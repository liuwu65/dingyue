var name="京东购物车 1.0.js";
auto.waitFor();


var 成立控制=0;

var 模式 = dialogs.select("选择模式\n\n(返回退出脚本)\n","● 抢购","● 捡漏");if(价格判断==-1){toast("已停止！");exit();}
if(模式==0){
    var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if(分==null){toast("已停止！");exit();}
    var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if(秒==null){toast("已停止！");exit();}
    var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if(延时==null){toast("已停止！");exit();}
}


var 价格判断 = dialogs.select("是否判断价格？\n\n(返回退出脚本)\n","● 判断价格","● 不判断价格");if(价格判断==-1){toast("已停止！");exit();}
if(价格判断==0){
    var 理想价格 =dialogs.input("输入物品理想价格\n\n(返回退出脚本)", 50); if( 理想价格==null){toast("已停止！");exit();}
}



function 倒计时(){
    console.show();
    sleep(100);
    console.setPosition(400,400);
    console.setSize(730,900);
    console.info("\n脚本已运行！\n"+"最后一分钟开始计时！");
    sleep(1000);

    for(;;){                //获取时间、判断开始
        var internetdDate = new Date(http.get("http://www.qq.com").headers["date"]); 
        var minute = internetdDate .getMinutes();
        var second = internetdDate .getSeconds();
        //print(minute+":"+second);
        if(minute>=分&&second>=秒){
            sleep(延时);//延迟时间
            break;
        }
        if(minute==分&&second<=秒-10){
            print(minute+":"+second);
            sleep(800);
        }
        if(minute==分&&second==秒-9){
            print(minute+":"+second);
            console.info("还有9秒");
            toast("还有9秒!\n请等待！");
            sleep(2000);
            toast("还有7秒!\n请等待！");
            console.hide();
            toast("还有5秒!\n马上开始！");
            toast("还有3秒!\n马上开始！");
        }
    }
    return;
}



if(模式==0){
    倒计时();
}
    
for(;;){
    textContains("去结算(").findOne().click();
    for(;;){
        if(textContains("提交订单").findOnce()){
            成立控制=0;
            break;
        }
        if(textContains("返回购物车").findOnce()){
            textContains("返回购物车").findOne().click();
            成立控制=1;
            break;
        }
    }
    if(成立控制==1){
        continue;
    }
    for(;;){
        if(textContains("提交订单").findOnce()){
            成立控制=0;
            break;
        }
        if(textContains("返回购物车").findOnce()){
            textContains("返回购物车").findOne().click();
            成立控制=1;
            break;
        }
    }
    if(成立控制==1){
        continue;
    }
    


    if(价格判断==0){
        var 价格=textContains("提交订单").findOne().parent().findOne(textContains("¥")).text().replace('¥','');
        if(价格<理想价格){
            textContains("提交订单").findOne().click();
        }else{
            back();
            continue;
        }
    }
    if(价格判断==1){
        textContains("提交订单").findOne().click();
    }


    for(;;){
        if(textContains("京东收银台").findOnce()){
            toast("购买成功！！！");
            成立控制=0;
            break;
        }
        if(textContains("返回购物车").findOnce()){
            textContains("返回购物车").findOne().click();
            idContains("ab1").findOne().click();
            成立控制=1;
            break;
        }
    }
    if(成立控制==1){
        continue;
    }else{
        break;
    }

}














log("00000000000000000000000000");



