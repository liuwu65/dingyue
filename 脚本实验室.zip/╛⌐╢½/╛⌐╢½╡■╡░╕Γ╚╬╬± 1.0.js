//京东叠蛋糕任务
//
auto.waitFor();

console.show();
sleep(100);
console.setPosition(400, 400);
console.setSize(730, 900);
log("正在进入！");

app.startActivity({
    data: "openApp.jdMobile://virtual?params=%7B%22des%22%3A%22m%22%2C%22url%22%3A%22https%3A%2F%2Fbunearth.m.jd.com%2FbabelDiy%2FZeus%2F3xAU77DgiPoDvHdbXUZb95a7u71X%2Findex.html%22%2C%22category%22%3A%22jump%22%2C%22sourceType%22%3A%22JSHOP_SOURCE_TYPE%22%2C%22sourceValue%22%3A%22JSHOP_SOURCE_VALUE%22%2C%22M_sourceFrom%22%3A%22lkyl%22%2C%22msf_type%22%3A%22click%22%2C%22m_param%22%3A%7B%22m_source%22%3A%220%22%2C%22event_series%22%3A%7B%7D%2C%22jda%22%3A%22177095863.1664140455.1538579865.1572975960.1572979455.472%22%2C%22usc%22%3A%22androidapp%22%2C%22ucp%22%3A%22t_335139774%22%2C%22umd%22%3A%22appshare%22%2C%22utr%22%3A%22CopyURL%22%2C%22jdv%22%3A%22177095863%7Candroidapp%7Ct_335139774%7Cappshare%7CCopyURL%7C1572882675599%22%2C%22ref%22%3A%22https%3A%2F%2Fbunearth.m.jd.com%2FbabelDiy%2FZeus%2F3xAU77DgiPoDvHdbXUZb95a7u71X%2Findex.html%22%2C%22psn%22%3A%221664140455%7C472%22%2C%22psq%22%3A5%2C%22pc_source%22%3A%22%22%2C%22mba_muid%22%3A%221664140455%22%2C%22mba_sid%22%3A%221572979455588510925986537476%22%2C%22std%22%3A%22MO-J2011-1%22%2C%22par%22%3A%22%22%2C%22event_id%22%3A%22Mnpm_ComponentApplied%22%2C%22mt_xid%22%3A%22%22%2C%22mt_subsite%22%3A%22%22%7D%2C%22SE%22%3A%7B%22mt_subsite%22%3A%22%22%2C%22__jdv%22%3A%22177095863%7Candroidapp%7Ct_335139774%7Cappshare%7CCopyURL%7C1572882675599%22%2C%22__jda%22%3A%22177095863.1664140455.1538579865.1572975960.1572979455.472%22%7D%7D",
});

text("做任务领金币").findOne();
sleep(2000);
text("做任务领金币").findOne().parent().click();
textContains("任务每日0点刷新").findOne();
log("进入成功！");
if (!text("已签到").findOne(500)) {
    text("签到").findOne().parent().click();
    log("签到");
}
text("已签到").findOne();
log("已签到！");


//做任务
var 找空次数 = 0;
for (; ;) {
    找空次数++;
    text("去完成").find().every(function (去完成) {
        var 任务内容 = 去完成.parent().parent().parent().child(0).child(1).text();

        if (任务内容.indexOf("8秒") != -1) {
            log(任务内容);
            找空次数 = 0;
            去完成.click();
            浏览8秒();
            textContains("任务每日").findOne();
            sleep(2000);
            return false;
        }

        else if (任务内容.indexOf("加购") != -1) {
            log(任务内容);
            找空次数 = 0;
            去完成.click();
            加购();
            textContains("任务每日").findOne();
            sleep(2000);
            return false;
        }

        else if (任务内容.indexOf("浏览5个商品") != -1) {
            log(任务内容);
            找空次数 = 0;
            去完成.click();
            浏览5个商品();
            textContains("任务每日").findOne();
            sleep(2000);
            return false;
        }

        else if (任务内容.indexOf("20-40") != -1) {
            log(任务内容);
            找空次数 = 0;
            去完成.click();
            二四();
            textContains("任务每日").findOne();
            sleep(2000);
            return false;
        }

        else {
            return true;
        }
    })
    sleep(500);
    if (找空次数 == 10) {
        log("任务完成！");
        toast("任务完成！");
        break;
    }
}


function 浏览8秒() {
    for (; ;) {
        if (idContains("arv").findOnce()) {
            idContains("arv").findOne().click();
        }
        if (textContains("恭喜完成").findOnce()) {
            desc("返回").findOne().click();
            break;
        }
        sleep(500);
    }
}

function 加购() {
    textContains("当前页点击加购").findOne();
    idContains("cart_").find().forEach(function (五商品) {
        if (五商品.child(0).text() == "已加购") {
            return;
        }
        五商品.child(2).click();
        sleep(300);
    })
    desc("返回").findOne().click();
}

function 浏览5个商品() {
    for (; ;) {
        if (idContains("view_").findOnce()) {
            idContains("view_").find().forEach(function (五商品) {
                五商品.click();
                text("购物车").findOne();
                desc("返回").findOne().click();
                idContains("view_").findOne();
            })
            sleep(1000);
            desc("返回").findOne().click();
            break;
        }
    }
}

function 二四() {
    sleep(3000);
    for (; ;) {
        if (textContains("任务每日").findOnce()) {
            break;
        }
        back();
        sleep(3000);
    }
}