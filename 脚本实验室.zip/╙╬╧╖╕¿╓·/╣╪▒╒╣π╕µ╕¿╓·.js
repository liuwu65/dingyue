for(;;){
    textContains("倒计时1s").findOne();
    sleep(1100);
    text("关闭广告").findOne().click();
    break;
}
