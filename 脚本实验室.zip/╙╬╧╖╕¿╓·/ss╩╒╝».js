//ss收集
auto.waitFor();
var a=0;
for(;;){
    descContains("ss").find().forEach(function(内容){
        if(内容.desc().indexOf("ssr://")!==-1||内容.desc().indexOf("ss://")!==-1){
            log(内容.desc());
            files.append("/sdcard/脚本/ss收集1.js", 内容.desc()+"\n"); 
        }
    })
    if(!desc("转到底部").findOne(50)){
        a++;
        if(a>3){
            toast("收集完成！");
            toast("收集完成！");
            break;
        }

    }
    swipe(135, 1650, 135, 230, 50);
}


