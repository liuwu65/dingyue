auto.waitFor();

var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if(分==null){toast("已停止！");exit();}
var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if(秒==null){toast("已停止！");exit();}
var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if(延时==null){toast("已停止！");exit();}

function 倒计时(){
    console.show();
    sleep(100);
    console.setPosition(400,400);
    console.setSize(730,900);
    console.info("\n脚本已运行！\n"+"最后一分钟开始计时！");
    sleep(1000);

    for(;;){                //获取时间、判断开始
        var internetdDate = new Date(http.get("http://www.qq.com").headers["date"]); 
        var minute = internetdDate .getMinutes();
        var second = internetdDate .getSeconds();
        //print(minute+":"+second);
        if(minute>=分&&second>=秒){
            sleep(延时);//延迟时间
            break;
        }
        if(minute==分&&second<=秒-10){
            print(minute+":"+second);
            sleep(800);
        }
        if(minute==分&&second==秒-9){
            print(minute+":"+second);
            console.info("还有9秒");
            toast("还有9秒!\n请等待！");
            sleep(2000);
            toast("还有7秒!\n请等待！");
            console.hide();
            toast("还有5秒!\n马上开始！");
            toast("还有3秒!\n马上开始！");
        }
    }
    return;
}


倒计时();


for(var i=0;i<100;i++){
    click(750,1650);
    sleep(20);
}