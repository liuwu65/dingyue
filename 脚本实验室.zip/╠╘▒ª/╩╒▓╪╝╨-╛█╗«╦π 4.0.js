var 名称版本 = "收藏夹-聚划算 4.0";
//添加指定规格模式，兼容聚划算的开团提醒按钮

auto.waitFor();
var time = new Date(http.get("http://www.qq.com").headers["date"]);
var month = time.getMonth()+1;
var log = "/sdcard/脚本/日志"+month+"."+time.getDate()+".js";
files.create(log);          //创建日志文件



var 抢购位置 = dialogs.select("请选择 抢购位置\n\n(返回退出脚本)", "\n● 收藏夹", "\n● 聚划算\n"); if(抢购位置==-1){toast("已停止！");exit();}
var 抢购模式 = dialogs.select("请选择 抢购模式\n\n(返回退出脚本)","● 准点模式", "● 捡漏模式"); if(抢购模式==-1){toast("已停止！");exit();}
if(抢购模式==0){
    var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if(分==null){toast("已停止！");exit();}
    var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if(秒==null){toast("已停止！");exit();}
    var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 4); if(延时==null){toast("已停止！");exit();}
}else{
    var 分 = 0;
    var 秒 = 0;
    var 延时 = 0;
}
var options = ["● 判断中间步骤  -  提交", "● 有中间步骤    -    提交","● 无中间步骤    -    提交","● 自动选择规格  -  提交","● 指定规格      -      提交"];
var 提交方式 = dialogs.select("请选择 提交方式\n\n(若不清楚是否有中间步骤\n请选择 判断中间步骤)\n\n(返回退出脚本)", options); if(提交方式==-1){toast("已停止！");exit();}
if(提交方式==4){
    var 类别数 = dialogs.singleChoice("请选择类别数量\n\n(只有一个选项的类不计算)",["1","2","3","4","5"])+1; if(类别数==-1){toast("已停止！");exit();};
    var 类别选择=[''];
    for(var i=0;i<类别数;i++){
        类别选择[i] = dialogs.singleChoice("第"+(i+1)+"类选择第几个？",["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25"]); if(类别选择[i]==-1){toast("已停止！");exit();};
    }
}
var 价格判断 = dialogs.select("是否判断价格？\n\n(返回退出脚本)\n","● 判断价格","● 不判断价格");if(价格判断==-1){toast("已停止！");exit();}
if(价格判断==0){
    var 理想价格 =dialogs.input("输入物品理想价格\n\n(返回退出脚本)", 50); if( 理想价格==null){toast("已停止！");exit();}
}
var time = new Date(http.get("http://www.qq.com").headers["date"]);
var 日志字串1 = "\n================================\n"+time.getHours()+":"+time.getMinutes()+":"+time.getSeconds()+"\n    /----"+名称版本+"----/\n";
if(!抢购位置){var 日志字串2 ="抢购位置：收藏夹\n"}else{var 日志字串2 ="抢购位置：聚划算\n"};
if(!抢购模式){var 日志字串3 ="抢购模式：准点模式\n"}else{var 日志字串3 ="抢购模式：捡漏模式\n"};
if(提交方式==0){var 日志字串4 ="提交方式：判断中间步骤\n"}
if(提交方式==1){var 日志字串4 ="提交方式：有中间步骤\n"}
if(提交方式==2){var 日志字串4 ="提交方式：无中间步骤\n"}
if(提交方式==3){var 日志字串4 ="提交方式：自动选择规格\n"}
if(提交方式==4){var 日志字串4 ="提交方式：指定规格\n类别选择："+类别选择+"\n"}
var 显示字串 = " ";var 日志字串5 = " ";var 成立控制 = 0;var 次数 = 0;





function 倒计时(){
    console.show();
    sleep(100);
    console.setPosition(400,400);
    console.setSize(730,900);
    console.info(显示字串+"\n脚本已运行！\n"+"最后一分钟开始计时！");
    sleep(1000);

    for(;;){                //获取时间、判断开始
        var internetdDate = new Date(http.get("http://www.qq.com").headers["date"]); //把Date转换成时间对象
        //var hour = internetdDate .getHours();
        var minute = internetdDate .getMinutes();
        var second = internetdDate .getSeconds();
        //print(minute+":"+second);
        if(minute>=分&&second>=秒){   //！！时间控制！！！！
            sleep(延时);//延迟时间
            break;
        }
        if(minute==分&&second<=秒-10){
            print(minute+":"+second);
            sleep(800);
        }
        if(minute==分&&second==秒-9){
            print(minute+":"+second);
            console.info("还有9秒");
            toast("还有9秒!\n请等待！");
            sleep(2000);
            toast("还有7秒!\n请等待！");
            console.hide();
            toast("还有5秒!\n马上开始！");
            toast("还有3秒!\n马上开始！");
        }
    }
    return;
}




function 判断价格抢购(){
    textContains("客服").findOne();
    var 购买按钮=idContains("detail_main_sys_button").find()[1];
    if(购买按钮&&购买按钮.enabled()){
        购买按钮.click();
        成立控制=1;
    }else{
        back();
        return;
    }                   //判断点击购买

    if(提交方式==0){           //判断中间步骤-提交
        var djkz = 0;
        for(;;){
            if(textContains("提交订单").findOnce()){
                var 价格=textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥','');
                if(价格<理想价格){
                    textStartsWith("提交订单").findOne().click();   //判断成立提交订单
                    toast("抢购完成！！！");
                }else{
                    toast("价格变更！！！");
                }
                break;
            }
            if(djkz==0&&idContains("confirm").findOnce()){
                idContains("confirm").findOne().click();
                djkz=1;
            }
        }
    }
    
    if(提交方式==1){           //有中间步骤-提交
        idContains("confirm").findOne().click();
        var 价格=textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥','');
        if(价格<理想价格){
            textStartsWith("提交订单").findOne().click();
            toast("抢购完成！！！");          //判断成立提交订单
        }else{
            toast("价格变更！！！");          //判断不成立返回
        }
    }

    if(提交方式==2){           //无中间步骤-提交
        var 价格=textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥','');
        if(价格<理想价格){
            textStartsWith("提交订单").findOne().click();
            toast("抢购完成！！！");          //判断成立提交订单
        }else{
            toast("价格变更！！！");          //判断不成立返回
        }
    }
    if(提交方式==3){           //自动选择规格-提交
        textContains("购买数量").findOne();
        idContains("sku_native_view_layout").findOne().children().forEach(function(类){
            类.children().forEach(function(类2){
                if(类2.className()=="android.widget.RelativeLayout"){
                    if(类2.childCount()==1){return;}
                    类2.children().every(function(项){
                        if(项.desc().indexOf("不可选择") != -1){
                            return true;
                        }else{
                            项.click();
                            return false;
                        }
                    });
                }
            });
        });                                 //自动选择规格操作
        idContains("confirm").findOne().click();
        var 价格=textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥','');
        if(价格<理想价格){
            textStartsWith("提交订单").findOne().click();
            toast("抢购完成！！！");          //判断成立提交订单
        }else{
            toast("价格变更！！！");          //判断不成立返回
        }
    }
    if(提交方式==4){           //指定规格-提交
        var i=0;
        textContains("购买数量").findOne();
        idContains("sku_native_view_layout").findOne().children().forEach(function(类){
            类.children().forEach(function(类2){
                if(类2.className()=="android.widget.RelativeLayout"){
                    if(类2.childCount()==1){return;}
                    if(类2.child(类别选择[i]).desc().indexOf("不可选择") != -1){
                        类2.children().every(function(项){
                            if(项.desc().indexOf("不可选择") != -1){
                                return true;
                            }else{
                                项.click();
                                return false;
                            }
                        });
                    }else{
                        类2.child(类别选择[i]).click();
                    }
                    i++;
                }
            });
        });
        idContains("confirm").findOne().click();
        var 价格=textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥','');
        if(价格<理想价格){
            textStartsWith("提交订单").findOne().click();
            toast("抢购完成！！！");
        }else{
            toast("价格变更！！！");
        }
    }
    价格1=价格;
}






function 判断价格捡漏(){
    textContains("客服").findOne();
    var 购买按钮=idContains("detail_main_sys_button").find()[1];
    if(购买按钮&&购买按钮.enabled()){
        购买按钮.click();
        成立控制=1;
    }else{
        back();
        return;
    }                   //判断点击购买

    if(提交方式==0){           //判断中间步骤-提交
        var djkz = 0;
        for(;;){
            if(textContains("提交订单").findOnce()){
                break;
            }
            if(djkz==0&&idContains("confirm").findOnce()){
                idContains("confirm").findOne().click();
                djkz=1;
            }
        }
        if(djkz==0){
            for(;;){
                for(;;){
                    textStartsWith("提交订单").findOne();
                    var 价格=textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥','');
                    if (价格>理想价格||textContains("购买数量超过").findOnce()||textContains("商品不能购买").findOnce()) {
                        sleep(1100);
                        back();
                        textContains("客服").findOne();
                        idContains("detail_main_sys_button").find()[1].click();
                        continue;
                    } else {
                        break;
                    }
                }
                textStartsWith("提交订单").findOne().click();
                if(textContains("我知道了").findOne(500)){
                    textContains("我知道了").findOne().click();
                    back();
                    textContains("客服").findOne();
                    idContains("detail_main_sys_button").find()[1].click();
                    continue;
                }else{
                    break;
                }
            }
            toast("抢购完成！！！");
        }
        if(djkz==1){
            for(;;){
                for(;;){
                    textStartsWith("提交订单").findOne();
                    var 价格=textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥','');
                    if (价格>理想价格||textContains("购买数量超过").findOnce()||textContains("商品不能购买").findOnce()) {
                        sleep(1100);
                        back();
                        idContains("confirm").findOne().click();
                        continue;
                    } else {
                        break;
                    }
                }
                textStartsWith("提交订单").findOne().click();
                if(textContains("我知道了").findOne(500)){
                    textContains("我知道了").findOne().click();
                    back();
                    idContains("confirm").findOne().click();
                    continue;
                }else{
                    break;
                }
            }
            toast("抢购完成！！！");
        }
    }
    
    if(提交方式==1){           //有中间步骤-提交
        idContains("confirm").findOne().click();
        for(;;){
            for(;;){
                textStartsWith("提交订单").findOne();
                var 价格=textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥','');
                if (价格>理想价格||textContains("购买数量超过").findOnce()||textContains("商品不能购买").findOnce()) {
                    sleep(1100);
                    back();
                    idContains("confirm").findOne().click();
                    continue;
                } else {
                    break;
                }
            }
            textStartsWith("提交订单").findOne().click();
            if(textContains("我知道了").findOne(500)){
                textContains("我知道了").findOne().click();
                back();
                idContains("confirm").findOne().click();
                continue;
            }else{
                break;
            }
        }
        toast("抢购完成！！！");
    }

    if(提交方式==2){           //无中间步骤-提交
        for(;;){
            for(;;){
                textStartsWith("提交订单").findOne();
                var 价格=textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥','');
                if (价格>理想价格||textContains("购买数量超过").findOnce()||textContains("商品不能购买").findOnce()) {
                    sleep(1100);
                    back();
                    textContains("客服").findOne();
                    idContains("detail_main_sys_button").find()[1].click();
                    continue;
                } else {
                    break;
                }
            }
            textStartsWith("提交订单").findOne().click();
            if(textContains("我知道了").findOne(500)){
                textContains("我知道了").findOne().click();
                back();
                textContains("客服").findOne();
                idContains("detail_main_sys_button").find()[1].click();
                continue;
            }else{
                break;
            }
        }
        toast("抢购完成！！！");
    }

    if(提交方式==3){           //自动选择规格-提交
        textContains("购买数量").findOne();
        idContains("sku_native_view_layout").findOne().children().forEach(function(类){
            类.children().forEach(function(类2){
                if(类2.className()=="android.widget.RelativeLayout"){
                    if(类2.childCount()==1){return;}
                    类2.children().every(function(项){
                        if(项.desc().indexOf("不可选择") != -1){
                            return true;
                        }else{
                            项.click();
                            return false;
                        }
                    });
                }
            });
        });                                 //自动选择规格操作
        idContains("confirm").findOne().click();

        for(;;){
            for(;;){
                textStartsWith("提交订单").findOne();
                var 价格=textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥','');
                if (价格>理想价格||textContains("购买数量超过").findOnce()||textContains("商品不能购买").findOnce()) {
                    sleep(1100);
                    back();
                    idContains("confirm").findOne().click();
                    continue;
                } else {
                    break;
                }
            }
            textStartsWith("提交订单").findOne().click();
            if(textContains("我知道了").findOne(500)){
                textContains("我知道了").findOne().click();
                back();
                idContains("confirm").findOne().click();
                continue;
            }else{
                break;
            }
        }
        toast("抢购完成！！！");
    }
    if(提交方式==4){           //指定规格-提交
        var i=0;
        textContains("购买数量").findOne();
        idContains("sku_native_view_layout").findOne().children().forEach(function(类){
            类.children().forEach(function(类2){
                if(类2.className()=="android.widget.RelativeLayout"){
                    if(类2.childCount()==1){return;}
                    if(类2.child(类别选择[i]).desc().indexOf("不可选择") != -1){
                        类2.children().every(function(项){
                            if(项.desc().indexOf("不可选择") != -1){
                                return true;
                            }else{
                                项.click();
                                return false;
                            }
                        });
                    }else{
                        类2.child(类别选择[i]).click();
                    }
                    i++;
                }
            });
        });

        idContains("confirm").findOne().click();

        for(;;){
            for(;;){
                textStartsWith("提交订单").findOne();
                var 价格=textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥','');
                if (价格>理想价格||textContains("购买数量超过").findOnce()||textContains("商品不能购买").findOnce()) {
                    sleep(1100);
                    back();
                    idContains("confirm").findOne().click();
                    continue;
                } else {
                    break;
                }
            }
            textStartsWith("提交订单").findOne().click();
            if(textContains("我知道了").findOne(500)){
                textContains("我知道了").findOne().click();
                back();
                idContains("confirm").findOne().click();
                continue;
            }else{
                break;
            }
        }
        toast("抢购完成！！！");
    }
}







function 判断价格(){
    if(抢购模式==0){                    //判断部分
        toast("抢购开始。。。");
        
        倒计时();
        for(var i=0;i<6;i++){
            click(350,650);
            次数++;
            判断价格抢购();
            if(成立控制==1){
                break;
            }                   //判断结束
            if(抢购位置)                    //判断返回
                textContains("个护").findOne();
            else
                descContains("全部宝贝").findOne();
        }
        files.append(log,"    最后显示价格：￥ "+价格1+"\n    进入次数统计："+次数+"\n================================\n");
        if(成立控制==1){
            toast("抢购结束！！！");
        }else{
            toast("来晚啦！！！\n可重新运行脚本选择捡漏！！！");
        }
    }
    


    if(抢购模式==1){                    //捡漏部分
        toast("捡漏开始。。。");
    
        for(;;){
            click(350,650);
            判断价格捡漏();
            if(成立控制==1){
                break;
            }
            if(抢购位置)                    //判断返回
                textContains("个护").findOne();
            else
                descContains("全部宝贝").findOne();
        }
    
        files.append(log,"    最后显示价格：￥ "+价格1+"\n================================\n");
        if(成立控制==1){
            toast("捡漏结束！！！");
        }else{
            toast("没有机会了。。。");
        }
    }
}













function 不判断价格抢购(){
    textContains("客服").findOne();
    var 购买按钮=idContains("detail_main_sys_button").find()[1];
    if(购买按钮&&购买按钮.enabled()){
        购买按钮.click();
        成立控制=1;
    }else{
        back();
        return;
    }                   //判断点击购买

    if(提交方式==0){           //判断中间步骤-提交
        var djkz = 0;
        for(;;){
            if(textContains("提交订单").findOnce()){
                textStartsWith("提交订单").findOne().click();
                toast("抢购完成！！！");
                break;
            }
            if(djkz==0&&idContains("confirm").findOnce()){
                idContains("confirm").findOne().click();
                djkz=1;
            }
        }
    }
    
    if(提交方式==1){           //有中间步骤-提交
        idContains("confirm").findOne().click();
        textStartsWith("提交订单").findOne().click();
        toast("抢购完成！！！");
    }

    if(提交方式==2){           //无中间步骤-提交
        textStartsWith("提交订单").findOne().click();
        toast("抢购完成！！！");
    }
    if(提交方式==3){           //自动选择规格-提交
        textContains("购买数量").findOne();
        idContains("sku_native_view_layout").findOne().children().forEach(function(类){
            类.children().forEach(function(类2){
                if(类2.className()=="android.widget.RelativeLayout"){
                    if(类2.childCount()==1){return;}
                    类2.children().every(function(项){
                        if(项.desc().indexOf("不可选择") != -1){
                            return true;
                        }else{
                            项.click();
                            return false;
                        }
                    });
                }
            });
        });                                 //自动选择规格操作

        idContains("confirm").findOne().click();
        textStartsWith("提交订单").findOne().click();
        toast("抢购完成！！！");
    }
    if(提交方式==4){           //指定规格-提交
        var i=0;
        textContains("购买数量").findOne();
        idContains("sku_native_view_layout").findOne().children().forEach(function(类){
            类.children().forEach(function(类2){
                if(类2.className()=="android.widget.RelativeLayout"){
                    if(类2.childCount()==1){return;}
                    if(类2.child(类别选择[i]).desc().indexOf("不可选择") != -1){
                        类2.children().every(function(项){
                            if(项.desc().indexOf("不可选择") != -1){
                                return true;
                            }else{
                                项.click();
                                return false;
                            }
                        });
                    }else{
                        类2.child(类别选择[i]).click();
                    }
                    i++;
                }
            });
        });

        idContains("confirm").findOne().click();
        textStartsWith("提交订单").findOne().click();
        toast("抢购完成！！！");
    }
}









function 不判断价格捡漏(){
    textContains("客服").findOne();
    var 购买按钮=idContains("detail_main_sys_button").find()[1];
    if(购买按钮&&购买按钮.enabled()){
        购买按钮.click();
        成立控制=1;
    }else{
        back();
        return;
    }                   //判断点击购买

    if(提交方式==0){           //判断中间步骤-提交
        var djkz = 0;
        for(;;){
            if(textContains("提交订单").findOnce()){
                break;
            }
            if(djkz==0&&idContains("confirm").findOnce()){
                idContains("confirm").findOne().click();
                djkz=1;
            }
        }
        if(djkz==0){
            for(;;){
                for(;;){
                    textStartsWith("提交订单").findOne();
                    if (textContains("购买数量超过").findOnce()||textContains("商品不能购买").findOnce()) {
                        sleep(1100);
                        back();
                        textContains("客服").findOne();
                        idContains("detail_main_sys_button").find()[1].click();
                        continue;
                    } else {
                        break;
                    }
                }
                textStartsWith("提交订单").findOne().click();
                if(textContains("我知道了").findOne(500)){
                    textContains("我知道了").findOne().click();
                    back();
                    textContains("客服").findOne();
                    idContains("detail_main_sys_button").find()[1].click();
                    continue;
                }else{
                    break;
                }
            }
            toast("抢购完成！！！");
        }
        if(djkz==1){
            for(;;){
                for(;;){
                    textStartsWith("提交订单").findOne();
                    if (textContains("购买数量超过").findOnce()||textContains("商品不能购买").findOnce()) {
                        sleep(1100);
                        back();
                        idContains("confirm").findOne().click();
                        continue;
                    } else {
                        break;
                    }
                }
                textStartsWith("提交订单").findOne().click();
                if(textContains("我知道了").findOne(500)){
                    textContains("我知道了").findOne().click();
                    back();
                    idContains("confirm").findOne().click();
                    continue;
                }else{
                    break;
                }
            }
            toast("抢购完成！！！");
        }
    }
    
    if(提交方式==1){           //有中间步骤-提交
        idContains("confirm").findOne().click();
        for(;;){
            for(;;){
                textStartsWith("提交订单").findOne();
                if (textContains("购买数量超过").findOnce()||textContains("商品不能购买").findOnce()) {
                    sleep(1100);
                    back();
                    idContains("confirm").findOne().click();
                    continue;
                } else {
                    break;
                }
            }
            textStartsWith("提交订单").findOne().click();
            if(textContains("我知道了").findOne(500)){
                textContains("我知道了").findOne().click();
                back();
                idContains("confirm").findOne().click();
                continue;
            }else{
                break;
            }
        }
        toast("抢购完成！！！");
    }

    if(提交方式==2){           //无中间步骤-提交
        for(;;){
            for(;;){
                textStartsWith("提交订单").findOne();
                if (textContains("购买数量超过").findOnce()||textContains("商品不能购买").findOnce()) {
                    sleep(1100);
                    back();
                    textContains("客服").findOne();
                    idContains("detail_main_sys_button").find()[1].click();
                    continue;
                } else {
                    break;
                }
            }
            textStartsWith("提交订单").findOne().click();
            if(textContains("我知道了").findOne(500)){
                textContains("我知道了").findOne().click();
                back();
                textContains("客服").findOne();
                idContains("detail_main_sys_button").find()[1].click();
                continue;
            }else{
                break;
            }
        }
        toast("抢购完成！！！");
    }

    if(提交方式==3){                     //自动选择规格-提交
        textContains("购买数量").findOne();
        idContains("sku_native_view_layout").findOne().children().forEach(function(类){
            类.children().forEach(function(类2){
                if(类2.className()=="android.widget.RelativeLayout"){
                    if(类2.childCount()==1){return;}
                    类2.children().every(function(项){
                        if(项.desc().indexOf("不可选择") != -1){
                            return true;
                        }else{
                            项.click();
                            return false;
                        }
                    });
                }
            });
        });                                 //自动选择规格操作

        idContains("confirm").findOne().click();
        for(;;){
            for(;;){
                textStartsWith("提交订单").findOne();
                if (textContains("购买数量超过").findOnce()||textContains("商品不能购买").findOnce()) {
                    sleep(1100);
                    back();
                    idContains("confirm").findOne().click();
                    continue;
                } else {
                    break;
                }
            }
            textStartsWith("提交订单").findOne().click();
            if(textContains("我知道了").findOne(500)){
                textContains("我知道了").findOne().click();
                back();
                idContains("confirm").findOne().click();
                continue;
            }else{
                break;
            }
        }
        toast("抢购完成！！！");
    }

    if(提交方式==4){                     //指定规格-提交
        var i=0;
        textContains("购买数量").findOne();
        idContains("sku_native_view_layout").findOne().children().forEach(function(类){
            类.children().forEach(function(类2){
                if(类2.className()=="android.widget.RelativeLayout"){
                    if(类2.childCount()==1){return;}
                    if(类2.child(类别选择[i]).desc().indexOf("不可选择") != -1){
                        类2.children().every(function(项){
                            if(项.desc().indexOf("不可选择") != -1){
                                return true;
                            }else{
                                项.click();
                                return false;
                            }
                        });
                    }else{
                        类2.child(类别选择[i]).click();
                    }
                    i++;
                }
            });
        });

        idContains("confirm").findOne().click();
        for(;;){
            for(;;){
                textStartsWith("提交订单").findOne();
                if (textContains("购买数量超过").findOnce()||textContains("商品不能购买").findOnce()) {
                    sleep(1100);
                    back();
                    idContains("confirm").findOne().click();
                    continue;
                } else {
                    break;
                }
            }
            textStartsWith("提交订单").findOne().click();
            if(textContains("我知道了").findOne(500)){
                textContains("我知道了").findOne().click();
                back();
                idContains("confirm").findOne().click();
                continue;
            }else{
                break;
            }
        }
        toast("抢购完成！！！");
    }
}







function 不判断价格(){

    if(抢购模式==0){                    //判断部分
        toast("抢购开始。。。");
        
        倒计时();
        for(var i=0;i<6;i++){
            click(350,650);
            次数++;
            不判断价格抢购(); 
            if(成立控制==1){
                break;
            }                   //判断结束
            if(抢购位置)                    //判断返回
                textContains("个护").findOne();
            else
                descContains("全部宝贝").findOne();
        }
        files.append(log,"    进入次数统计："+次数+"\n================================\n");
        if(成立控制==1){
            toast("抢购结束！！！");
        }else{
            toast("来晚啦！！！\n可重新运行脚本选择捡漏！！！");
        }
    }
    


    if(抢购模式==1){                    //捡漏部分
        toast("捡漏开始。。。");
    
        for(;;){
            click(350,650);
            不判断价格捡漏();
            if(成立控制==1){
                break;
            }                   //判断结束
            if(抢购位置)                    //判断返回
                textContains("个护").findOne();
            else
                descContains("全部宝贝").findOne();
        }
    
        files.append(log,"\n================================\n");
        if(成立控制==1){
            toast("捡漏结束！！！");
        }else{
            toast("没有机会了。。。");
        }
    }
}


if(价格判断==0){
    var 价格1=null;
    var 日志字串5 = 日志字串1+"判断价格！\n"+日志字串2+日志字串3+日志字串4+"    设定时间："+分+":"+秒+"\n    延时："+延时+"\n"+"    理想价格："+理想价格+"\n";
    var 显示字串 ="/----"+名称版本+"----/\n\n"+"判断价格！\n"+日志字串2+日志字串3+日志字串4+"开始时间："+分+":"+秒+"\n延        时："+延时+"\n"+"理想价格：￥ "+理想价格+"\n";              //显示参数
    files.append(log, 日志字串5);                        //写入日志文件
    判断价格();
}

if(价格判断==1){
    var 日志字串5 = 日志字串1+"不判断价格！\n"+日志字串2+日志字串3+日志字串4+"    设定时间："+分+":"+秒+"\n    延时："+延时+"\n";
    var 显示字串 ="/----"+名称版本+"----/\n\n"+"不判断价格！\n"+日志字串2+日志字串3+日志字串4+"开始时间："+分+":"+秒+"\n延        时："+延时+"\n";              //显示参数
    files.append(log, 日志字串5);                        //写入日志文件
    不判断价格();
}
