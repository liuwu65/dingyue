auto.waitFor();
toast("开始浏览。。。");

进入();
function 进入() {
    sleep(1000);
    app.startActivity({
        packageName: "com.taobao.taobao",
        className: "com.taobao.search.searchdoor.SearchDoorActivity"
    });
    waitForActivity("com.taobao.search.searchdoor.SearchDoorActivity");
    sleep(1000);
    setText("双十二全民寻宝");
    if (text("搜索").findOnce())
        text("搜索").findOne().click();
    sleep(5000);
    for(;;){
        log("进入判断");
        if(textContains("base64").findOnce()) {
            break;
        }else
            sleep(5000);
    }//完成任务判断
    click(950,1650);
    log("进入成功");
}

function 去打卡(){
    log("开始打卡");
    textContains("前往双12互动群").findOne().click();
    for(;;){
        log("判断");
        if(desc("立即打卡").findOnce()) {
            click(540,630);
            sleep(5000);
            click(950,1650);
            break;
        }else
            sleep(300);
    }//完成任务判断
    log("打卡完成");
}

function 去浏览(){
    log("开始浏览");
    if(textContains("首页").findOnce()){
        textContains("首页").findOne().click();
        sleep(4000);
        swipe(500, 1500, 500, 500, 300);//滑动
        sleep(17000);
        进入();
        return;               
    }
    if(textContains("淘宝人生").findOnce()){
        textContains("淘宝人生").findOne().click();
        sleep(7000);
        click(540,1240);
        sleep(1000);
        进入();
        return;               
    }
    if(textContains("访问频道").findOnce()){
        textContains("访问频道").findOne().click();
        sleep(4000);
        click(300,1300);
        sleep(3000);
        进入();
        return;               
    }//特殊对待

    textContains("去浏览").findOne().click();
    for(;;){
        log("等待浏览");
        if (textContains("滑动浏览").findOnce()||descContains("滑动浏览").findOnce())
            break;
        else
            sleep(500);//开始浏览判断
        if(textContains("今日已达").findOnce()||descContains("今日已达").findOnce()){
            back();
            sleep(1000);
            return;
        }
        if (textContains("任务完成").findOnce()||descContains("任务完成").findOnce()||descContains("你已获得").findOnce()){
            back();
            sleep(1000);
            return;
        }//已达上线或已完成判断并返回
    }
    log("==========正常浏览");
    swipe(500, 1500, 500, 500, 300);//滑动
    for(;;){
        log("判断");
        if(textContains("任务完成").findOnce()||descContains("任务完成").findOnce())
            break;
        else
            sleep(500);
        }//完成任务判断
    back();
    log("浏览完成");
    sleep(3000);
}

function 去搜索(){
    log("开始搜索");
    textContains("去搜索").findOne().click();
    sleep(4000);
    swipe(500, 1500, 500, 500, 300);//滑动
    for(;;){
        if (textContains("任务完成").findOnce()||descContains("任务完成").findOnce())
            break;
        else
            sleep(300);
    }//完成任务判断
    back();
    sleep(3000);
}

for(var i=0;i<30;i++){
    if (text("去签到").findOnce()) {
        text("去签到").findOne().click();
        sleep(2000);
        continue;
    }else{
        for(;;){
            if(textContains("去浏览").findOnce()){
                去浏览();
                continue;
            }else{
                for(;;){
                    if(textContains("去搜索").findOnce()){
                        去搜索();
                        continue;
                    }else{
                        for(;;){
                            if (textContains("前往双12互动群").findOnce()){
                                去打卡();
                                continue;
                            }else{
                                i++;
                                break;
                            }
                        }
                        break;
                    }
                }
                break;
            }
                
        }
    }
    sleep(3000);
    log("111");
}
toast("浏览完成");
toast("开心投骰子吧！！");

