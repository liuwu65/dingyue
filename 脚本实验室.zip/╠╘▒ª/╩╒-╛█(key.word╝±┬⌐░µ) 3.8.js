var 名称版本 = "收-聚(key.word捡漏版) 3.8";
//解决点击提交订单后的捡漏失败情况

auto.waitFor();
var time = new Date(http.get("http://www.qq.com").headers["date"]);
var month = time.getMonth()+1;
var log = "/sdcard/脚本/日志"+month+"."+time.getDate()+".js";
files.create(log);          //创建日志文件

var 价格判断 = dialogs.select("是否判断价格？\n\n(返回退出脚本)\n","● 判断价格","● 不判断价格");if(价格判断==-1){toast("已停止！");exit();}
var 显示字串 = " ";var 成立控制 = 0;


var 抢购位置 = dialogs.select("请选择 抢购位置\n\n(返回退出脚本)", "\n● 收藏夹", "\n● 聚划算\n"); if(抢购位置==-1){toast("已停止！");exit();}
var 选项关键字符 = dialogs.rawInput("输入选项关键字符\n\n(返回退出脚本)", "【"); if(选项关键字符==null){toast("已停止！");exit();}
var 分 = dialogs.input("输入截止的时间-分\n\n(返回退出脚本)", 59); if(分==null){toast("已停止！");exit();}
var 秒 = dialogs.input("输入截止的时间-秒\n\n(返回退出脚本)", 59); if(秒==null){toast("已停止！");exit();}
var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if(延时==null){toast("已停止！");exit();}
var time = new Date(http.get("http://www.qq.com").headers["date"]);
var 日志字串1 = "\n================================\n"+time.getHours()+":"+time.getMinutes()+":"+time.getSeconds()+"\n/--"+名称版本+"--/\n";
if(!抢购位置){var 日志字串2 ="抢购位置：收藏夹\n"}else{var 日志字串2 ="抢购位置：聚划算\n"};
var 日志字串5 = " ";
var 显示字串 = " ";



function 倒计时(){
    console.show();
    sleep(100);
    console.setPosition(400,400);
    console.setSize(730,900);
    console.info(显示字串+"\n脚本已运行！\n"+"最后一分钟开始计时！");
    sleep(1000);

    for(;;){                //获取时间、判断开始
        var internetdDate = new Date(http.get("http://www.qq.com").headers["date"]); //把Date转换成时间对象
        //var hour = internetdDate .getHours();
        var minute = internetdDate .getMinutes();
        var second = internetdDate .getSeconds();
        //print(minute+":"+second);
        if(minute>=分&&second>=秒){   //！！时间控制！！！！
            sleep(延时);//延迟时间
            break;
        }
        if(minute==分&&second<=秒-10){
            print(minute+":"+second);
            sleep(800);
        }
        if(minute==分&&second==秒-9){
            print(minute+":"+second);
            console.info("还有9秒");
            toast("还有9秒!\n请等待！");
            sleep(2000);
            toast("还有7秒!\n请等待！");
            console.hide();
            toast("还有5秒!\n马上开始！");
            toast("还有3秒!\n马上开始！");
        }
    }
    return;
}





function 判断价格(){
    var 理想价格 =dialogs.input("输入物品理想价格\n\n(返回退出脚本)", 50); if( 理想价格==null){toast("已停止！");exit();}

    日志字串5 = 日志字串1+日志字串2+"选项关键字："+选项关键字符+"\n    截止时间："+分+":"+秒+"\n    延时："+延时+"\n"+"    理想价格："+理想价格+"\n";
    显示字串 ="/"+名称版本+"/\n\n"+日志字串2+选项关键字符+"\n截止时间："+分+":"+秒+"\n延        时："+延时+"\n"+"理想价格：￥ "+理想价格+"\n";              //显示参数
    files.append(log, 日志字串5);                        //写入日志文件
    

    if(true){                    //捡漏部分
        toast("捡漏开始。。。");
    
        function 抢购(){
            textContains("客服").findOne();
            var 购买按钮=idContains("detail_main_sys_button").find()[1];
            if( 购买按钮.enabled()){
                购买按钮.click();
                成立控制=1;
            }else{
                back();
                return;
            }                   //判断点击购买
    
            if(true){           //有中间步骤-提交
                textContains("确定").findOne();
                descContains(选项关键字符).find().every(function(选项){
                    if(选项.desc().indexOf("不可选择") != -1){
                        return true;
                    }else{
                        选项.click();
                        return false;
                    }
                });
                idContains("confirm").findOne().click();
                for(;;){
                    for(;;){
                        textStartsWith("提交订单").findOne();
                        var 价格=textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥','');
                        if (价格>理想价格||textContains("购买数量超过").findOnce()||textContains("商品不能购买").findOnce()) {
                            sleep(1300);
                            back();
                            idContains("confirm").findOne().click();
                            continue;
                        } else {
                            break;
                        }
                    }
                    textStartsWith("提交订单").findOne().click();
                    if(textContains("我知道了").findOne(500)){
                        textContains("我知道了").findOne().click();
                        back();
                        idContains("confirm").findOne().click();
                        continue;
                    }else{
                        break;
                    }
                }
                toast("抢购完成！！！");
            }
            价格1=价格;
        }
        
      
        for(;;){
            var internetdDate = new Date(http.get("http://www.qq.com").headers["date"]); //把Date转换成时间对象
            var minute = internetdDate .getMinutes();
            var second = internetdDate .getSeconds();
            //print(minute+":"+second);
            if(minute>=分&&second>=30){    //！！时间控制！！！！
                break;
            }
    
            if(抢购位置)                    //判断返回
                textContains("个护").findOne();
            else
                descContains("全部宝贝").findOne();
            click(350,650);
            抢购(); 
            if(成立控制==1){
                break;
            }                               //判断结束
        }
    
        if(成立控制!=1){
            toast("   循环停止！\n\n开始整点捡漏！");
            toast("   循环停止！\n\n开始整点捡漏！");
            倒计时();
    
            for(var i=0;i<4;i++){
                click(350,650);
                抢购(); 
                if(成立控制==1){
                    break;
                }
                if(抢购位置)
                    textContains("个护").findOne();
                else
                    descContains("全部宝贝").findOne();   //判断返回
            }
        }
    
        files.append(log,"    最后显示价格：￥ "+价格1+"\n================================\n");
        if(成立控制==1){
            toast("捡漏结束！！！");
        }else{
            toast("没有机会了。。。");
        }
    }
}





function 不判断价格(){
    日志字串5 = 日志字串1+日志字串2+"选项关键字："+选项关键字符+"\n    截止时间："+分+":"+秒+"\n    延时："+延时+"\n";
    显示字串 ="/"+名称版本+"/\n\n"+日志字串2+选项关键字符+"\n截止时间："+分+":"+秒+"\n延        时："+延时+"\n";              //显示参数
    files.append(log, 日志字串5);                        //写入日志文件
    
    
    if(true){                    //捡漏部分
        toast("捡漏开始。。。");
    
        function 抢购(){
            textContains("客服").findOne();
            var 购买按钮=idContains("detail_main_sys_button").find()[1];
            if( 购买按钮.enabled()){
                购买按钮.click();
                成立控制=1;
            }else{
                back();
                return;
            }                   //判断点击购买
    
            if(true){           //有中间步骤-提交
                textContains("确定").findOne();
                descContains(选项关键字符).find().every(function(选项){
                    if(选项.desc().indexOf("不可选择") != -1){
                        return true;
                    }else{
                        选项.click();
                        return false;
                    }
                });
                idContains("confirm").findOne().click();

                for(;;){
                    for(;;){
                        textStartsWith("提交订单").findOne();
                        if (textContains("购买数量超过").findOnce()||textContains("商品不能购买").findOnce()) {
                            sleep(1300);
                            back();
                            idContains("confirm").findOne().click();
                            continue;
                        } else {
                            break;
                        }
                    }
                    textStartsWith("提交订单").findOne().click();
                    if(textContains("我知道了").findOne(500)){
                        textContains("我知道了").findOne().click();
                        back();
                        idContains("confirm").findOne().click();
                        continue;
                    }else{
                        break;
                    }
                }
                toast("抢购完成！！！");
            }
        }
        
      
        for(;;){
            var internetdDate = new Date(http.get("http://www.qq.com").headers["date"]); //把Date转换成时间对象
            var minute = internetdDate .getMinutes();
            var second = internetdDate .getSeconds();
            //print(minute+":"+second);
            if(minute>=分&&second>=30){    //！！时间控制！！！！
                break;
            }
    
            if(抢购位置)                    //判断返回
                textContains("个护").findOne();
            else
                descContains("全部宝贝").findOne();
            click(350,650);
            抢购(); 
            if(成立控制==1){
                break;
            }                               //判断结束
        }
    
        if(成立控制!=1){
            toast("   循环停止！\n\n开始整点捡漏！");
            toast("   循环停止！\n\n开始整点捡漏！");
            倒计时();
    
            for(var i=0;i<4;i++){
                click(350,650);
                抢购(); 
                if(成立控制==1){
                    break;
                }
                if(抢购位置)
                    textContains("个护").findOne();
                else
                    descContains("全部宝贝").findOne();   //判断返回
            }
        }
    
        files.append(log,"\n================================\n");
        if(成立控制==1){
            toast("捡漏结束！！！");
        }else{
            toast("没有机会了。。。");
        }
    }
}





if(价格判断==0){
    判断价格();
}

if(价格判断==1){
    不判断价格();
}