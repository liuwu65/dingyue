var 名称版本="购物车 2.9";
//少量调整

auto.waitFor();
var time = new Date(http.get("http://www.qq.com").headers["date"]);
var month = time.getMonth()+1;
var log = "/sdcard/脚本/日志"+month+"."+time.getDate()+".js";
files.create(log);          //创建日志文件

var 显示字串 = " ";
var 价格判断 = dialogs.select("是否判断价格？\n\n(返回退出脚本)\n","● 判断价格","● 不判断价格");if(价格判断==-1){toast("已停止！");exit();}
if(价格判断==0){
    var 理想价格 =dialogs.input("输入物品理想价格\n\n(返回退出脚本)", 50); if( 理想价格==null){toast("已停止！");exit();}
}
var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if(分==null){toast("已停止！");exit();}
var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if(秒==null){toast("已停止！");exit();}
var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if(延时==null){toast("已停止！");exit();}
var time = new Date(http.get("http://www.qq.com").headers["date"]);
var 日志字串1 = "\n================================\n"+time.getHours()+":"+time.getMinutes()+":"+time.getSeconds()+"\n    /----"+名称版本+"----/\n";






function 倒计时(){
    console.show();
    sleep(100);
    console.setPosition(400,400);
    console.setSize(730,900);
    console.info(显示字串+"\n脚本已运行！\n"+"最后一分钟开始计时！");
    sleep(1000);

    for(;;){                //获取时间、判断开始
        var internetdDate = new Date(http.get("http://www.qq.com").headers["date"]); //把Date转换成时间对象
        //var hour = internetdDate .getHours();
        var minute = internetdDate .getMinutes();
        var second = internetdDate .getSeconds();
        //print(minute+":"+second);
        if(minute>=分&&second>=秒){   //！！时间控制！！！！
            sleep(延时);//延迟时间
            break;
        }
        if(minute==分&&second<=秒-10){
            print(minute+":"+second);
            sleep(800);
        }
        if(minute==分&&second==秒-9){
            print(minute+":"+second);
            console.info("还有9秒");
            toast("还有9秒!\n请等待！");
            sleep(2000);
            toast("还有7秒!\n请等待！");
            console.hide();
            toast("还有5秒!\n马上开始！");
            toast("还有3秒!\n马上开始！");
        }
    }
    return;
}





function 判断价格(){
    var 抢购模式 = dialogs.select("购物车-价格判断\n\n请选择 抢购模式\n\n(返回退出脚本)\n","● 结算","● 刷新","● 捡漏");if(抢购模式==-1){toast("已停止！");exit();}

    if(抢购模式==0){var 日志字串4 ="抢购模式：结算模式\n"}
    if(抢购模式==1){var 日志字串4 ="抢购模式：刷新模式\n"}
    if(抢购模式==2){var 日志字串4 ="抢购模式：捡漏模式\n"}
    var 日志字串5 = 日志字串1+"判断价格！\n"+日志字串4+"    设定时间："+分+":"+秒+"\n    延时："+延时+"\n"+"    理想价格："+理想价格+"\n";
    显示字串 ="/----"+名称版本+"----/\n\n"+"判断价格！\n"+日志字串4+"开始时间："+分+":"+秒+"\n延        时："+延时+"\n"+"理想价格：￥ "+理想价格+"\n";                             //显示参数
    files.append(log, 日志字串5);                        //写入日志文件
    
    
    
    if(抢购模式==0){                                             //价格部分
        toast("抢购开始！！！");
        var 次数 = 0;
    
        倒计时();
        for(var i=0;i<4;i++){
            idContains("button_cart_charge").findOne().click();
            次数++;
            textContains("提交订单").findOne();
            if(textContains("商品不能").findOnce()){
                back();
                continue;         
            }                               //等待提交订单按钮及错误处理
        
            var 价格=textContains("合计").findOne().parent().findOne(textContains("￥")).text().replace('￥','');
            if(价格<理想价格){
                textContains("提交订单").findOne().click();//提交订单
                toast("抢购完成！！！");
                break;           //判断成立提交订单
            }else{
                back();          //判断不成立返回
            }
        }
        files.append(log,"    最后显示价格：￥ "+价格+"\n    进入次数统计："+次数+"\n===============================\n");//写入日志文件
        toast("抢购结束。。。");
        toast("可在当天日志文件中查看该次抢购相关参数！");
        toast("可在当天日志文件中查看该次抢购相关参数！");
        toast("可在当天日志文件中查看该次抢购相关参数！");
    }
    
    
    if(抢购模式==1){                                             //刷新部分
        toast("抢购开始！！！");
        var 次数 = 0;
        倒计时();
    
        for(var i=0;i<6;i++){
            swipe(540,150,540,800,320);
            次数++;
            text("购物车").boundsInside(0,0,540,200).findOne();
            var checkbox = classNameEndsWith("CheckBox").boundsInside(0,0,1080,800).findOne();
            if(checkbox.enabled()){
                checkbox.click();
                break;
            }
        }
    
        textContains("结算(").findOne();
        textContains("结算(").findOne().click();
        textStartsWith("提交订单").findOne();
        var 价格=textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥','');
        if(价格<理想价格){
            textStartsWith("提交订单").findOne().click();//提交订单
            toast("抢购完成！！！");
        }
        else
            toast("价格已变更！！！");
        //判断成立提交订单
        
        files.append(log,"    最后显示价格：￥ "+价格+"\n    刷新次数统计："+次数+"\n===============================\n");
          
        
        toast("可在当天日志文件中查看该次抢购相关参数！");
        toast("可在当天日志文件中查看该次抢购相关参数！");
        toast("可在当天日志文件中查看该次抢购相关参数！");
    }
    
    
    if(抢购模式==2){                                             //捡漏部分
        toast("捡漏开始！！！");
        var 次数 = 0;
    
        for(;;){
            idContains("button_cart_charge").findOne().click();
            textStartsWith("提交订单").findOne();
            var 价格=textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥','');
            if (价格>理想价格||textContains("购买数量超过").findOnce()||textContains("商品不能购买").findOnce()) {
                sleep(1100);
                back();
                continue;
            }
            textStartsWith("提交订单").findOne().click();
            if(textContains("我知道了").findOne(1000)){
                textContains("我知道了").findOne().click();
                back();
                continue;
            }else{
                break;
            }
            toast("捡漏成功！！！");
        }

        files.append(log,"    最后显示价格：￥ "+价格+"\n    进入次数统计："+次数+"\n================================\n");//写入日志文件
        toast("捡漏结束。。。");
        toast("可在当天日志文件中查看该次抢购相关参数！");
    }
}







function 不判断价格(){
    var 抢购模式 = dialogs.select("购物车-无价格判断\n\n请选择 抢购模式\n\n(返回退出脚本)\n","● 结算","● 刷新");if(抢购模式==-1){toast("已停止！");exit();}
    if(抢购模式==0){var 日志字串4 ="抢购模式：结算模式\n"}
    if(抢购模式==1){var 日志字串4 ="抢购模式：刷新模式\n"}
    if(抢购模式==2){var 日志字串4 ="抢购模式：捡漏模式\n"}
    var 日志字串5 = 日志字串1+"不判断价格！\n"+日志字串4+"    设定时间："+分+":"+秒+"\n    延时："+延时+"\n";
    显示字串 ="/----"+名称版本+"----/\n\n"+"不判断价格！\n"+日志字串4+"开始时间："+分+":"+秒+"\n延        时："+延时+"\n";                             //显示参数
    files.append(log, 日志字串5);                        //写入日志文件
    
    
    if(抢购模式==0){                                             //价格部分
        toast("抢购开始！！！");
        var 次数 = 0;
    
        倒计时();
        for(var i=0;i<4;i++){
            idContains("button_cart_charge").findOne().click();
            次数++;
            textContains("提交订单").findOne();
            if(textContains("商品不能").findOnce()){
                back();
                continue;         
            }                               
            textContains("提交订单").findOne().click();
            toast("抢购操作已完成！！！");
            break;
        }
        files.append(log,"    进入次数统计："+次数+"\n===============================\n");//写入日志文件
        toast("抢购结束。。。");
        toast("可在当天日志文件中查看该次抢购相关参数！");
        toast("可在当天日志文件中查看该次抢购相关参数！");
    }
    
    
    if(抢购模式==1){                                             //刷新部分
        toast("抢购开始！！！");
        var 次数 = 0;
        倒计时();
    
        for(var i=0;i<6;i++){
            swipe(540,150,540,800,320);
            次数++;
            text("购物车").boundsInside(0,0,540,200).findOne();
            var checkbox = classNameEndsWith("CheckBox").boundsInside(0,0,1080,800).findOne();
            if(checkbox.enabled()){
                checkbox.click();
                break;
            }
        }
    
        textContains("结算(").findOne();
        textContains("结算(").findOne().click();
        textContains("提交订单").findOne().click();
        toast("抢购操作已完成！！！");
        
        files.append(log,"    刷新次数统计："+次数+"\n================================\n");
        toast("可在当天日志文件中查看该次抢购相关参数！");
        toast("可在当天日志文件中查看该次抢购相关参数！");
    }
}


if(价格判断==0){
    判断价格();
}
if(价格判断==1){
    不判断价格();
}