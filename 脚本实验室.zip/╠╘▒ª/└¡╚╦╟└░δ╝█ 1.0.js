//拉人抢半价 1.0
//添加手动输入延时，完成循环刷新判断

auto.waitFor();
var t = 0;
var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 430); if(延时==null){toast("已停止！");exit();}//开始的分和秒
toast("抢购开始。。。");

for(;;){                //获取时间、判断开始
    var internetdDate = new Date(http.get("http://www.qq.com").headers["date"]); //把Date转换成时间对象
    //var hour = internetdDate .getHours();
    var minute = internetdDate .getMinutes();
    var second = internetdDate .getSeconds();
    //log(minute+":"+second);
    if(minute>=59&&second>=58){   //！！时间控制！！！！
        sleep(延时);//延迟时间
        break;
    }
    if(t==0&&minute==59&&second==30){
        t++;
        toast("还有30秒");
    }
    if(t==1&&minute==59&&second==48){
        t++;
        toast("还有10秒，马上开始");
    }                    //显示
}

for(;;){
    descContains("刷新").findOne().click();
    sleep(500);
    textContains("那***3").findOne();
    if(textContains("疯抢进行").findOnce()){
        break;
    }
}
click(865,1150);

toast("抢购结束。。。");
