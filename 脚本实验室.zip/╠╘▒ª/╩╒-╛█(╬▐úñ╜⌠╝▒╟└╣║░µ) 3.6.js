var 名称版本 = "收-聚(无￥紧急抢购版) 3.6";
//修改为不判断价格紧急版

auto.waitFor();
var time = new Date(http.get("http://www.qq.com").headers["date"]);
var month = time.getMonth()+1;
var log = "/sdcard/脚本/日志"+month+"."+time.getDate()+".js";
files.create(log);          //创建日志文件

var 显示字串 = " ";var 成立控制 = 0;var 次数 = 0;

var options = ["● 判断中间步骤  -  提交", "● 有中间步骤    -    提交","● 无中间步骤    -    提交","● 自动选择规格  -  提交"];
var 提交方式 = dialogs.select("提交", options); if(提交方式==-1){toast("已停止！");exit();}
var 分 = dialogs.input("分", 59); if(分==null){toast("已停止！");exit();}
var 秒 = dialogs.input("秒", 59); if(秒==null){toast("已停止！");exit();}
var 延时 = dialogs.input("延时", 5); if(延时==null){toast("已停止！");exit();}
var time = new Date(http.get("http://www.qq.com").headers["date"]);
var 日志字串1 = "\n================================\n"+time.getHours()+":"+time.getMinutes()+":"+time.getSeconds()+"\n    /----"+名称版本+"----/\n";
if(提交方式==0){var 日志字串4 ="提交方式：判断中间步骤\n"}
if(提交方式==1){var 日志字串4 ="提交方式：有中间步骤\n"}
if(提交方式==2){var 日志字串4 ="提交方式：无中间步骤\n"}
if(提交方式==3){var 日志字串4 ="提交方式：自动选择规格\n"}
var 日志字串5 = 日志字串1+"不判断价格！\n"+日志字串4+"    设定时间："+分+":"+秒+"\n    延时："+延时+"\n";
var 显示字串 ="/----"+名称版本+"----/\n\n"+"不判断价格！\n"+日志字串4+"开始时间："+分+":"+秒+"\n延        时："+延时+"\n";
files.append(log, 日志字串5);



function 倒计时(){
    console.show();
    sleep(100);
    console.setPosition(400,400);
    console.setSize(730,900);
    console.info(显示字串+"\n脚本已运行！\n"+"最后一分钟开始计时！");
    sleep(1000);

    for(;;){                //获取时间、判断开始
        var internetdDate = new Date(http.get("http://www.qq.com").headers["date"]); //把Date转换成时间对象
        //var hour = internetdDate .getHours();
        var minute = internetdDate .getMinutes();
        var second = internetdDate .getSeconds();
        //print(minute+":"+second);
        if(minute>=分&&second>=秒){   //！！时间控制！！！！
            sleep(延时);//延迟时间
            break;
        }
        if(minute==分&&second<=秒-10){
            print(minute+":"+second);
            sleep(800);
        }
        if(minute==分&&second==秒-9){
            print(minute+":"+second);
            console.info("还有9秒");
            toast("还有9秒!\n请等待！");
            sleep(2000);
            toast("还有7秒!\n请等待！");
            console.hide();
            toast("还有5秒!\n马上开始！");
            toast("还有3秒!\n马上开始！");
        }
    }
    return;
}



function 不判断价格抢购(){
    textContains("客服").findOne();
    var 购买按钮=idContains("detail_main_sys_button").find()[1];
    if( 购买按钮.enabled()){
        购买按钮.click();
        成立控制=1;
    }else{
        back();
        return;
    }                   //判断点击购买

    if(提交方式==0){           //判断中间步骤-提交
        var djkz = 0;
        for(;;){
            if(textContains("提交订单").findOnce()){
                textStartsWith("提交订单").findOne().click();
                toast("抢购完成！！！");
                break;
            }
            if(djkz==0&&idContains("confirm").findOnce()){
                idContains("confirm").findOne().click();
                djkz=1;
            }
        }
    }
    
    if(提交方式==1){           //有中间步骤-提交
        idContains("confirm").findOne().click();
        textStartsWith("提交订单").findOne().click();
        toast("抢购完成！！！");
    }

    if(提交方式==2){           //无中间步骤-提交
        textStartsWith("提交订单").findOne().click();
        toast("抢购完成！！！");
    }
    if(提交方式==3){           //自动选择规格-提交
        textContains("购买数量").findOne();
        idContains("sku_native_view_layout").findOne().children().forEach(function(类){
            类.children().forEach(function(类2){
                if(类2.className()=="android.widget.RelativeLayout"){
                    if(类2.childCount()==1){return;}
                    类2.children().every(function(项){
                        if(项.desc().indexOf("不可选择") != -1){
                            return true;
                        }else{
                            项.click();
                            return false;
                        }
                    });
                }
            });
        });                                 //自动选择规格操作

        idContains("confirm").findOne().click();
        textStartsWith("提交订单").findOne().click();
        toast("抢购完成！！！");
    }
}



toast("抢购开始。。。");    
倒计时();
for(var i=0;i<6;i++){
    click(350,650);
    次数++;
    不判断价格抢购(); 
    if(成立控制==1){
        break;
    }                   //判断结束
    descContains("全部宝贝").findOne();
}
files.append(log,"    进入次数统计："+次数+"\n================================\n");
if(成立控制==1){
    toast("抢购结束！！！");
}else{
    toast("来晚啦！！！");
}