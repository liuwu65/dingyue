//积分兑换 2.0.js
//合并三种情况
auto.waitFor();

var 使用位置 = dialogs.select("请选择 使用位置\n\n(返回退出脚本)", "● 积分兑换-店铺会员", "● 积分兑换-更多", "● 积分兑换-链接", "● 专享礼券"); if(使用位置==-1){toast("已停止！");exit();}
var 商品部分名称 = dialogs.rawInput("商品部分名称",""); if(商品部分名称==null){toast("已停止！");exit();}
var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if(分==null){toast("已停止！");exit();}
var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if(秒==null){toast("已停止！");exit();}
var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if(延时==null){toast("已停止！");exit();}



function 倒计时(){
    console.show();
    sleep(100);
    console.setPosition(400,400);
    console.setSize(730,900);
    console.info("\n脚本已运行！\n"+"最后一分钟开始计时！");
    sleep(1000);

    for(;;){                //获取时间、判断开始
        var internetdDate = new Date(http.get("http://www.qq.com").headers["date"]); 
        var minute = internetdDate .getMinutes();
        var second = internetdDate .getSeconds();
        //print(minute+":"+second);
        if(minute>=分&&second>=秒){
            sleep(延时);//延迟时间
            break;
        }
        if(minute==分&&second<=秒-10){
            print(minute+":"+second);
            sleep(700);
        }
        if(minute==分&&second==秒-9){
            print(minute+":"+second);
            console.info("还有9秒");
            toast("还有9秒!\n请等待！");
            sleep(2000);
            toast("还有7秒!\n请等待！");
            console.hide();
            toast("还有5秒!\n马上开始！");
            toast("还有3秒!\n马上开始！");
        }
    }
    return;
}






if(使用位置==0){
    倒计时();

    for(var i=0;i<10;i++){
        var 名称位置=textContains(商品部分名称).findOne().bounds();
        click(名称位置.centerX(), 名称位置.centerY());
        for(;;){
            var 兑换存在=textContains("会员专享权益").findOne().parent().parent().find(text("立即兑换")).nonEmpty();
            if(兑换存在){
                textContains("会员专享权益").findOne().parent().parent().findOne(text("立即兑换")).parent().click();
                text("确定").findOne().click();
                toast("成功！");
                toast("脚本已结束！");
                exit();
            }
    
            var 即将存在=textContains("会员专享权益").findOne().parent().parent().find(text("即将开始")).nonEmpty();
            if(即将存在){
                var 返回位置=textContains("会员专享权益").findOne().bounds();
                click(返回位置.centerX(),返回位置.centerY());
                for(;;){
                    if(!text("会员专享权益").findOnce()){
                        break;
                    }
                }
                break;
            }
    
            if(text("已抢光").findOnce()){
                toast("已抢光！");
                exit();
            }
        }
    }
}




if(使用位置==1){
    倒计时();

    for (var i=0;i<10;i++) {
        textContains(商品部分名称).findOne().parent().parent().click();
        textContains("向您推荐以下商品").findOne();
        for (; ;) {
            if (textContains("立即兑换").findOnce()) {
                textContains("立即兑换").findOne().click();
                text("确定").findOne().click();
                textContains("客服").findOne();
                var 购买按钮=idContains("detail_main_sys_button").find()[1];
                购买按钮.click();
                textStartsWith("提交订单").findOne().click();
                toast("成功！");
                toast("脚本已结束！");
                exit();
            }
            if (textContains("即将开始").findOnce()) {
                back();
                textContains("我的积分").findOne();
                break;
            }
            if (textContains("已抢光").findOnce()) {
                toast("已抢光！");
                exit();
            }
        }
    }
}




if(使用位置==2){
    倒计时();

    for (var i=0;i<50;i++) {
        descContains(商品部分名称).findOne().parent().parent().parent().click();
        textContains("向您推荐以下商品").findOne();
        for (; ;) {
            if (text("立即兑换").findOnce()) {
                text("立即兑换").findOne().click();
                text("确定").findOne().click();
                textContains("客服").findOne();
                var 购买按钮=idContains("detail_main_sys_button").find()[1];
                购买按钮.click();
                textStartsWith("提交订单").findOne().click();
                toast("成功！");
                toast("脚本已结束！");
                exit();
            }
            if (text("即将开始").findOnce()) {
                back();
                idContains("input").findOne();
                break;
            }
            if (textContains("已抢光").findOnce()) {
                toast("已抢光！");
                toast("脚本已结束！");
                exit();
            }
        }
    }
}




if(使用位置==3){
    倒计时();

    for(var i=0;i<10;i++){
        var 名称位置=textContains(商品部分名称).findOne().bounds();
        click(名称位置.centerX(), 名称位置.centerY());
        for(;;){
            var 领取存在=textContains("会员专享权益").findOne().parent().parent().find(text("立即领取")).nonEmpty();
            if(领取存在){
                textContains("会员专享权益").findOne().parent().parent().findOne(text("立即领取")).parent().click();
                text("确定").findOne().click();
                toast("成功！");
                toast("脚本已结束！");
                exit();
            }
            var 即将存在=textContains("会员专享权益").findOne().parent().parent().find(text("即将开始")).nonEmpty();
            if(即将存在){
                var 返回位置=textContains("会员专享权益").findOne().bounds();
                click(返回位置.centerX(),返回位置.centerY());
                for(;;){
                    if(!text("会员专享权益").findOnce()){
                        break;
                    }
                }
                break;
            }
            if(text("已抢光").findOnce()){
                toast("已抢光！");
                toast("脚本已结束！");
                exit();
            }
        }
    }  
}




toast("由于循环执行10次，脚本已结束！");
