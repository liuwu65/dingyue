//群助手 2.0
//合并打卡与评论功能，解决火爆问题，解决速度过快的一些bug
auto.waitFor();

var i = dialogs.select("请选择群助手功能\n\n(返回退出)", "● 打卡", "● 评论"); if(i==-1){toast("已停止！");exit();}

if(i==0){                  //打卡
    var j = 0;
    var k = 0;
    var t = new Date(http.get("http://www.qq.com").headers["date"]);
    var month = t.getMonth()+1;
    var log = "/sdcard/脚本/日志"+month+"."+t.getDate()+".js";
    files.create(log);          //创建日志文件
    
    function 打卡(){
        for(var i=1;i<20;i++){
            if(descContains("签到赢宝箱").findOnce()){
                break;
            }
            sleep(200);
            if(i%9==0){
                swipe(700, 1500, 700, 1000, 400);
                continue;
            }               //打卡入口不出现的滑动处理
            if(i>=19){
                toast("该店铺没有打卡活动，请在日志中查看！");
                var t = new Date(http.get("http://www.qq.com").headers["date"]);
                var b = "\n"+t.getHours()+":"+t.getMinutes()+":"+t.getSeconds()+"\n";
                files.append(log,b+"该店铺打卡活动不存在："+店名);//写入日志文件
                j++;
                back();
                return;
            }               //没有打卡活动的店铺判断与记录
        }                   //等待进入1
        descContains("签到赢宝箱").findOne().parent().parent().click();
        sleep(500);
        if(textContains("太火爆了").findOnce()){
            toast("太火爆了");
            back();sleep(400);back();
            return;
        }
        textContains("连续").findOne();             //等待进入打卡页面
        if(textContains("今日已签").findOnce()){
            toast("已经签到过了");
            back();sleep(400);back();
            return;
        }                   //判断是否已到成功
        if(textContains("已完成").findOnce()){
            toast("该店铺已经完成，请在日志中查看店铺名称！");
            var t = new Date(http.get("http://www.qq.com").headers["date"]);
            var b = "\n"+t.getHours()+":"+t.getMinutes()+":"+t.getSeconds()+"\n";
            files.append(log, b+"打卡已完成店铺："+店名);//写入日志文件
            k++;
            back();sleep(400);back();
            return;
        }                   //判断是否已到成功并记录
        textContains("立即签到").findOne().click();
        sleep(1500);
        for(;;){
            if(textContains("马上抽奖").findOnce()){
                for(;;){
                    toast("可以开始抽奖啦1");
                    sleep(2300);
                }
            }               //判断是否有抽奖
            if(textContains("今日已签").findOnce()){
                toast("签到成功");
                back();sleep(400);back();
                break;
            }
        }                   //判断是否签到成功
    }
    
    for(;;){
        if(idContains("sp_content_img").boundsInside(50,160,1060,600).findOnce()){
            var 店名=idContains("sp_content_img").boundsInside(50,160,1060,600).findOnce().parent().child(0).text();
            idContains("sp_content_img").boundsInside(50,160,1060,600).findOnce().parent().parent().parent().parent().click();
            打卡();
        }                   //在范围寻找打卡控件并记录店名
        descContains("语音").findOne();sleep(300);
        swipe(540,1400,540,1000,300);sleep(600);
        if(textContains("123456").boundsInside(0,100,1080,600).findOnce()){
            files.append(log, "\n"+"此次打卡已完成！"+"\n"+"================================"+"\n");
            break;
        }
    }
    
    for(;;){
        toast("打卡任务已完成！");
        sleep(2000);
        if(j){
            toast("有"+j+"个店铺没有打卡活动！");
            sleep(2000);
        }
        if(k){
            toast("有"+k+"个店铺打卡活动已完成！");
            sleep(2000);
        }
        toast("请在日志中查看！");
        sleep(2000);
    }
}

if(i==1){           //评论
    var h = device.height;
    var 内容 = ["打卡打卡","来啦来啦","支持支持","希望好运","祝大卖"];
    
    function 评论(){
        sleep(3000);
        click(280,h-170);
        sleep(1500);
        editable().findOne().setText(内容[random(0, 内容.length-1)]);
        sleep(500);
        click(970,h-170);
        sleep(1000);
        back();
        sleep(400);
        back();
    }
    
    for(;;){
        if(descContains("这个分享不错").boundsInside(50,230,1060,600).findOnce()){
            descContains("这个分享不错").boundsInside(50,230,1060,600).findOnce().parent().parent().parent().click();
            评论();
        }                   //在范围寻找打卡控件并记录店名
        descContains("语音").findOne();
        swipe(540,1400,540,1000,300);sleep(500);
        if(textContains("123456").boundsInside(0,130,1080,500).findOnce()){
            toast("评论已完成");
            break;
        }
    }    
}
