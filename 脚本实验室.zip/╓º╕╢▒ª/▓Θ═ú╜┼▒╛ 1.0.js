//停止脚本 1.0
auto.waitFor();

var 运行的脚本 = [''];

for(var i=0;i<engines.all().length;i++){
    var t=(""+engines.all()[i].source).replace('/storage/emulated/0/','');
    运行的脚本[i] = t;

}

var 操作脚本 = dialogs.multiChoice(
    "请选择要结束的脚本",
    运行的脚本
);

for(var i=0;i<操作脚本.length;i++){
    engines.all()[操作脚本[i]].forceStop();
    toast(运行的脚本[操作脚本[i]]+":已停止！");
}

