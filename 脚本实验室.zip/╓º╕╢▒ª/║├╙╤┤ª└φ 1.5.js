//支付宝好友 1.5
//少量修改
auto.waitFor();

var 功能 = dialogs.select("请选择 功能\n\n(返回退出脚本)", "● 群列加好友", "● 合列加好友", "● Q 吱加好友", "● 友列加前缀", "● 处理森列前缀", "● xqe好友分析前缀", "● Q列发消息"); if (功能 == -1) { toast("已停止！"); exit(); }


if(功能==0){
    var times = 0;

    function 加好友(){
        textContains("转账").findOne();
        for(;;){
            if(textContains("发消息").findOnce()){
                back();
                textContains("群聊成员").findOne();
                return;
            }
            if(textContains("加好友").findOnce()){
                break;
            }
        }                               //判断是否是好友
        textContains("加好友").findOne().click();
        for(;;){
            if(textContains("今天已经发送").findOne(300)){
                toast("今日加好友已达上限！");
                exit();
            }
            if(textContains("发消息").findOnce()){
                back();
                times++;
                return;
            }
            if(textContains("发送").findOnce()){
                break;
            }
        }                               //判断是否已达加好友上限
        setText(0," ");
        textContains("发送").findOne().click();
        textContains("请求已发送").findOne();
        back();
        textContains("群聊成员").findOne();
        times++;
    }
    
    for(;;){
        click(200,400);
        加好友();
        sleep(200);
        swipe(540,965,540,800,200);
        sleep(200);
        if(times>33){
            break;
        }
    }
}



if(功能==1){
    var times = 0;

    function 加好友(){
        for(;;){
            if(textContains("TA收取你").findOnce()||textContains("种树").findOnce()){
                back();
                text("蚂蚁森林").findOne();
                return;
            }
            if(textContains("加为好友").findOnce()){
                break;
            }
        }                               //判断是否是好友
        textContains("加为好友").findOne().click();
        textContains("加好友").findOne().click();
        for(;;){
            if(textContains("明天再来").findOne(300)){
                toast("今日加好友已达上限！");
                exit();
            }
            if(textContains("发送").findOnce()){
                break;
            }
        }                               //判断是否已达加好友上限
        setText(0," ");
        textContains("发送").findOne().click();
        textContains("请求已发送").findOne();
        back();
        textContains("加为好友").findOne();
        back();
        text("蚂蚁森林").findOne();
        times++;
    }
    
    for(;;){
        click(200,400);
        加好友();
        sleep(500);
        swipe(540,987,540,800,200);
        sleep(500);
        if(times>33){
            break;
        }
    }    
}



if(功能==2){
    var 口令1 = new Array;
    var 口令2 = new Array;
    var number = 0;
    
    for (; ;) {
        textContains("吱口令").find().forEach(function (口令文本) {
            口令1[number] = 口令文本.text().replace(/[^0-9a-zA-z]/g,'');
            number++;
        })
        //break;
        swipe(540, 310, 540, 1800, 200);
        if (textContains("昨天").findOnce()) {
            break;
        }
    }
    
    for (var i = 0; i < 口令1.length; i++){
        for(var j = i+1; j < 口令1.length; j++){
            if(口令1[i]==口令1[j]||口令1[i].length>11){
                口令1[i]=null;
                break;
            }
        }
    }
    
    number = 0;
    for(var i = 0; i < 口令1.length; i++){
        if(口令1[i]){
            口令2[number]=口令1[i];
            number++;
        }
    }
    log(口令2);
    
    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=20000001"
    });
    text("首页").findOne();
    idContains("search_button").findOne().click();      //进入
    
    for(var i = 0;i<口令2.length;i++){
        text("搜索").findOne();
        setText(0,口令2[i]);
        idContains("search_confirm").findOne().click();
        text("吱口令解析").findOne();
        if(textContains("查看信息").findOnce()){
            continue;
        }
        click(500,540);
        for(;;){
            if(textContains("朋友验证").findOnce()){
                setText(0," ");
                sleep(500);
                textContains("发送").findOne().click();
                break;
            }
            if(textContains("发消息").findOnce()){
                back();
                break;
            }
            if(textContains("今天已经发送太多").findOne(300)){
                toast("今日加好友已达上限！");
                exit();
            }
        }
    }    
}



if(功能==3){
    for(var i = 0;i<130;i++){
        press(210,1050, 800);
        textContains("设置备注").findOne().parent().click();
        textContains("备注名").findOne();
        if(textStartsWith("(").findOne(300)){
            back();
            toast("修改完成!");
            toast("修改完成!");
            break;
        }
        var name =textContains("备注名").findOne().parent().child(1).text();
        setText(0,"(1)"+name);
        sleep(600);
        textContains("完成").findOne().click();
        textContains("通讯录").findOne().click();
        sleep(400);
    }
}




if(功能==4){
    function 处理前缀(){
        textContains("收取你").findOne();

        if(textContains("(1)").boundsInside(0,0,1080,400).findOne(300)||textContains("(2)").boundsInside(0,0,1080,400).findOne(300)){

            if(textContains("(1)").boundsInside(0,0,1080,400).findOne(200)){
                var 收取 = textContains("你收取").findOne().parent().findOne(textContains("g")).text().replace('g','');
                if(收取<1){                 //删除
                    if (是否删1){
                        textContains("我的大树养成").findOne().click();
                        sleep(200);
                        desc("设置").findOne().click();
                        sleep(200);
                        textContains("删除").findOne().click();
                        sleep(200);
                        idContains("ensure").findOne().click();
                        textContains("我的大树养成").findOne();
                    }
                    back();
                    text("蚂蚁森林").findOne();
                    sleep(200);
                }else{                      //重命名
                    textContains("我的大树养成").findOne().click();
                    sleep(200);
                    desc("设置").findOne().click();
                    sleep(200);
                    idContains("set_remarkName").findOne().click();
                    var name =textContains("备注名").findOne().parent().child(1).text().replace('(1)','');
                    setText(0,"(2)"+name);
                    sleep(800);
                    textContains("完成").findOne().click();
                    idContains("set_remarkName").findOne();
                    sleep(200);
                    back();
                    sleep(200);
                    textContains("发消息").findOne();
                    sleep(200);
                    back();
                    textContains("我的大树养成").findOne();
                    back();
                    text("蚂蚁森林").findOne();
                    sleep(200);
                }
            }
    
    
            if(textContains("(2)").boundsInside(0,0,1080,400).findOne(200)){
                if(是否降2){
                    var 收取 = textContains("你收取").findOne().parent().findOne(textContains("g")).text().replace('g','');
                    if(收取<1){                      //重命名
                        textContains("我的大树养成").findOne().click();
                        sleep(200);
                        desc("设置").findOne().click();
                        sleep(200);
                        idContains("set_remarkName").findOne().click();
                        var name =textContains("备注名").findOne().parent().child(1).text().replace('(2)','');
                        setText(0,"(1)"+name);
                        sleep(800);
                        textContains("完成").findOne().click();
                        idContains("set_remarkName").findOne();
                        sleep(200);
                        back();
                        sleep(200);
                        textContains("发消息").findOne();
                        sleep(200);
                        back();
                        textContains("我的大树养成").findOne();
                        back();
                        text("蚂蚁森林").findOne();
                        sleep(200);
                    }else{
                        back();
                        text("蚂蚁森林").findOne();
                        sleep(200); 
                    }
                }else{
                    back();
                    text("蚂蚁森林").findOne();
                    sleep(200); 
                }
            }
        }else{
            back();
            text("蚂蚁森林").findOne();
            sleep(200); 
        } 
    }
    

    var 是否删1 = dialogs.select("请选择 是否删除无偷(1)\n\n(返回退出脚本)", "● 否", "● 是"); if (是否删1 == -1) { toast("已停止！"); exit(); }
    var 是否降2 = dialogs.select("请选择 是否降低无偷(2)\n\n(返回退出脚本)", "● 否", "● 是"); if (是否降2 == -1) { toast("已停止！"); exit(); }

    for(var i=0;i<500;i++){
        click(170,450);
        sleep(200);
        处理前缀();
        sleep(200);
        swipe(520,1020,520,800,200);
        if(textContains("没有更多了").boundsInside(0,1700,1080,1800).findOnce()){
            break;
        }
        sleep(200);
    }
}





if(功能==5){
    function 二(){
        textContains("查看森林").findOne().click();
        if(text("打开").findOne(300)){
            text("打开").findOne().click();
        }
        textContains("我的大树养成").findOne().click();
        sleep(200);
        desc("设置").findOne().click();
        sleep(200);
        idContains("set_remarkName").findOne().click();
        textContains("备注名").findOne();
        if(textContains("(2)").findOnce()){
            click(740,1870);
            textContains("XQuick").findOne().parent().parent().click();
            textContains("输入查找").findOne();
            return;
        }
        var name =textContains("备注名").findOne().parent().child(1).text().replace('(1)','');
        setText(0,"(2)"+name);
        sleep(800);
        textContains("完成").findOne().click();
        idContains("set_remarkName").findOne();
        click(740,1870);
        textContains("XQuick").findOne().parent().parent().click();
        textContains("输入查找").findOne();
    }
    
    
    for(;;){
        textContains("(1)").find().forEach(function(一){
            一.parent().longClick();
            二();
            sleep(200);
        })
        if(textContains("730. (").findOnce()){
            toast("结束！");
            break;
        }
        swipe(540,1460,540,300,200);
        sleep(200);
    }
}


if(功能==6){
    var 消息数 = dialogs.select("请选择 发送消息间隔数", "19", "49");  if (消息数 == -1) { toast("已停止！"); exit(); }
    if (消息数 == 0) {消息数 = 19;}
    if (消息数 == 1) {消息数 = 49;}
    log(消息数);
    for(;;){
        idContains("unreadmsg").find().forEach(function(未读数){
            if(未读数.text()>=消息数||未读数.text()=="99+"){
                未读数.parent().parent().parent().click();
                idContains("input").findOne();
                sleep(100);
                setText("Inly32H56Rm复制吱口令，打开支付宝搜索，即可添加我为好友");
                text("发送").findOne().click();
                back();
                text("群助手").findOne();
                sleep(100);
            }
        });
        sleep(500);
        if(text("设为置顶").findOnce()){
            toast("发送脚本结束！");
            toast("发送脚本结束！");
            break;
        }
    }
}