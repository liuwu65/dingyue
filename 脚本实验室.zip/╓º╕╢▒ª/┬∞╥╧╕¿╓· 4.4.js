//蚂蚁辅助 4.3.js
//少量修改
auto.waitFor();
if (!requestScreenCapture()) {
    toast("请求截图失败");
    exit();
}

var 账号 = [
    "54mtk304@t.odmail.cn",
    "656565651@t.odmail.cn",
    "656565652@t.odmail.cn",
    "656565653@t.odmail.cn",
    "656565654@t.odmail.cn",
    "656565655@t.odmail.cn",
    "656565656@t.odmail.cn",
    //"656565657@t.odmail.cn",
    //"656565658@t.odmail.cn",
    "656565659@t.odmail.cn",
    "6565656510@t.odmail.cn",
    "6565656511@t.odmail.cn",
    "6565656512@t.odmail.cn",
    "6565656513@t.odmail.cn",
    "6565656514@t.odmail.cn",
    "lw0165656565@163.com",
    "hpp0165@163.com",
    "hpp0265@163.com",
    //"hpp0365@163.com",
    //"hpp0465@163.com",
    //"hpp0565@163.com",
    "15281718257",
    "13158507242",
    "18873208031",
    "511303a22tm.cdb@sina.cn",
    "13788131465",
    "18873292759"
];

var 密码 = [
    "123456lw,",
    "123456lw,",
    "123456lw,",
    "123456lw,",
    "123456lw,",
    "123456lw,",
    "123456lw,",
    "123456lw,",
    "123456lw,",
    "123456lw,",
    "123456lw,",
    "123456lw,",
    "123456lw,",
    "123456lw,",
    "123456lw,",
    "123456lw,",
    //"123456lw,",
    //"123456lw,",
    //"123456lw,",
    //"123456lw,",
    //"123456lw,",
    "123456lw,",
    "123456lw,",
    "1997qq",
    "980118lw,",
    "199771qq",
    "980118lw,"
];

var 书名 = "春";
var 功能 = dialogs.select("请选择 功能\n\n(返回退出脚本)", "● 收能量(单账号)", "● 半自动切号", "● 自动定时切号", "● 自动浇水", "● 自动阅读", "● 步数同步"); if (功能 == -1) { toast("已停止！"); exit(); }

var 默认选择项 = [''];
for (var i = 0; i < 账号.length; i++) {
    默认选择项[i] = i;
}





if (功能 == 0) {                                //收能量
    var h0 = 0; var m0 = 00; var h1 = 24; var m1 = 60;
    var 手 = images.read("/sdcard/脚本/支付宝/手.jpg");
    var 爱心 = images.read("/sdcard/脚本/支付宝/爱心.jpg");
    var 没有更多 = images.read("/sdcard/脚本/支付宝/没有更多.jpg");
    var 能量模式 = dialogs.select("请选择 运行模式\n\n(返回退出脚本)", "● 普通模式", "● 定时收取"); if (能量模式 == -1) { toast("已停止！"); exit(); }


    function 收能量() {                   //收能量
        text("成就").findOne();
        for (var i = 0; i < 3; i++) {                       //弹窗处理
            if (idContains("J_pop_treedialog_close").findOnce()) {
                idContains("J_pop_treedialog_close").findOne().click();
            }
            sleep(500);
        }
        textContains("成就").findOne().parent().children().forEach(function (能量球) {
            var 范围 = 能量球.bounds();
            if (范围.centerY() < 450 || 能量球.text() == "成就" || 能量球.text() == "浇水" || 能量球.text() == "弹幕" || 能量球.text() == "发消息" || 能量球.text() == "公益林" || 能量球.text() == "通知" || 能量球.text() == "背包" || 能量球.text() == "通知" || 能量球.text() == "任务" || 能量球.text() == "攻略") { return; }
            click(范围.centerX(), 范围.centerY());
        })
        toast("已收取");
        if (text("种树").findOne(300)) {
            return;
        } else {
            back();
            text("蚂蚁森林").findOne();
        }
    }


    function 找手() {                          //寻找可偷的好友
        for (; ;) {
            var img = captureScreen();
            var point = (findImage(img, 手, { region: [900, 200, 180, 1720], threshold: 0.7 })/*||findImage(img, 爱心, {region: [900,200,180,1720],threshold: 0.7})*/);
            if (point) {
                click(point.x - 10, point.y + 10);
                收能量();
                kz++;
                sleep(300);
            } else {
                swipe(700, 1700, 700, 500, 100);
                sleep(300);
            }
            if (textContains("没有更多了").boundsInside(0, 1700, 1080, 1800).findOnce()) {
                break;
            }
        }
    }


    function 进入() {
        app.startActivity({
            action: "VIEW",
            data: "alipays://platformapi/startapp?appId=60000002"
        });
        if (text("使用密码").findOne(1000)) {         //应用锁
            click(540, 1560); sleep(500);
            text("0").findOne().click(); sleep(200);
            text("5").findOne().click(); sleep(200);
            text("2").findOne().click(); sleep(200);
            text("5").findOne().click(); sleep(200);
        }
        sleep(500);
        text("种树").findOne();
        sleep(3000);
    }


    function 唤醒() {
        if (!device.isScreenOn()) {
            device.wakeUp();
            sleep(500);
            swipe(540, 1400, 540, 400, 300); sleep(500);
            click(540, 1770); sleep(200);
            click(540, 1330); sleep(200);
            click(540, 1100); sleep(200);
            click(540, 1330); sleep(200);
        }
    }


    if (能量模式 == 1) {                                //定时
        h0 = rawInput("输入开始时间-小时\n\n(返回退出脚本)", 6); if (h0 == null) { toast("已停止！"); exit(); }
        m0 = rawInput("输入开始时间-分\n\n(返回退出脚本)", 58); if (m0 == null) { toast("已停止！"); exit(); }
        h1 = rawInput("输入结束时间-小时\n\n(返回退出脚本)", 7); if (h1 == null) { toast("已停止！"); exit(); }
        m1 = rawInput("输入结束时间-分\n\n(返回退出脚本)", 40); if (m1 == null) { toast("已停止！"); exit(); }
        if (!confirm("确定时间\n" + "开始时间：" + h0 + ":" + m0 + "\n结束时间：" + h1 + ":" + m1)) {
            toast("请重新运行以设定时间！");
            exit();
        }
        toast("定时任务已开启！");
        for (; ;) {
            var internetdDate = new Date(http.get("http://www.qq.com").headers["date"]);
            var hour = internetdDate.getHours();
            var minute = internetdDate.getMinutes();
            if (hour >= h0 && minute >= m0) {
                唤醒();
                进入();
                break;
            }
            sleep(50000);
        }
    }
    else {
        进入();
    }


    for (; ;) {                //主程序
        var internetdDate = new Date(http.get("http://www.qq.com").headers["date"]);
        var hour = internetdDate.getHours();
        var minute = internetdDate.getMinutes();
        if (hour >= h1 && minute >= m1) {
            toast("定时任务已结束！");
            break;
        }
        收能量();
        toast("自己能量已收取！");
        sleep(500);
        text("查看更多好友").findOnce().click();
        sleep(1000);
        找手();
        sleep(500);
        back();
        sleep(500);
    }
}








if (功能 == 5) {
    var 获取步数 = dialogs.select("请选择 是否获取前一天步数\n\n(返回退出脚本)", "● 否", "● 是"); if (获取步数 == -1) { toast("已停止！"); exit(); }

    var 操作账号 = dialogs.multiChoice(
        "请选择账号",
        账号,
        默认选择项
    );

    if (获取步数) {
        app.launchApp("设置");
        text("电池").findOne();
        swipe(540, 1600, 540, 200, 200);
        sleep(200);
        swipe(540, 1600, 540, 200, 200);
        sleep(200);
        swipe(540, 1600, 540, 200, 200);
        sleep(200);
        text("系统").findOne().parent().parent().click();
        text("日期和时间").findOne().parent().parent().parent().click();
        var 开关1 = text("自动确定时区").findOne().parent().parent().child(2).child(0).bounds();
        click(开关1.centerX(), 开关1.centerY());
        text("时区").findOne().parent().parent().click();
        setText("-11");
        textContains("美国").findOne().parent().click();
        app.launchApp("运动健康");
        textContains("今日活动量").findOne();
        sleep(3000);
        swipe(540, 300, 540, 1800, 1000);
        sleep(3000);
        app.launchApp("设置");
        text("电池").findOne();
        swipe(540, 1600, 540, 200, 200);
        sleep(200);
        swipe(540, 1600, 540, 200, 200);
        sleep(200);
        swipe(540, 1600, 540, 200, 200);
        sleep(200);
        text("系统").findOne().parent().parent().click();
        text("日期和时间").findOne().parent().parent().parent().click();
        var 开关1 = text("自动确定时区").findOne().parent().parent().child(2).child(0).bounds();
        click(开关1.centerX(), 开关1.centerY());
    }
    app.launchApp("运动健康");
    textContains("今日活动量").findOne();
    sleep(3000);
    swipe(540, 300, 540, 1800, 1000);
    sleep(3000);

    for (var 同步 = 0; 同步 < 操作账号.length; 同步++) {
        text("我的").findOne().parent().parent().click();
        sleep(200);
        textContains("数据共享").findOne().parent().parent().click();
        sleep(200);
        idContains("layout_alisport").findOne().click();
        sleep(200);
        idContains("aliSport_button_cancel_connect").findOne().click();
        sleep(200);
        idContains("dialog_no_title_btn_positive").findOne().click();
        sleep(200);
        textContains("绑定支付宝运动").findOne().click();
        sleep(200);
        textContains("登录").findOne();
        sleep(1000);
        setText(0, 账号[操作账号[同步]]);
        setText(1, 密码[操作账号[同步]]);
        sleep(1500);
        click(540, 1200);
        textContains("确认授权").findOne();
        click(540, 1100);
        textContains("绑定成功").findOne();
        back();
        textContains("数据共享").findOne();
        back();
        text("我的").findOne();
        idContains("user_profile_health_settings_layout").findOne().click();
        sleep(200);
        idContains("download_button").findOne().click();
        sleep(500);
        if (textContains("确定").findOne(2000)) {
            textContains("确定").findOne().click();
        }
        sleep(3500);
        back();

    }
    toast("所有账号已同步完成！！！");
    toast("所有账号已同步完成！！！");
    toast("所有账号已同步完成！！！");
}








if (功能 > 0 && 功能 < 5) {
    function 退换账号() {
        if (功能 == 1) {
            toast("需要换账号时，\n进入设置界面自动切换！");
            text("换账号登录").findOne();
        }

        if (功能 == 2 || 功能 == 3 || 功能 == 4) {
            if (功能 == 2) {
                for (var j = 0; ; j++) {
                    if (i == 0)
                        break;
                    sleep(1000);
                    if ((间隔 - j) <= 0)
                        break;
                    if ((间隔 - j) % 5 == 0)
                        toast("还剩" + (间隔 - j) + "秒切换！");
                }
            }
            text("我的").findOne().parent().click();
            sleep(1000);
            idContains("right_container_2").findOne().click();
            sleep(1000);
        }
        text("换账号登录").findOne();
        sleep(200);
        text("换账号登录").boundsInside(0, 1360, 1080, 1900).findOne().parent().parent().parent().parent().click();
        sleep(200);
        idContains("otherAccountSwitcher").findOne().click();
        sleep(200);
        for(;;){
            if(className("android.widget.EditText").findOnce()){
                break;
            }
            if(textContains("等待").findOnce()){
                textContains("等待").findOne().click();
            }
        }
        sleep(200);
        setText(0, 账号[操作账号[i]]);
        sleep(200);
        idContains("nextButton").findOne().click();
        for (; ;) {
            if (text("密码").findOne(5000)) {
                break;
            }
            if (text("换个方式登录").findOnce()) {
                text("换个方式登录").findOne().click();
                text("密码登录").findOne().parent().click();
                break;
            }
        }
        sleep(200);
        text("密码").findOne();
        sleep(200);
        setText(1, 密码[操作账号[i]]);
        sleep(200);
        idContains("loginButton").findOne().click();
        if (账号[操作账号[i]] == "18873292759") {
            var t = files.read("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json1");
            files.write("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json", t);
        }
        else if(账号[操作账号[i]] == "13788131465")
        {
            var t = files.read("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json2");
            files.write("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json", t);
        }else{
            var t = files.read("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json3");
            files.write("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json", t);
        }
        sleep(200);
        text("首页").findOne();
        toast("登录成功！");
        sleep(1000);
    }


    function 浇水() {
        toast("开始浇水！");
        text("首页").findOne().parent().click();
        sleep(200);
        text("蚂蚁森林").findOne().parent().parent().click();
        sleep(200);
        text("种树").findOne();
        sleep(200);
        text("八九").findOne().parent().parent().click();
        sleep(200);
        for (var i = 0; i < 3; i++) {
            var 浇水控件 = text("浇水").findOne().bounds();
            click(浇水控件.centerX(), 浇水控件.centerY());
            sleep(200);
            if (textContains("请选择为").findOne(5000)) {
                sleep(1000);
                click(950, 1400);
                sleep(1000);
                text("浇水送祝福").findOne().click();
                sleep(4000);
            } else {
                toast("已经浇过了！")
                back();
                sleep(200);
                textContains("种树").findOne();
                sleep(200);
                back();
                sleep(200);
                text("首页").findOne();
                return;
            }
        }
        toast("浇水成功！");
        back();
        sleep(200);
        textContains("种树").findOne();
        sleep(200);
        back();
        sleep(200);
        text("首页").findOne();
    }



    function 阅读() {
        var 刷数 = 35;
        var 下一章 = images.read("/sdcard/脚本/支付宝/下一章.jpg");
        toast("开始阅读！");
    
        text("首页").findOne().parent().click();
        sleep(2000);
        app.startActivity({
            action: "VIEW",
            data: "alipays://platformapi/startapp?appId=2018072560844004"
        });
        sleep(1000);
        text("书旗小说").findOne().parent().click();
        text("榜单").findOne();
        for (; ;) {
            click(300, 265);
            if (text("热门搜索").findOne()) {
                break;
            }
        }
        setText(0, 书名);
        click(540, 265);
        sleep(2000);
        click(1000, 1750);
        sleep(2000);
        click(200, 550);
        text("书籍详情").findOne();
        sleep(3000);
        click(580, 1750);
        sleep(4000);
        for (; ;) {
            swipe(540, 1400, 540, 200, 20);
            swipe(540, 1400, 540, 200, 20);
            swipe(540, 1400, 540, 200, 20);
            var img = captureScreen();
            var point = (findImage(img, 下一章, { region: [650, 1500, 400, 400], threshold: 0.9 }));
            if (point) {
                sleep(500);
                press(point.x + 100, point.y + 50, 500);
                sleep(4000);
                click(540, 1400);
                sleep(500);
                click(540, 1400);
                break;
            }
        }
        for (var 次 = 0; 次 < 刷数; 次++) {
            for (var 下刷数 = 0; ; 下刷数++) {
                swipe(540, 1400, 540, 200, 40);
                var img = captureScreen();
                var point = (findImage(img, 下一章, { region: [650, 1500, 400, 400], threshold: 0.8 }));
                if (point) {
                    if (下刷数 < 5) {
                        press(point.x + 100, point.y + 50, 400);
                        sleep(4000);
                        continue;
                    }
                    刷数=1000/下刷数;
                    log(刷数);
                    break;
                }
            }
            for (var 上刷数 = 0; 上刷数 < 下刷数 + 2; 上刷数++) {
                swipe(540, 200, 540, 1400, 40);
            }
        }
        toast("阅读结束！");
        app.startActivity({
            action: "VIEW",
            data: "alipays://platformapi/startapp?appId=20000001"
        });
        text("首页").findOne();
        toast("看书完成！");
    }


    if (功能 == 2) {
        var 间隔 = dialogs.input("输入切号间隔(单位秒)\n\n(返回退出脚本)", 40); if (间隔 == null) { toast("已停止！"); exit(); }
    }
    var 操作账号 = dialogs.multiChoice(
        "请选择账号",
        账号,
        默认选择项
    );

    app.startActivity({                                     //程序入口
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=20000001"
    });
    text("首页").findOne();

    for (var i = 0; i < 操作账号.length; i++) {
        退换账号();
        if (功能 == 3) {
            if (i < 操作账号.length - 1) {
                浇水();
            }
        }
        if (功能 == 4) {
            阅读();
        }
    }


    toast("所有操作已完成！");
    toast("所有操作已完成！");
    toast("所有操作已完成！");
}
