var 脚本名称="保活 2.2.js";
//少量修改
auto.waitFor();

var time = new Date(http.get("http://www.qq.com").headers["date"]);
var month = time.getMonth()+1;
var log ="启动时间："+" "+time.getHours()+":"+time.getMinutes()+"\n";
files.write("/sdcard/脚本/保活日志.js", log);

toast("登录超时监听开启！");

function 进入(){
    toast("开始重启支付宝！");
    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=20000001"
    });
    text("首页").findOne();
    sleep(1000);
    text("我的").findOne().parent().click();
    sleep(1000);
    idContains("right_container_2").findOne().click();
    sleep(1000);
    text("换账号登录").findOne();
    sleep(200);
    text("换账号登录").boundsInside(0, 1360, 1080, 1900).findOne().parent().parent().parent().parent().click();
    sleep(200);
    idContains("otherAccountSwitcher").findOne().click();
    sleep(200);
    for(;;){
        if(className("android.widget.EditText").findOnce()){
            break;
        }
        if(textContains("等待").findOnce()){
            textContains("等待").findOne().click();
        }
    }
    sleep(200);
    setText(0,"13788131465");
    sleep(200);
    idContains("nextButton").findOne().click();
    for (; ;) {
        if (text("密码").findOne(5000)) {
            break;
        }
        if (text("换个方式登录").findOnce()) {
            text("换个方式登录").findOne().click();
            text("密码登录").findOne().parent().click();
            break;
        }
    }
    sleep(200);
    text("密码").findOne();
    sleep(200);
    setText(1,"199771qq");
    sleep(200);
    idContains("loginButton").findOne().click();
    sleep(200);
    var t = files.read("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json2");
    files.write("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json", t);
    files.append("/sdcard/脚本/保活日志.js", "切换为.json2    "); 
    text("首页").findOne();
    toast("切换完成！");

    for (var j = 0; ; j++) {
        sleep(1000);
        if ((30 - j) <= 0)
            break;
        if ((30 - j) % 5 == 0)
            toast("还剩" + (30 - j) + "秒切换！");
    }

    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=20000001"
    });
    text("首页").findOne();
    sleep(1000);
    text("我的").findOne().parent().click();
    sleep(1000);
    idContains("right_container_2").findOne().click();
    sleep(1000);
    text("换账号登录").findOne();
    sleep(200);
    text("换账号登录").boundsInside(0, 1360, 1080, 1900).findOne().parent().parent().parent().parent().click();
    sleep(200);
    idContains("otherAccountSwitcher").findOne().click();
    sleep(200);
    for(;;){
        if(className("android.widget.EditText").findOnce()){
            break;
        }
        if(textContains("等待").findOnce()){
            textContains("等待").findOne().click();
        }
    }
    sleep(200);
    setText(0,"18873292759");
    sleep(200);
    idContains("nextButton").findOne().click();
    
    for (; ;) {
        if (text("密码").findOne(5000)) {
            break;
        }
        if (text("换个方式登录").findOnce()) {
            text("换个方式登录").findOne().click();
            text("密码登录").findOne().parent().click();
            break;
        }
    }
    sleep(200);
    text("密码").findOne();
    sleep(200);
    setText(1,"980118lw,");
    sleep(200);
    idContains("loginButton").findOne().click();
    sleep(200);
    var t = files.read("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json1");
    files.write("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json", t);
    files.append("/sdcard/脚本/保活日志.js", "切换为.json1\n"); 
    toast("当前监听终止！");
    engines.execScriptFile("/sdcard/脚本/支付宝/"+脚本名称);
    toast("新的监听已开启！");
    text("首页").findOne();
    toast("支付宝重启完成！");
    exit();
}

// events.observeToast();
// events.onToast(function(toast){
//     //log("Toast内容: " + toast.getText() + " 包名: " + toast.getPackageName());
//     if(toast.getText()=="登录超时，请重启支付宝")
//         进入();
// });

// events.observeNotification();
// events.on("notification", function(n){
//     if(n.getText()){
//         if(n.getText().indexOf("重启支付宝")!==-1){
//             var time = new Date(http.get("http://www.qq.com").headers["date"]);
//             var 日志字串1 ="\n"+time.getHours()+":"+time.getMinutes()+":"+time.getSeconds()+"超时重启\n";
//             files.append("/sdcard/脚本/保活日志.js", 日志字串1); 
//             进入();
//         }
//     }
// });

var thread = threads.start(function(){
    
        var 定时=4200000;
        for(;;){
            var time = new Date(http.get("http://www.qq.com").headers["date"]);
            if((time.getHours()==7&&time.getMinutes()<30)||(time.getHours()==23&&time.getMinutes()>50)||(time.getHours()==0&&time.getMinutes()<5)){
                var t = files.read("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json2");
                files.write("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json", t);
                files.append("/sdcard/脚本/保活日志.js", ".json2  "); 
                sleep(120000);
                定时=0;
                continue;
            }else{
                var t = files.read("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json1");
                files.write("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json", t);
                files.append("/sdcard/脚本/保活日志.js", ".json1  "); 
            }
            
            sleep(300000);
            定时=定时-300000;
            files.append("/sdcard/脚本/保活日志.js", 定时/60000+"\n"); 
            if(定时<1){
                break;
            }
        }
        var time = new Date(http.get("http://www.qq.com").headers["date"]);
        var 日志字串1 ="\n"+time.getHours()+":"+time.getMinutes()+":"+time.getSeconds()+"定时切换\n";
        files.append("/sdcard/脚本/保活日志.js", 日志字串1); 
        进入();
    
});



