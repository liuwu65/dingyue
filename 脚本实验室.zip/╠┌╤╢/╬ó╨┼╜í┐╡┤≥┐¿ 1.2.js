//微信健康打卡 1.2
//适应新版打卡
auto.waitFor();

app.launchApp("微信");
textContains("湖南科技大学企业号").findOne().parent().parent().parent().parent().click();
text("系统助手").findOne();
swipe(540,1600,540,200,200);
sleep(200);
swipe(540,1600,540,200,200);
sleep(200);
swipe(540,1600,540,200,200);
sleep(200);
swipe(540,1600,540,200,200);
sleep(200);
swipe(540,1600,540,200,200);
sleep(200);
textContains("学生健康打卡").findOne().parent().parent().parent().parent().click();
text("通知公告").findOne();
text("健康打卡").findOne().parent().parent().click();
textContains("返校后").findOne();
var hours = new Date(http.get("http://www.qq.com").headers["date"]).getHours();
if (hours >= 0 && hours < 8) {
    textContains("早上健康打卡").findOne().click();
    textContains("正常").findOne();
    textContains("+ 现在打卡").findOne().click();
}
else if (hours >= 13 && hours < 20) {
    textContains("晚上健康打卡").findOne().click();
    textContains("正常").findOne();
    textContains("未打卡，现在打卡").findOne().click();
}
else {
    toast("不在打卡时间范围！！");
    toast("不在打卡时间范围！！");
    exit();
}
textContains("今日体温").findOne();
var 体温=Math.round(363+Math.random()*4)/10;
textContains("今日体温").findOne().parent().child(1).child(0).setText(体温);
textContains("提交").findOne().click();
textContains("确认提交").findOne().click();
toast("打卡成功！！");
toast("打卡成功！！");