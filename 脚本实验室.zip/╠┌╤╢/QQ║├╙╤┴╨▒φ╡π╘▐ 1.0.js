//QQ列表点赞 1.0
auto.waitFor();
toast("列表点赞需要切换到好友列表！\n\n同时，手动展开所有分组！\n\n还需要滑动至列表顶部！");
sleep(500);
toast("列表点赞需要切换到好友列表！\n\n同时，手动展开所有分组！\n\n还需要滑动至列表顶部！");
sleep(500);
toast("列表点赞需要切换到好友列表！\n\n同时，手动展开所有分组！\n\n还需要滑动至列表顶部！");
sleep(500);
toast("列表点赞将在5秒后开启！");
sleep(7000);
for(;;){
    if(id("icon").boundsInside(0,460,540,860).findOnce())
        break;
    else
        swipe(540,987,540,800,200);
}                   //滑到开始位置

for(;;){
    id("icon").boundsInside(0,460,540,860).findOne().parent().parent().click();
    if(descContains("八九").findOne(500)){
        back();
        textContains("联系人").findOne();
        sleep(200);
        swipe(540,987,540,800,200);
        continue;
    }               //跳过自己

    var 赞=descContains("赞").findOne();
    for(var i=0;i<10;i++){
        赞.click();
    }
    sleep(300);
    if(descContains("非正常人类").findOnce()){
        back();
        break;
    }               //结束控制
    
    back();
    textContains("联系人").findOne();
    sleep(200);
    swipe(540,987,540,800,200);
}

toast("列表点赞已完成！！！");
toast("列表点赞已完成！！！");


