//微信运动点赞 1.0
//微调
auto.waitFor();
var a = 0;
var w = device.width;
var h = device.height;

app.startActivity({
    packageName: "com.tencent.mm",
    className: "com.tencent.mm.ui.LauncherUI"
});
textContains("使用以下").findOne();
textContains("微信").boundsInside(0,h/2,w/2,h).findOne().parent().click();
waitForActivity("com.tencent.mm.ui.LauncherUI");
textContains("微信运动").findOne().parent().parent().parent().parent().click();
textContains("步数排行榜").findOne().parent().parent().click();
var selfname = id("brk").findOne().text();

for(;;){
  id("brk").find().forEach(function(name){
    if(name.text()==selfname)
    return;
  if(name.parent().parent().child(1).text()>=5000){
    name.parent().parent().parent().child(1).click();
  }
  else{
    a=1;
  }
  })
  if(a==1){
      toast("今日步数大于5000好友点赞已完成！");
      break;
  }
  swipe(540,1700,540,300,300);sleep(500);
}






