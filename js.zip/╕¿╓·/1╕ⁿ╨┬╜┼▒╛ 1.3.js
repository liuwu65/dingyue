//更新脚本 1.2
//添加解压操作
auto.waitFor();

files.removeDir("/sdcard/脚本.zip");
var url = "https://gitee.com/liuwu6565/dingyue/raw/master/js.zip";
var res = http.get(url);
if (res.statusCode != 200) {
    toast("请求失败");
} else {
    files.writeBytes("/sdcard/脚本.zip", res.body.bytes());
    toast("下载成功");
    files.removeDir("/sdcard/脚本/");
    app.launchApp("文件管理");
    toast("如果3s没有自动打开文件管理，手动打开");
    toast("如果3s没有自动打开文件管理，手动打开");
    toast("如果3s没有自动打开文件管理，手动打开");
    text("手机").findOne();
    swipe(300, 1000, 1000, 1000, 10);
    sleep(200);
    swipe(300, 1000, 1000, 1000, 10);
    sleep(200);
    swipe(300, 1000, 1000, 1000, 10);
    sleep(200);
    text("内部存储设备").findOne();
    sleep(700);
    for (; ;) {
        swipe(540, 1600, 540, 50, 200);
        sleep(200);
        if (text("脚本.zip").findOnce()) {
            sleep(500);
            break;
        }
    }
    text("脚本.zip").findOne().parent().parent().parent().parent().click();
    text("解压缩到此处").findOne().click();
    toast("解压成功");
    launchApp("Auto.js");
    toast("请刷新");
    toast("请刷新");
}
