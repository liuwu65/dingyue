auto.waitFor();

var 时 = dialogs.input("闹钟时间-时\n\n(返回退出脚本)", 02); if (时 == null) { toast("已停止！"); exit(); }
var 分 = dialogs.input("闹钟时间-分\n\n(返回退出脚本)", 05); if (分 == null) { toast("已停止！"); exit(); }

function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    sleep(100);

    for (; ;) {
        var localDate = new Date();
        var hour = localDate.getHours();
        var minute = localDate.getMinutes();
        log("闹钟时间："+时+":"+分);
        log("当前时间："+hour+":"+minute+"\n");
        
        if (hour == 时) {
            if (minute == 分) {
                log("时间到！\n");
                break;
            } else {
                sleep(10000);
                continue;
            }
        } else {
            sleep(10000);
            continue;
        }
    }
}

倒计时();
idContains("playBtn").findOne().click();