//ss收集
auto.waitFor();
var i = 0;
for (; ;) {
    descContains("ss").find().forEach(function (内容) {
        if (内容.desc().indexOf("ssr://") !== -1 || 内容.desc().indexOf("ss://") !== -1) {
            log(内容.desc());
            files.append("/sdcard/脚本/ss链接.js", 内容.desc() + "\n");
        }
    })
    if (!desc("转到底部").findOne(100)) {
        i++;
        if (i > 3) {
            toast("收集完成！");
            toast("收集完成！");
            break;
        }
        swipe(950, 1300, 950, 230, 50);
        continue;
    }
    if (i == 0) {
        swipe(135, 1650, 135, 230, 50);
        i = 1;
        continue;
    }
    if (i == 1) {
        swipe(950, 1300, 950, 230, 50);
        i = 0;
        continue;
    }
}


