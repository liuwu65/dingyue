//关闭广告 1.0
if (device.brand == "HONOR") {
    auto.waitFor();
} else {
    function root开无障碍() {
        var pref = android.preference.PreferenceManager.getDefaultSharedPreferences(context);
        pref.edit().putBoolean("key_enable_accessibility_service_by_root", true).commit();
        function 重启无障碍root(参数) {
            toastLog("正在尝试使用root权限开启无障碍")
            var s = shell("settings get secure enabled_accessibility_services", true).result.replace(/\n/, "");
            if (s.indexOf(参数) > -1) {
                s = s.replace(参数, "")
                var 结果 = shell("settings put secure enabled_accessibility_services :" + s, true);
                if (结果.code) {
                    toastLog("尝试开启无障碍服务异常");
                    return
                }
            }
            s += ":" + 参数
            s = s.replace(/:+/gim, ":")
            shell("settings put secure accessibility_enabled 1", true);
            var code = shell("settings put secure enabled_accessibility_services " + s, true).code;
            if (code) {
                toastLog("尝试开启无障碍服务异常");
                return
            }
            shell("settings put secure accessibility_enabled 1", true);
        }
        let autojs = context.getPackageName() + "/com.stardust.autojs.core.accessibility.AccessibilityService";
        重启无障碍root(autojs);
    }
    root开无障碍();
    log("root");
}

toastLog("开始检测！");
for (; ;) {
    if (textStartsWith("跳过").findOnce()) {
        var bound = textStartsWith("跳过").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        toastLog("跳过1个广告！");
        sleep(500);
    }
    if (idContains("close_ad").findOnce()) {
        var bound = idContains("close_ad").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        toastLog("跳过1个广告！");
        sleep(500);
    }
    if (id("close_bt").findOnce()) {
        var bound = idContains("close_bt").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        toastLog("跳过1个广告！");
        sleep(500);
    }
    if (idContains("skip").findOnce()) {
        var bound = idContains("skip").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        toastLog("跳过1个广告！");
        sleep(500);
    }
    if (idContains("close_icon").findOnce()) {
        var bound = idContains("close_icon").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        toastLog("跳过1个广告！");
        sleep(500);
    }
    sleep(200);
    log("正在检测！");
}


















































