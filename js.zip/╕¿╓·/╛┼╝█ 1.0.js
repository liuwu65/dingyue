auto.waitFor();

var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if (分 == null) { toast("已停止！"); exit(); }
var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if (秒 == null) { toast("已停止！"); exit(); }
var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if (延时 == null) { toast("已停止！"); exit(); }
var 位置 = dialogs.select("选择悬浮框顶点\n\n(返回退出脚本)\n", "● 左上↖", "● 右上↗", "● 左下↙", "● 右下↘"); if (位置 == -1) { toast("已停止！"); exit(); }
var x;
var y;
var 显示字串;




function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info(显示字串 + "\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(100);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute == 分) {
            if (second <= 秒 - 6) {
                print(minute + ":" + second);
                sleep(800);
                continue;
            } else {
                console.info(minute + ":" + second);
                console.info("还有5秒");
                sleep(2000);
                toast("还有3秒!");
                console.hide();
                sleep(1000);
                break;
            }
        } else {
            sleep(800);
            continue;
        }
    }
    console.hide();
    for (; ;) {
        var second = new Date(http.get("http://www.baidu.com").headers["Date"]).getSeconds();
        if (second >= 秒) {
            sleep(延时);
            return;
        }
    }
}




function 主程序() {
    for (; ;) {
        for (; ;) {
            click(x, y);
            if (textContains("九价人乳头瘤").findOnce()) {
                break;
            }
        }

        var ParentView1 = textContains("九价人乳头瘤").findOne().parent();
        var ClickButton = ParentView1.child(ParentView1.childCount() - 1).child(0);
        if (ClickButton.text() == "暂未开始") {
            back();
            for (var i = 0; i < 10000; i++) {
                if (!text("支付方式").findOnce()) {
                    break;
                }
                log(i);
                if (i % 100 == 99) {
                    back();
                    i=0;
                }
            }
            continue;
        }
        if (ClickButton.text() == "立即预约") {
            break;
        }

    }


    for (; ;) {
        ClickButton.click();
        if (text("选择预约时间").findOnce()) {
            break;
        }
        if (text("门诊公告").findOnce()) {
            var ParentView2 = text("门诊公告").findOne().parent();
            var CloseButton = ParentView2.child(ParentView2.childCount() - 1).bounds();
            click(CloseButton.centerX(), CloseButton.centerY());
            continue;
        }
        break;
    }


    var bounds = ClickButton.bounds();
    for (; ;) {
        click(bounds.centerX(), bounds.centerY());
        if (text("选择预约时间").findOnce()) {
            break;
        }
    }


    for (var i = 0; i < 11; i++) {
        if (text("可预约").findOnce()) {
            var bounds = text("可预约").findOne().bounds();
            for (; ;) {
                click(bounds.centerX(), bounds.centerY());
                if (text("预约").findOnce()) {
                    text("预约").findOne().click();
                    break;
                }
            }


            text("可预约").findOne().parent().click();
            break;
        }
        if (i == 10) {
            toastLog("已满或加载中");
            toastLog("已满或加载中");
            toastLog("已满或加载中");
        }
    }

}




var window = floaty.window(
    <vertical>
        <text id="text1" text="将方框移动到适当位置；点击确定开始" textSize="20sp" bg="#44ffcc00" />
        <button id="ok" text="确定" bg="#44dddd00" />
    </vertical>
);
window.setSize(500, 450);
window.setPosition(300, 450);
window.setAdjustEnabled(!window.isAdjustEnabled());
window.exitOnClose();
window.ok.on("click", () => {
    window.disableFocus();
    x = window.getX();
    y = window.getY();
    if (位置 == 0) { y = y + 65; }
    if (位置 == 1) { x = x + 430; y = y + 65; }
    if (位置 == 2) { y = y + 440; }
    if (位置 == 3) { x = x + 430; y = y + 440; }
    显示字串 = "坐标：(" + x + "," + y + ")";
    window.setPosition(-400, 1200);

    threads.start(function () {
        倒计时();
        主程序();
        exit();
    });
    //window.close();
});
setInterval(() => { }, 500);

