auto.waitFor();
toast("已开启屏幕常亮！");
for (; ;) {
    device.keepScreenOn(999999999999999);
    device.keepScreenDim(999999999999999)
    sleep(110000);
    if (device.getBattery() < 21) {
        device.vibrate(1000);
        toast("电量低！");
        sleep(2000);
        device.vibrate(1000);
        toast("电量低！");
        sleep(2000);
        device.vibrate(1000);
        toast("电量低！");
        sleep(2000);
    }
}
