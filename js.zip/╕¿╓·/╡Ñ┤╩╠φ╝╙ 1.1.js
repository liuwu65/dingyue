//单词添加 1.1
//优化结构
auto.waitFor();
var 词库=new Array;
var 延时=200;
var i = 0;
var text = open("/sdcard/脚本/单词.txt", mode = "r", encoding = "utf-8", bufferSize = 8192);
text.readlines().forEach(function (line) {
    词库[i] = line;
    i++;
});

for (i = 0; i < 词库.length; i++) {
    setText(词库[i]);
    sleep(延时);
    if(idContains("word_operation").findOne(300)){
        idContains("word_operation").findOne().click();
        sleep(延时);
        if (textContains("取消").findOne(100)) {
            textContains("取消").findOne().click();
            sleep(延时);
        }
    }else{
        files.append("/sdcard/脚本/单词1.txt", 词库[i]+"\n"); 
        sleep(延时);
    }
}
