//单词添加(点击版) 1.1
//修改日志显示
auto.waitFor();
var 词库 = new Array;
var 延时 = 200;
var i = 0;
var text = open("/sdcard/脚本/单词.txt", mode = "r", encoding = "utf-8", bufferSize = 8192);
text.readlines().forEach(function (line) {
    词库[i] = line;
    i++;
});
i = 0;

var window = floaty.window(
    <vertical >
        <text gravity="center" id="text1" text="下一个" textColor="#44dddd00" textSize="40sp" bg="#44ffcc00" />
        <button gravity="center" id="ok" text="确定" textSize="40sp" bg="#44dddd00" />
    </vertical>
);
window.setSize(500, 400);
window.setPosition(300, 1400);
window.setAdjustEnabled(!window.isAdjustEnabled());
window.exitOnClose();
window.ok.on("click", () => {
    threads.start(function () {
        setText(词库[i]);
        sleep(延时);
        if (idContains("word_operation").findOne(300)) {
            idContains("word_operation").findOne().click();
            sleep(延时);
            if (textContains("取消").findOne(100)) {
                textContains("取消").findOne().click();
                sleep(延时);
            }
        } else {
            files.append("/sdcard/脚本/单词1.txt", 词库[i] + "\n");
            sleep(延时);
        }
        i++;
        if(i==词库.length){
            toast("单词已添加完成！");
            sleep(2000);
            toast("单词已添加完成！");
            sleep(2000);
            window.close();
            toast("单词已添加完成！");
            toast("单词已添加完成！");
            toast("单词已添加完成！");
            
        }
    });

});
setInterval(() => { }, 500);





