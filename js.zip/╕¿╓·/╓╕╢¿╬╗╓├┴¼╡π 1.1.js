//指定位置连点1.1
//添加倒计时功能
auto.waitFor();


var 显示字串;
var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if(分==null){toast("已停止！");exit();}
var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if(秒==null){toast("已停止！");exit();}
var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if(延时==null){toast("已停止！");exit();}
var 位置 = dialogs.select("选择悬浮框顶点\n\n(返回退出脚本)\n", "● 左上↖", "● 右上↗", "● 左下↙", "● 右下↘"); if (位置 == -1) { toast("已停止！"); exit(); }
var 间隔 = dialogs.input("输入点击间隔(单位毫秒)\n10~500之间\n(返回退出脚本)", 20); if (间隔 == null) { toast("已停止！"); exit(); }
var 时长 = dialogs.input("输入点击持续时间(单位秒)\n\n(返回退出脚本)", 3); if (间隔 == null) { toast("已停止！"); exit(); }


function 倒计时(){
    console.show();
    sleep(100);
    console.setPosition(400,400);
    console.setSize(730,900);
    console.info(显示字串+"\n脚本已运行！\n"+"最后一分钟开始计时！");
    sleep(1000);

    for(;;){                //获取时间、判断开始
        var internetdDate = new Date(http.get("http://www.qq.com").headers["Date"]); //把Date转换成时间对象
        //var hour = internetdDate .getHours();
        var minute = internetdDate .getMinutes();
        var second = internetdDate .getSeconds();
        //print(minute+":"+second);
        if(minute>=分&&second>=秒){   //！！时间控制！！！！
            sleep(延时);//延迟时间
            break;
        }
        if(minute==分&&second<=秒-10){
            print(minute+":"+second);
            sleep(800);
        }
        if(minute==分&&second==秒-9){
            print(minute+":"+second);
            console.info("还有9秒");
            toast("还有9秒!\n请等待！");
            sleep(2000);
            toast("还有7秒!\n请等待！");
            console.hide();
            toast("还有5秒!\n马上开始！");
            toast("还有3秒!\n马上开始！");
        }
    }
    return;
}


var window = floaty.window(
    <vertical>
        <text id="text1" text="将方框移动到适当位置；点击确定开始" textSize="20sp" bg="#44ffcc00" />
        <button id="ok" text="确定" bg="#44dddd00" />
    </vertical>
);
window.setSize(500, 450);
window.setPosition(300, 450);
window.setAdjustEnabled(!window.isAdjustEnabled());
window.exitOnClose();
window.ok.on("click", () => {
    window.disableFocus();
    var x = window.getX();
    var y = window.getY();
    if (位置 == 0) { y = y+ 65; }
    if (位置 == 1) { x = x + 430; y = y + 65; }
    if (位置 == 2) { y = y + 440; }
    if (位置 == 3) { x = x + 430; y = y + 440; }
    显示字串 = "坐标：(" + x + "," + y + ")\n间隔：" + 间隔 + " ms\n时长：" + 时长 + " s\n";
    window.setPosition(-400, 1200);
    threads.start(function () {
        倒计时();
        var 次数 = 时长 * 1000 / 间隔 * 0.9;
        for (var i = 0; i < 次数; i++) {
            press(x, y, 间隔);
        }
        toast("点击结束！");
        toast("点击结束！");
        exit();
    });
    //window.close();
});
setInterval(() => { }, 500);
