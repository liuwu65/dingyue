//清空文件 1.4.js
auto.waitFor();
console.show();
sleep(100);
console.setPosition(400,400);
console.setSize(730,900);


var arr = files.listDir("/sdcard/");
for (var i = 0; i < arr.length; i++) {
    if (arr[i] == "脚本" || arr[i] == "脚本" || arr[i] == "Pictures" || arr[i] == "DCIM" || arr[i] == "1" || arr[i] == "Android"||arr[i] == "XMind"||arr[i] == "MIUI") {
    }else{
        files.removeDir("/sdcard/"+arr[i]);
        log("移除  /sdcard/"+arr[i]);
    }
}
var arr = files.listDir("/sdcard/MIUI");
for (var i = 0; i < arr.length; i++) {
    if (arr[i] == "sound_recorder") {
    }else{
        files.removeDir("/sdcard/MIUI/"+arr[i]);
        log("移除  /sdcard/MIUI/"+arr[i]);
    }
}
var arr = files.listDir("/sdcard/脚本");
for (var i = 0; i < arr.length; i++) {
    if (arr[i] == "辅助"||arr[i] == "京东"||arr[i] == "淘宝"||arr[i] == "淘宝(兑换+直群抢)"||arr[i] == "京东"||arr[i] == "支付宝"||arr[i] == "腾讯"||arr[i] == "天猫"||arr[i] == "购物") {
    }else{
        files.removeDir("/sdcard/脚本/"+arr[i]);
        log("移除  /sdcard/脚本/"+arr[i]);
    }
}
var arr = files.listDir("/sdcard/Android");
for (var i = 0; i < arr.length; i++) {
    if (arr[i] == "data") {
    }else{
        files.removeDir("/sdcard/Android/"+arr[i]);
        log("移除  /sdcard/Android/"+arr[i]);
    }
}
var arr = files.listDir("/sdcard/Android/data");
for (var i = 0; i < arr.length; i++) {
    if (arr[i] == "pansong291.xposed.quickenergy.qiufeng"||arr[i] == "xposed.quickenergy.lbxxsuper"||arr[i] == "pansong291.xposed.quickenergy"||arr[i] == "com.tencent.tmgp.sgame"||arr[i] == "com.tencent.tmgp.speedmobile") {
    }else{
        files.removeDir("/sdcard/Android/data/"+arr[i]);
        log("移除  /sdcard/Android/data/"+arr[i]);
    }
}
files.removeDir("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/rank.json");
log("移除  /sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/rank.json");
app.launchApp("文件管理");
text("手机").findOne();
swipe(300, 1000, 1000, 1000, 10);
sleep(200);
swipe(300, 1000, 1000, 1000, 10);
sleep(200);
swipe(300, 1000, 1000, 1000, 10);
sleep(200);
desc("点击切换数据").findOne().click();
sleep(700);
text("应用双开数据").findOne().click();
sleep(700);
text("Android").findOne().parent().parent().parent().parent().click();
text("data").findOne().parent().parent().parent().parent().click();
text("pansong291.xposed.quickenergy.qiufeng").findOne().parent().parent().parent().parent().click();
if (text("rank.json").findOne(2000)) {
    text("rank.json").findOne().parent().parent().parent().parent().longClick();
    text("删除").findOne().parent().click();
    text("取消").findOne().parent().child(1).click();
}

console.info("清除完成！");
sleep(1500);
console.hide();