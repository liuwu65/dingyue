auto.waitFor();


files.create("/sdcard/1/QQfile/");
sleep(500);
var arr = files.listDir("/sdcard/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv");
for (var i = 0; i < arr.length; i++) {
    files.move("/sdcard/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/" + arr[i], "/sdcard/1/QQfile/" + arr[i]);
    log("/sdcard/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/" + arr[i]);

}

log("移动完成！");