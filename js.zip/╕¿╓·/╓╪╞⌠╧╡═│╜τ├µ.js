auto.waitFor();

app.launchApp("ChiMi");
text("系统界面").findOne().parent().parent().click();
text("MIUI状态栏").findOne();
desc("更多选项").findOne().click();
text("重启系统界面").findOne().parent().parent().parent().click();
text("是").findOne().click();
sleep(3500);
swipe(540, 100, 1000, 1200, 500); sleep(300);
swipe(540, 1200, 1000, 100, 500); sleep(1000);
desc("0").findOne().click(); sleep(200);
desc("5").findOne().click(); sleep(200);
desc("2").findOne().click(); sleep(200);
desc("5").findOne().click(); sleep(200);
text("MIUI状态栏").findOne();
home();
idContains("clear_icon").findOne().click();
toast("已重启");



