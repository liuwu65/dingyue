var 脚本名称="保活 3.2.js";
//修复出错
auto.waitFor();

var now = new Date();
var h=now.getHours();
var m=now.getMinutes();
var log ="脚本启动时间："+" "+h+":"+m+"======\n";
files.write("/sdcard/脚本/保活日志.js", log);
toast("保活程序已开启！");


function 唤醒() {
    if (!device.isScreenOn()) {
        device.wakeUp();
        sleep(1500);
        app.launchApp("支付宝");
        if (device.brand == "HONOR") {
            swipe(540, 1400, 540, 100, 500); sleep(500);
            desc("0").findOne().click(); sleep(200);
            desc("5").findOne().click(); sleep(200);
            desc("2").findOne().click(); sleep(200);
            desc("5").findOne().click(); sleep(200);
            sleep(2000);
        }
        if (device.brand == "Xiaomi" || device.brand == "Redmi") {
            swipe(540, 10, 540, 1200, 400); sleep(300);
            //swipe(540, 1200, 1000, 100, 400); sleep(1000);
            desc("设置").findOne().click(); sleep(1000);
            desc("0").findOne().click(); sleep(200);
            desc("5").findOne().click(); sleep(200);
            desc("2").findOne().click(); sleep(200);
            desc("5").findOne().click(); sleep(200);
            sleep(2000);
        }
    }
    toast("开始重启");
    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=20000001"
    });

    for (; ;) {
        if (text("打开").findOnce()) {
            text("打开").findOne().click();
        }
        if (textContains("首页").findOnce()) {
            text("首页").findOne().parent().click();
        }
        if (text("蚂蚁森林").findOnce()) {
            break;
        }
    }

    sleep(1000);
    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=60000002"
    });
    for (; ;) {
        if (text("打开").findOnce()) {
            text("打开").findOne().click();
        }
        if (textContains("我的大树养成").findOne(4000)) {
            break;
        }
        if (text("重新加载").findOnce()) {
            text("重新加载").findOne().click();
            sleep(300);
        }
        sleep(100);
    }
    sleep(1000);
    home();
    sleep(500);
    home();
}




var thread = threads.start(function(){
    for(;;){
        if (textContains("支付宝出现异常").findOnce()) {
            sleep(800);
            text("取消").findOne().click();
        }
        sleep(10000);
    }
});

console.show();
sleep(100);
console.setPosition(400, 400);
console.setSize(730, 900);

for(;;){
    var now = new Date();
    var h=now.getHours();
    var m=now.getMinutes();
    console.info(m);
    if ((h == 6 && m > 50)||(h == 7 && m < 30) || (h == 23 && m > 50) || (h == 0 && m < 5)) {
        var q = files.read("/sdcard/脚本/支付宝/附件/q-max.json");
        files.write("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json", q);
        files.append("/sdcard/脚本/保活日志.js", "q-max.json-急速模式\n");
        var x = files.read("/sdcard/脚本/支付宝/附件/x-max.json");
        files.write("/sdcard/Android/data/pansong291.xposed.quickenergy/config.json", x);
        files.append("/sdcard/脚本/保活日志.js", "x-max.json-急速模式\n");
        唤醒();
        var now = new Date();
        var h=now.getHours();
        var m=now.getMinutes();
        var log = "启动时间：" + " " + h + ":" + m + "\n";
        console.info(log);
        files.append("/sdcard/脚本/保活日志.js", log);
        sleep(270000);
        continue;
    }else{
        var q = files.read("/sdcard/脚本/支付宝/附件/q-nor.json");
        files.write("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json", q);
        files.append("/sdcard/脚本/保活日志.js", "q-nor.json-省电模式\n");   
        var x = files.read("/sdcard/脚本/支付宝/附件/x-nor.json");
        files.write("/sdcard/Android/data/pansong291.xposed.quickenergy/config.json", x);
        files.append("/sdcard/脚本/保活日志.js", "x-nor.json-省电模式\n");
    }
    
    var log = "检测时间" + " " + h + ":" + m + "\n";
    console.info(log);
    files.append("/sdcard/脚本/保活日志.js", log);
    sleep(120000);
}