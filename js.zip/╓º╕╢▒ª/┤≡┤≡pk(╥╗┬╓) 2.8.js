//答答pk(一轮) 2.8.js
//调整
auto.waitFor();
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}
if (!requestScreenCapture()) {
    toast("请求截图失败！");
    exit();
}
var 篮球 = images.read("/sdcard/脚本/支付宝/附件/篮球.jpg");
var 篮框1 = images.read("/sdcard/脚本/支付宝/附件/篮框1.jpg");
var 篮框2 = images.read("/sdcard/脚本/支付宝/附件/篮框2.jpg");

var 账号 = [
    "18873292759",
    "511303a22tm.cdb@sina.cn",
    "13158507242",
    "13788131465",
    "18873208031",
    "hpp0165@163.com",
];
var 密码 = [
    "980118lw,",
    "980118lw,",
    "123456lw,",
    "1997qq",
    "1997qq",
    "123456lw,",
];


var 次数 = 0;
var 题目 = new Array;
var 答案 = new Array;
var 新增题目 = new Array;
var 新增答案 = new Array;
var 添题参数 = 0;
var 胜利次数 = 0;
var 平局次数 = 0;
var 失败次数 = 0;
var 难度等级 = 2;
var 入场积分 = 50;
var 操作账号 = [0, 1, 2, 3, 4, 5];
var 当前运行账号 = dialogs.select("请选择 开始账号", 账号); if (当前运行账号 == -1) { toast("已停止！"); exit(); }
//当前运行账号 = 通信(当前运行账号, 0);

// app.startActivity({
//     action: "VIEW",
//     data: "alipays://platformapi/startapp?appId=20000001"
// });


function 清除数据() {
    if (device.brand == "HONOR") {
        app.launchApp("设置");
        desc("搜索查询").findOne();
        for (; ;) {
            if (text("应用和通知").findOnce()) {
                text("应用和通知").findOne().parent().parent().click();
                break;
            }
            if (text("应用").findOnce()) {
                text("应用").findOne().parent().parent().click();
                break;
            }
        }
        text("应用管理").findOne().parent().parent().parent().click();
        textContains("所有应用").findOne();
        sleep(500);
        for (; ;) {
            if (text("支付宝").findOnce()) {
                break;
            }
            scrollDown();
            sleep(300);
        }
        sleep(500);
        var bound = text("支付宝").findOne().bounds();
        click(bound.centerX() + 500, bound.centerY());
        var bound = text("存储").findOne().bounds();
        click(bound.centerX() + 500, bound.centerY());
        sleep(500);
        for (; ;) {
            if (text("删除数据").findOnce()) {
                text("删除数据").findOne().click();
                sleep(500);
            }
            if (text("确定").findOnce()) {
                text("确定").findOne().click();
                break;
            }
            if (text("删除").findOnce()) {
                text("删除").findOne().click();
                break;
            }
            sleep(200);
        }
        text("0 B").findOne();
        sleep(500);
        app.launchApp("支付宝");
        text("同意").findOne().click();
        sleep(500);
        var t = 0;
        for (; ;) {
            if (text("始终允许").findOnce()) {
                t = 1;
                text("始终允许").findOne().click();
                sleep(200);
                continue;
            }
            if (text("确定").findOnce()) {
                t = 1;
                text("确定").findOne().click();
                sleep(200);
                continue;
            }
            t++;
            if (t > 5) {
                break;
            }
            sleep(200);
        }
        sleep(300);
        text("其他登录方式").findOne().parent().click();
        sleep(300);
    } else {
        home();
        sleep(500);
        home();
        sleep(500);
        desc("常用").findOne().click();
        desc("支付宝").findOne().longClick();
        text("应用信息").findOne().parent().click();
        text("清除数据").findOne().parent().click();
        text("清除全部数据").findOne().click();
        text("确定").findOne().click();
        sleep(800);
        app.launchApp("支付宝");
        for (; ;) {
            if (text("同意").findOnce()) {
                text("同意").findOne().click();
                sleep(300);
            }
            if (text("仅在使用中允许").findOnce()) {
                text("仅在使用中允许").findOne().click();
                sleep(200);
                break;
            }
            sleep(300);
        }
        sleep(400);
        text("其他登录方式").findOne().parent().click();
        for (; ;) {
            sleep(600);
            log("其他登录方式");
            if (text("其他登录方式").findOnce()) {
                text("其他登录方式").findOne().parent().click();
            } else {
                break;
            }
        }
    }
}

function 通信(k, j) {
    var 通信组 = new Array;
    console.hide();
    home(); sleep(500);
    home(); sleep(500);
    if (device.brand == "HONOR") {
        for (; ;) {
            if (text("一键优化").findOnce()) {
                text("一键优化").findOne().click();
                sleep(500);
                text("一键优化").findOne().click();
                sleep(6000);
                desc("QQ").findOne().click();
                break;
            }
            if (text("一键清理").findOnce()) {
                text("一键清理").findOne().click();
                sleep(500);
                text("一键清理").findOne().click();
                sleep(3000);
                break;
            }
            sleep(200);
        }
        sleep(1000);
    } else {
        idContains("clear_icon").findOne().click();
        sleep(500);
        idContains("clear_icon").findOne().click();
        sleep(3000);
    }

    app.launchApp("QQ");
    desc("搜索").findOne();
    sleep(1000);
    desc("搜索").findOne().click();
    text("取消").findOne();
    setText(0, "通信组");
    textContains("1057319533").findOne().parent().parent().parent().click();
    idContains("input").findOne();
    sleep(2000);
    var text0 = idContains("chat_item_content_layout").find()[idContains("chat_item_content_layout").find().length - 1].text();
    for (var i = 0; i < 6; i++) {
        通信组[i] = text0.substring(i, i + 1);
    }
    if (j == 0) {
        通信组[k] = 1;
        var 返回值 = k;
    }
    var 临时编号 = k + 1;
    if (临时编号 == 6) {
        临时编号 = 0;
    }
    if (j == 1) {
        for (var i = 0; i <= 6; i++) {
            if (i == 5) {
                log("没有账号可执行");
                通信组[k] = 0;
                var text0 = "";
                for (var i = 0; i < 6; i++) {
                    text0 = text0 + 通信组[i];
                }
                log(text0);
                setText(0, text0);
                sleep(500);
                text("发送").findOne().click();
                console.show();
                sleep(100);
                console.setPosition(500, 750);
                console.setSize(600, 500);
                exit();
            }
            if (通信组[临时编号] == 0) {
                通信组[临时编号] = 1;
                var 返回值 = 临时编号;
                break;
            }
            临时编号++;
            if (临时编号 == 6) {
                临时编号 = 0;
            }
        }
        通信组[k] = 0;
    }
    if (j == 2) {
        通信组[k] = 2;
        for (var i = 0; i <= 6; i++) {
            if (i == 6) {
                log("没有账号可执行");
                var text0 = "";
                for (var i = 0; i < 6; i++) {
                    text0 = text0 + 通信组[i];
                }
                log(text0);
                setText(0, text0);
                sleep(500);
                text("发送").findOne().click();
                console.show();
                sleep(100);
                console.setPosition(500, 750);
                console.setSize(600, 500);
                var text0 = idContains("chat_item_content_layout").find()[idContains("chat_item_content_layout").find().length - 1].text();
                if (text0 == "222222") {
                    setText(0, "今日任务已完成！");
                    sleep(500);
                    text("发送").findOne().click();
                    sleep(500);
                    setText(0, "000000");
                    sleep(500);
                    text("发送").findOne().click();
                    sleep(500);
                    if (device.brand == "Redmi") {
                        engines.execScriptFile("/sdcard/脚本/支付宝/积分总结 1.2.js");
                    }
                }
                exit();
            }
            if (通信组[临时编号] == 0) {
                通信组[临时编号] = 1;
                var 返回值 = 临时编号;
                break;
            }
            临时编号++;
            if (临时编号 == 6) {
                临时编号 = 0;
            }
        }
    }

    var text0 = "";
    for (var i = 0; i < 6; i++) {
        text0 = text0 + 通信组[i];
    }
    log(text0);
    setText(0, text0);
    sleep(500);
    text("发送").findOne().click();
    return 返回值;
}

function 退换账号() {
    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=20000001"
    });
    sleep(200);
    for (; ;) {
        if (text("换个账号").findOne(50)) {
            text("换个账号").findOne().click();
            sleep(100);
            break;
        }
        if (textContains("点击下方头像登录").findOne(50)) {
            text("换个账号登录").findOne().click();
            sleep(100);
            break;
        }
        if (textContains("账号在其他设备登录").findOne(50)) {
            text("好的").findOne().click();
            sleep(100);
            continue;
        }
        if (text("我的").findOne(50)) {
            text("我的").findOne();
            sleep(100);
            text("我的").findOne().parent().click();
            sleep(500);
            for (; ;) {
                if (idContains("right_container_2").findOnce()) {
                    idContains("right_container_2").findOne().click();
                }
                if (text("换账号登录").findOnce() || text("切换账号").findOnce()) {
                    break;
                }
                sleep(200);
            }
            sleep(100);
            for (; ;) {
                if (text("切换账号").findOnce()) {
                    text("切换账号").findOne().click();
                    break;
                }
                if (text("换账号登录").findOnce()) {
                    if (text("换账号登录").boundsInside(0, 1200, 1080, 1900).findOne().clickable()) {
                        text("换账号登录").boundsInside(0, 1200, 1080, 1900).findOne().click();
                    } else {
                        text("换账号登录").boundsInside(0, 1200, 1080, 1900).findOne().parent().parent().parent().parent().click();
                    }
                    break;
                }
            }
            sleep(100);
            idContains("otherAccountSwitcher").findOne().click();
            sleep(100);
            for (; ;) {
                if (className("android.widget.EditText").findOnce()) {
                    break;
                }
                if (textContains("等待").findOnce()) {
                    textContains("等待").findOne().click();
                }
            }
            break;
        }
        if (text("账号").findOnce()) {
            break;
        }
    }
    sleep(100);
    if (text("密码").findOnce()) {
        sleep(200);
        setText(0, 账号[当前运行账号]);
        setText(1, 密码[当前运行账号]);
        sleep(200);
        setText(0, 账号[当前运行账号]);
        setText(1, 密码[当前运行账号]);
    } else {
        sleep(200);
        setText(0, 账号[当前运行账号]);
        sleep(200);
        for (; ;) {
            if (className("android.widget.EditText").findOnce()) {
                break;
            }
            if (textContains("等待").findOnce()) {
                textContains("等待").findOne().click();
            }
        }
        idContains("nextButton").findOne().click();
        sleep(100);
        for (; ;) {
            if (text("密码").findOnce()) {
                break;
            }
            if (textContains("指纹").findOnce() || text("刷脸登录").findOnce() || text("短信验证码登录").findOnce()) {
                text("换个方式登录").findOne().click();
                text("密码登录").findOne().parent().click();
                sleep(100);
            }
            if (text("请将球滑向篮球框中").findOne(1000)) {
                for (; ;) {
                    if (text("请将球滑向篮球框中").findOne(500)) {
                        var co1 = findImage(captureScreen(), 篮球, { threshold: 0.7 });
                        var co2 = findImage(captureScreen(), 篮框1, { threshold: 0.7 });
                        var co3 = findImage(captureScreen(), 篮框2, { threshold: 0.7 });
                        if (co1 && (co2 || co3)) {
                            if (co2) {
                                swipe(co1.x + 50, co1.y + 50, co2.x + 100, co2.y + 80, 1500);
                                sleep(1000);
                            } else {
                                swipe(co1.x + 50, co1.y + 50, co3.x + 100, co3.y + 100, 500);
                                sleep(1000);
                            }
                        }
                    } else {
                        break;
                    }
                }
            }
        }
        sleep(100);
        setText(0, 账号[当前运行账号]);
        setText(1, 密码[当前运行账号]);
        sleep(200);
        setText(0, 账号[当前运行账号]);
        setText(1, 密码[当前运行账号]);
        for (; ;) {
            if (className("android.widget.EditText").findOnce()) {
                break;
            }
            if (textContains("等待").findOnce()) {
                textContains("等待").findOne().click();
            }
        }
    }
    idContains("loginButton").findOne().click();
    sleep(100);
    for (; ;) {
        if (textContains("选出").findOnce() || textContains("哪").findOnce() || textContains("发送短信验证码").findOnce()) {
            for (; ;) {
                device.vibrate(500);
                if (text("首页").findOne(1500)) {
                    break;
                }
            }
        }
        if (idContains("otherAccountSwitcher").findOnce() || textContains("登录成功").findOnce()) {
            app.startActivity({
                action: "VIEW",
                data: "alipays://platformapi/startapp?appId=20000001"
            });
            sleep(100);
        }
        if (textContains("支付宝本地服务").findOne(100)) {
            text("下一步").findOne().click();
            sleep(500);
            if (textContains("始终允许").findOne(500)) {
                textContains("始终允许").findOne().click();
            } else {
                text("仅在使用中允许").findOne().click();
            }
        }
        if (text("请将球滑向篮球框中").findOne(100)) {
            for (; ;) {
                if (text("请将球滑向篮球框中").findOne(500)) {
                    var co1 = findImage(captureScreen(), 篮球, { threshold: 0.7 });
                    var co2 = findImage(captureScreen(), 篮框1, { threshold: 0.7 });
                    var co3 = findImage(captureScreen(), 篮框2, { threshold: 0.7 });
                    if (co1 && (co2 || co3)) {
                        if (co2) {
                            swipe(co1.x + 50, co1.y + 50, co2.x + 100, co2.y + 80, 1500);
                            sleep(1000);
                        } else {
                            swipe(co1.x + 50, co1.y + 50, co3.x + 100, co3.y + 100, 500);
                            sleep(1000);
                        }
                    }
                } else {
                    break;
                }
            }
        }
        if (text("首页").findOnce()) {
            break;
        }
    }
    sleep(300);
    if (textContains("支付宝本地服务").findOne(100)) {
        text("下一步").findOne().click();
        sleep(500);
        if (textContains("始终允许").findOne(100)) {
            textContains("始终允许").findOne().click();
        } else {
            text("仅在使用中允许").findOne().click();
        }
    }
    text("首页").findOne().parent().click();
    for (var i = 0; ; i++) {
        if (text("蚂蚁森林").findOnce()) {
            break;
        }
        if (i > 30) {
            home(); sleep(400); home(); sleep(400);
            if (device.brand == "HONOR") {
                for (; ;) {
                    if (text("一键优化").findOnce()) {
                        text("一键优化").findOne().click(); sleep(500); text("一键优化").findOne().click(); sleep(3000);
                        break;
                    }
                    if (text("一键清理").findOnce()) {
                        text("一键清理").findOne().click(); sleep(500); text("一键清理").findOne().click(); sleep(3000); break;
                    }
                    sleep(200);
                }
            } else {
                idContains("clear_icon").findOne().click(); sleep(500); idContains("clear_icon").findOne().click(); sleep(1000);
            }
            app.startActivity({
                action: "VIEW",
                data: "alipays://platformapi/startapp?appId=20000001"
            });
            i = 0;
            text("首页").findOne();
        }
        sleep(200);
    }
    toast("登录成功！");
    sleep(100);
}

function 清除缓存() {
    console.hide();
    home(); sleep(500);
    home(); sleep(500);
    if (device.brand == "HONOR") {
        for (; ;) {
            if (text("一键优化").findOnce()) {
                text("一键优化").findOne().click();
                sleep(500);
                text("一键优化").findOne().click();
                sleep(3000);
                break;
            }
            if (text("一键清理").findOnce()) {
                text("一键清理").findOne().click();
                sleep(500);
                text("一键清理").findOne().click();
                sleep(3000);
                break;
            }
            sleep(200);
        }
        sleep(1000);
    } else {
        idContains("clear_icon").findOne().click();
        sleep(500);
        idContains("clear_icon").findOne().click();
        sleep(3000);
    }
    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=77700189"
    });
    text("安全知识力").findOne();
}

function 领取体力() {
    var bound = text("50").findOne().bounds();
    for (; ;) {
        click(bound.centerX(), bound.centerY());
        sleep(500);
        if (text("今日可用").findOnce()) {
            break;
        }
    }
    var 分享体力 = text("分享传播").findOne().parent().parent().child(2).findOne(classNameContains("Button")).child(0);
    sleep(300);
    if (分享体力.text() != "已领取" && 分享体力.text() != "立即领取") {
        var bound = 分享体力.bounds();
        click(bound.centerX(), bound.centerY());
        sleep(800);
        text("QQ").findOne().parent().click();
        sleep(800);
        idContains("shareToken_close").findOne().click();
        sleep(800);
        click(bound.centerX(), bound.centerY());
        sleep(800);
        text("QQ").findOne().parent().click();
        sleep(800);
        idContains("shareToken_close").findOne().click();
    }

    for (var i = 0; i < 5; i++) {
        if (text("立即领取").className("android.view.View").findOnce()) {
            var bound = text("立即领取").className("android.view.View").findOne().bounds();
            click(bound.centerX(), bound.centerY());
            sleep(800);
            if (textContains("体力已满").findOnce()) {
                sleep(1000);
                back();
                sleep(500);
                return;
            }

        }
        if (textContains("答题体力已满").findOnce()) {
            sleep(1000);
            back();
            sleep(500);
            return;
        }
        sleep(200);
    }

    back();
    text("安全知识力").findOne();
    sleep(500);
}

function 进入刷分页() {
    if (idContains("otherAccountSwitcher").findOnce() || textContains("登录成功").findOnce()) {
        app.startActivity({
            action: "VIEW",
            data: "alipays://platformapi/startapp?appId=20000001"
        });
        sleep(100);
    }
    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=77700189"
    });
    text("安全知识力").findOne();
    threads.start(function () {
        for (; ;) {
            if (text("继续答题赢大奖").findOnce()) {
                var bound = text("关闭弹层").findOne().bounds();
                sleep(100);
                click(bound.centerX(), bound.centerY());
                break;
            }
            if (text("今日可用").findOnce() || textContains("PK赢积分").findOnce()) {
                break;
            }
            sleep(200);
        }
    });
    if (text("50").findOne().parent().child(1).text() < 41) {
        领取体力();
    }
    清除缓存();
    text("安全知识力").findOne();
    次数 = parseInt(text("50").findOne().parent().child(1).text() / 10);
    sleep(2000);
    click(715, 1250);
    sleep(200);
    click(715, 1250);
    sleep(100);
    var bound = textContains("PK赢积分").findOne().bounds();
    sleep(100);
    click(bound.centerX(), bound.centerY());
    sleep(100);
    textContains("难度等级").findOne();
    sleep(100);
}

function 读取题库() {
    题目 = [];
    答案 = [];
    var i = 0;
    var text = open("/sdcard/脚本/支付宝/附件/题库.json", mode = "r", encoding = "utf-8");
    text.readlines().forEach(function (line) {
        题目[i] = line.match(/(\S*)\|\|/)[1];
        答案[i] = line.match(/\|\|(\S*)/)[1];
        i++;
    });
    log("读取题目数:" + i);
}

function 添加题库() {
    textContains("本局正确率").findOne();
    sleep(2000);
    var bound = textContains("回顾本局答题").findOne().bounds();
    for (var j = 0; j < 2; j++) {
        click(bound.centerX(), bound.centerY()); sleep(200);
    }
    textContains("正确答案").findOne();
    sleep(1000);
    var i = 0;
    textContains("正确答案").find().forEach(function (答案1) {
        新增题目[i] = 答案1.parent().parent().child(0).text();
        新增答案[i] = 答案1.text().replace('正确答案：', '');
        i++;
    });
    for (var i = 0, len1 = 新增题目.length; i < len1; i++) {
        for (var j = 0, len2 = 题目.length; j < len2; j++) {
            if (新增题目[i] == 题目[j]) {
                题目[j] = "null";
                答案[j] = "null";
                break;
            }
        }
    }
    for (var i = 0, len1 = 新增题目.length; i < len1; i++) {
        题目[题目.length] = 新增题目[i];
        答案[答案.length] = 新增答案[i];
    }
    files.write("/sdcard/脚本/支付宝/附件/题库.json", "", encoding = "utf-8");
    var 题目数 = 0;
    for (var i = 0, len = 题目.length; i < len; i++) {
        if (题目[i] != "null") {
            files.append("/sdcard/脚本/支付宝/附件/题库.json", 题目[i] + "||" + 答案[i] + "\n", encoding = "utf-8");
            题目数++;
        }
    }
    log("添加题库题目数:" + 题目数);
    back();
    textContains("本局正确率").findOne();
    添题参数 = 0;
}

function 比较分数(当局) {
    var 父控件 = textContains("/5").findOne().parent().parent().parent().parent().parent().child(0).child(1).child(1);
    var 我的 = parseInt(父控件.child(2).child(1).child(1).text());
    var 你的 = parseInt(父控件.child(4).child(1).child(1).text());
    var t = (我的 - 你的) - ((6 - 当局) * 200);
    if (t > 0) {
        return false;
    } else {
        return true;
    }
}

function 选答案() {
    var 成立控制 = 0;
    for (; ;) {
        var 页面 = textContains("/5").findOne().parent().parent().child(1);
        if (页面.childCount() == 2) {
            if (页面.child(0).childCount() == 1) {
                break;
            }
        }
    }
    var 题目1 = 页面.child(0).child(0).text();
    log("当前题目：" + 题目1);
    for (var i = 0, len = 题目.length; i < len; i++) {
        if (题目1 == 题目[i]) {
            log("已有答案：" + 答案[i]);
            for (var k = 0; k < 1000; k++) {
                var answer = 页面.child(1).findOne(text(答案[i]));
                if (answer) {
                    var bound = answer.bounds();
                    var x = bound.centerX();
                    var y = bound.centerY();
                    //for (var i = 0; i < 15; i++) { click(x, y); }
                    sleep(900); click(x, y); sleep(150); click(x, y); sleep(150); click(x, y);
                    成立控制 = 1;
                    break;
                }
            }
            break;
        }
    }

    if (成立控制 == 0) {
        log("题库没有答案！");
        添题参数 = 1;
        for (; ;) {
            var 页面 = textContains("/5").findOne().parent().parent().child(1);
            if (页面.childCount() == 2) {
                if (页面.child(1).childCount() > 1) {
                    break;
                }
            }
        }
        var bound = 页面.child(1).child(1).bounds();
        for (var j = 0; j < 10; j++) {
            click(bound.centerX(), bound.centerY()); sleep(100);
        }
    }
}

function 选错答案() {
    var 成立控制 = 0;
    for (; ;) {
        var 页面 = textContains("/5").findOne().parent().parent().child(1);
        if (页面.childCount() == 2) {
            if (页面.child(0).childCount() == 1) {
                break;
            }
        }
    }
    var 题目1 = 页面.child(0).child(0).text();
    log("当前题目：" + 题目1);
    for (var i = 0, len = 题目.length; i < len; i++) {
        if (题目1 == 题目[i]) {
            log("选错答案：" + 答案[i] + "！");
            var ci = 0;
            页面.child(1).children().forEach(function (选项) {
                if (ci == 0 && 选项.child(0).child(0).text() != 答案[i]) {
                    var bound = 选项.bounds();
                    var x = bound.centerX();
                    var y = bound.centerY();
                    //for (var i = 0; i < 15; i++) { click(x, y); }
                    sleep(900); click(x, y); sleep(150); click(x, y); sleep(150); click(x, y);
                    成立控制 = 1;
                    ci++;
                }
            });
            break;
        }
    }

    if (成立控制 == 0) {
        log("题库没有答案！");
        添题参数 = 1;
        for (; ;) {
            var 页面 = textContains("/5").findOne().parent().parent().child(1);
            if (页面.childCount() == 2) {
                if (页面.child(1).childCount() > 1) {
                    break;
                }
            }
        }
        var bound = 页面.child(1).child(1).bounds();
        for (var j = 0; j < 10; j++) {
            click(bound.centerX(), bound.centerY()); sleep(100);
        }
    }
}

function 答题主体() {
    读取题库();
    log(">进入答题");
    if (难度等级 == 0) {
        var bound = textContains("难度等级：低").findOne().bounds();
    }
    if (难度等级 == 1) {
        var bound = textContains("难度等级：中").findOne().bounds();
    }
    if (难度等级 == 2) {
        var bound = textContains("难度等级：高").findOne().bounds();
    }
    click(bound.centerX(), bound.centerY());
    sleep(200);
    click(bound.centerX(), bound.centerY());
    for (var i = 0; ;) {
        if (text("1/5").findOnce()) {
            break;
        }
        if (text("重试").findOne(2000)) {
            i++;
            if (i > 1) {
                if (次数 == 1) {
                    当前运行账号--;
                }
                console.hide();
                return 000;
            }
            var bound = text("重试").findOne().bounds();
            sleep(500);
            click(bound.centerX(), bound.centerY());
            sleep(4000);
            continue;
        }
        if (textContains("上限").findOnce()) {
            操作账号[当前运行账号] = "null";
            console.info("当前账号今日任务已完成！");
            files.append("/sdcard/脚本/刷积分日志.js", "当前账号今日任务已完成！\n");
            //当前运行账号 = 通信(当前运行账号, 2);
            当前运行账号++;
            胜利次数 = 0;
            平局次数 = 0;
            失败次数 = 0;
            if (当前运行账号 == 6) {
                当前运行账号 = 0;
                console.hide();
                退换账号();
                console.show();
                sleep(100);
                console.setPosition(500, 750);
                console.setSize(600, 500);
                console.info("本轮完成！");
                exit();
            }
            sleep(1000);
            console.hide();
            // app.startActivity({
            //     action: "VIEW",
            //     data: "alipays://platformapi/startapp?appId=20000001"
            // });
            return 000;
        }
        if (textContains("体力不足").findOnce()) {
            //当前运行账号 = 通信(当前运行账号, 1);
            当前运行账号++;
            if (当前运行账号 == 6) {
                当前运行账号 = 0;
                console.hide();
                退换账号();
                console.show();
                sleep(100);
                console.setPosition(500, 750);
                console.setSize(600, 500);
                console.info("本轮完成！");
                exit();
            }
            胜利次数 = 0;
            平局次数 = 0;
            失败次数 = 0;
            // app.startActivity({
            //     action: "VIEW",
            //     data: "alipays://platformapi/startapp?appId=20000001"
            // });
            console.hide();
            return 000;
        }
        if (textContains("人气太旺").findOnce()) {
            // app.startActivity({
            //     action: "VIEW",
            //     data: "alipays://platformapi/startapp?appId=20000001"
            // });
            console.hide();
            return 000;
        }
        i = 0;
    }
    log("开始答题");
    for (var k = 1; k <= 5; k++) {
        for (; ;) {
            if (k > 1 && textContains("没有找到对手").findOnce()) {
                console.hide();
                return 000;
            }
            if (text(k + "/5").findOnce()) {
                break;
            }
            sleep(100);
        }
        if (比较分数(k)) {
            选答案();
        } else {
            选错答案();
            //log("分数已胜出，暂不答题！");
        }
    }
    log("<答题结束");
    for (; ;) {
        if (textContains("继续挑战").findOnce() || textContains("回顾本局").findOnce()) {
            break;
        }
        sleep(500);
    }
}

function 判断胜负() {
    for (; ;) {
        if (textContains("失败").findOnce()) {
            失败次数++;
            var 分数 = textContains("失败").findOne().parent().parent().parent().child(1).child(0).child(1).child(0).child(0).text();
            if (分数 < 1000) {
                return "失败";
            }
        }
        if (textContains("胜利").findOnce()) {
            胜利次数++;
            var 分数 = textContains("胜利").findOne().parent().parent().parent().child(1).child(0).child(1).child(0).child(0).text();
            if (分数 < 1000) {
                return "失败";
            }
            return "胜利";
        }
        if (textContains("平局").findOnce()) {
            平局次数++;
            var 分数 = textContains("平局").findOne().parent().parent().parent().child(1).child(0).child(1).child(0).child(0).text();
            if (分数 < 1000) {
                return "失败";
            }
            return "平局";
        }
        sleep(200);
    }
}

function 刷题整体() {
    console.show();
    sleep(100);
    console.setPosition(500, 50);
    console.setSize(600, 500);
    for (var i = 0; i < 次数 && i < 1; i++) {
        log("===第" + (i + 1) + "/" + 次数 + "次答题===");
        sleep(100);
        if (答题主体() == 000) {
            console.hide();
            return;
        }
        if (操作账号[当前运行账号] == "null") {
            console.hide();
            return;
        }
        var 胜负 = 判断胜负();
        //log("该局比赛" + 胜负);
        if (添题参数 == 1) {
            device.vibrate(500);
            添加题库();
        }
    }
    var 对手名字 = text("回顾本局答题").findOne().parent().parent().parent().parent().parent().child(1).child(1).child(1).text();
    back();
    files.append("/sdcard/脚本/刷积分日志.js", "\n对手名字：" + 对手名字 + "  胜负:" + 胜负 + "\n胜" + 胜利次数 + " 平" + 平局次数 + " 败" + 失败次数 + "\n积分增加" + (胜利次数 - 失败次数) * 入场积分 + "分\n");
    console.info("胜" + 胜利次数 + " 平" + 平局次数 + " 败" + 失败次数 + "\n积分增加" + (胜利次数 - 失败次数) * 入场积分 + "分");
    sleep(3000);
    console.hide();
}

function 判断任务完成() {
    var 完成数量 = 0;
    for (var i = 0; i < 操作账号.length; i++) {
        if (操作账号[i] == "null") {
            完成数量++;
        }
    }
    if (完成数量 == 6) {
        console.show();
        sleep(100);
        console.setPosition(500, 750);
        console.setSize(600, 500);
        files.append("/sdcard/脚本/刷积分日志.js", "=============================\n今日任务已完成！\n");
        console.info("今日任务已完成！");
        engines.execScriptFile("/sdcard/脚本/支付宝/积分总结 1.1.js");
        exit();
    }
}




for (; ;) {
    log("当前运行账号：" + 账号[当前运行账号]);
    files.append("/sdcard/脚本/刷积分日志.js", "=============================\n账号：" + 账号[当前运行账号] + "\n");
    if (操作账号[当前运行账号] == "null") {
        //当前运行账号 = 通信(当前运行账号, 2);
        当前运行账号++;
        胜利次数 = 0;
        平局次数 = 0;
        失败次数 = 0;
        if (当前运行账号 == 6) {
            当前运行账号 = 0;
            console.hide();
            退换账号();
            console.show();
            sleep(100);
            console.setPosition(500, 750);
            console.setSize(600, 500);
            console.info("本轮完成！");
            exit();
        }
        files.append("/sdcard/脚本/刷积分日志.js", "当前账号今日任务已完成！\n");
        continue;
    }
    清除数据();
    退换账号();
    进入刷分页();
    if (次数 > 1) {
        刷题整体();
    }
    if (次数 <= 1) {
        if (次数 == 1) {
            刷题整体();
        }
        当前运行账号++;
        胜利次数 = 0;
        平局次数 = 0;
        失败次数 = 0;
        if (当前运行账号 == 6) {
            if (device.brand != "HONOR") {
                当前运行账号 = 0;
                console.hide();
                退换账号();
            }
            console.show();
            sleep(100);
            console.setPosition(500, 750);
            console.setSize(600, 500);
            console.info("本轮完成！");
            exit();
        }
    }
    判断任务完成();
    sleep(500);
}