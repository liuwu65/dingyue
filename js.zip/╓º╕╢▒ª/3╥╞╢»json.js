auto.waitFor();

var now = new Date();
var h = now.getHours();
var m = now.getMinutes();

if ((h == 6 && m > 50) || (h == 7 && m < 30) || (h == 23 && m > 50) || (h == 0 && m < 5)) {
    var q = files.read("/sdcard/脚本/支付宝/附件/q-max.json");
    var x = files.read("/sdcard/脚本/支付宝/附件/x-max.json");
} else {
    var q = files.read("/sdcard/脚本/支付宝/附件/q-nor.json");
    var x = files.read("/sdcard/脚本/支付宝/附件/x-nor.json");
}

files.write("/sdcard/Android/data/pansong291.xposed.quickenergy.qiufeng/config.json", q);
files.write("/sdcard/Android/data/pansong291.xposed.quickenergy/config.json", x);
files.write("/sdcard/1/config.json", q);
files.write("/sdcard/脚本/config.json", x);


app.launchApp("文件管理");
text("手机").findOne();
swipe(300, 1000, 1000, 1000, 10);
sleep(200);
swipe(300, 1000, 1000, 1000, 10);
sleep(200);
swipe(300, 1000, 1000, 1000, 10);
sleep(200);


desc("点击切换数据").findOne().click();
sleep(700);
text("内部存储设备").findOne().click();
sleep(700);
text("1").findOne().parent().parent().parent().parent().click();
text("config.json").findOne().parent().parent().parent().parent().longClick();
text("移动").findOne().parent().click();
desc("点击切换数据").findOne().click();
sleep(700);
text("应用双开数据").findOne().click();
sleep(700);
text("Android").findOne().parent().parent().parent().parent().click();
text("data").findOne().parent().parent().parent().parent().click();
text("pansong291.xposed.quickenergy.qiufeng").findOne().parent().parent().parent().parent().click();
text("粘贴").findOne().parent().click();
text("应用至全部").findOne().click();
text("替换").findOne().click();
sleep(700);


desc("点击切换数据").findOne().click();
sleep(700);
text("内部存储设备").findOne().click();
sleep(700);
text("脚本").findOne().parent().parent().parent().parent().click();
text("config.json").findOne().parent().parent().parent().parent().longClick();
text("移动").findOne().parent().click();
desc("点击切换数据").findOne().click();
sleep(700);
text("应用双开数据").findOne().click();
sleep(700);
text("Android").findOne().parent().parent().parent().parent().click();
text("data").findOne().parent().parent().parent().parent().click();
text("pansong291.xposed.quickenergy").findOne().parent().parent().parent().parent().click();
text("粘贴").findOne().parent().click();
text("应用至全部").findOne().click();
text("替换").findOne().click();


