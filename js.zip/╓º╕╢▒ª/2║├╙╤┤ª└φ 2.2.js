//支付宝好友 2.2
//修改前缀分析，低能好友选中，加前缀
auto.waitFor();

threads.start(function () {
    for (; ;) {
        if (textContains("是否继续").findOnce()) {
            text("打开").findOne().click();
        }
        sleep(2000);
    }
});

function 群列加好友() {
    function 加好友() {
        textContains("转账").findOne();
        for (; ;) {
            if (textContains("发消息").findOnce()) {
                back();
                textContains("群聊成员").findOne();
                return;
            }
            if (textContains("加好友").findOnce()) {
                break;
            }
        }                               //判断是否是好友

        textContains("加好友").findOne().click();
        sleep(800);
        for (var i = 0; i < 10; i++) {
            if (textContains("今天已经发送").findOne(500)) {
                toast("今日加好友已达上限！");
                exit();
            }
            if (textContains("发消息").findOnce()) {
                sleep(500);
                back();
                return;
            }
            if (textContains("发送").findOnce()) {
                break;
            }
            if (i == 9) {
                back();
                return;
            }
            sleep(500);
        }                               //判断是否已达加好友上限

        setText(0, " ");
        textContains("发送").findOne().click();
        if (textContains("请求已发送").findOne(2000)) {
            back();
            textContains("群聊成员").findOne();
        } else {
            back();
            sleep(500);
            back();
            textContains("转账").findOne();
            back();
            textContains("群聊成员").findOne();
        }
    }

    for (; ;) {
        click(200, 400);
        加好友();
        sleep(200);
        swipe(540, 965, 540, 800, 200);
        sleep(200);
    }
}

function 合列加好友() {
    function 加好友() {
        for (; ;) {
            if (textContains("TA收取你").findOnce() || textContains("种树").findOnce()) {
                back();
                text("蚂蚁森林").findOne();
                return;
            }
            if (textContains("加为好友").findOnce()) {
                break;
            }
        }                               //判断是否是好友
        textContains("加为好友").findOne().click();
        textContains("加好友").findOne().click();
        for (; ;) {
            if (textContains("明天再来").findOne(300)) {
                toast("今日加好友已达上限！");
                exit();
            }
            if (textContains("发送").findOnce()) {
                break;
            }
        }                               //判断是否已达加好友上限
        setText(0, " ");
        textContains("发送").findOne().click();
        textContains("请求已发送").findOne();
        back();
        textContains("加为好友").findOne();
        back();
        text("蚂蚁森林").findOne();
    }

    for (; ;) {
        click(200, 400);
        加好友();
        sleep(500);
        swipe(540, 987, 540, 800, 200);
        sleep(500);
    }
}

function Q列发消息() {
    var 消息数 = dialogs.select("请选择 发送消息间隔数", "9", "19", "49"); if (消息数 == -1) { toast("已停止！"); exit(); }
    var 口令 = dialogs.select("请选择 口令", "lw", "hpp"); if (口令 == -1) { toast("已停止！"); exit(); }
    if (消息数 == 0) { 消息数 = 9; }
    if (消息数 == 1) { 消息数 = 19; }
    if (消息数 == 2) { 消息数 = 49; }
    log(消息数);
    for (; ;) {
        idContains("unreadmsg").find().forEach(function (未读数) {
            if (未读数.text() >= 消息数 || 未读数.text() == "99+") {
                未读数.parent().parent().parent().click();
                idContains("input").findOne();
                sleep(100);
                if (口令 == 0) {
                    setText("Inly32H56Rm复制吱口令，打开支付宝搜索，即可添加我为好友");
                }
                if (口令 == 1) {
                    setText("raPhp0u053T复制吱口令，打开支付宝搜索，即可添加我为好友");
                }
                text("发送").findOne().click();
                back();
                text("群助手").findOne();
                sleep(2000);
            }
        });
        sleep(1000);
        if (text("设为置顶").findOnce()) {
            toast("发送脚本结束！");
            toast("发送脚本结束！");
            break;
        }
    }
}

function xqe好友分析前缀() {

    function 修改昵称(周收) {
        textContains("查看森林").findOne().click();
        for (; ;) {
            if (textContains("我的大树养成").findOne(4000)) {
                break;
            }
            if (text("重新加载").findOnce()) {
                text("重新加载").findOne().click();
                sleep(300);
            }
            sleep(100);
        }
        text("你收取TA").findOne();
        for (; ;) {
            var 实收 = text("你收取TA").findOne().parent().child(text("你收取TA").findOne().parent().childCount() - 1);
            if (实收 && 实收.text().indexOf("g") != -1) {
                break;
            }
        }
        sleep(500);
        var 实收 = parseInt(text("你收取TA").findOne().parent().child(text("你收取TA").findOne().parent().childCount() - 1).text().replace('g', ''));
        if (实收 > 周收) {
            log("实收:" + 实收 + ">" + "周收：" + 周收 + "    -调整");
            周收 = 实收;
        }

        text("我的大树养成记录").findOne().click();
        sleep(200);
        desc("设置").findOne().click();
        sleep(200);
        idContains("set_remarkName").findOne().click();
        textContains("备注名").findOne();
        if (周收 > 99) {
            setText(0, "zaaz" + 周收 + "azza");
        } else if (周收 > 9) {
            setText(0, "zaaz0" + 周收 + "azza");
        } else {
            setText(0, "zaaz00" + 周收 + "azza");
        }

        for (var i = 0; i < 15; i++) {
            if (text("完成").findOne().enabled()) {
                textContains("完成").findOne().click();
                idContains("set_remarkName").findOne();
                break;
            }
            if (i > 10) {
                log("昵称不变！");
                break;
            }
            sleep(200);
        }
        swipe(100, device.height - 20, 1000, device.height - 20, 300);
        textContains("输入查找").findOne();
    }

    function 查一列() {
        className("ListView").findOne().children().forEach(function (项) {
            var 文字 = 项.child(1).text();
            if (文字.indexOf("(0)") == -1) {
                var 起始位 = 文字.indexOf("周收");
                var 结束位 = 文字.indexOf("总收");
                var 周收 = parseInt(文字.substring(起始位 + 2, 结束位 - 1));
                log("周收：" + 周收);

                if (周收 > 0) {
                    if (文字.indexOf("提醒") != -1) {
                        log("提醒好友：有收    -修正");
                        项.longClick();
                        修改昵称(周收);
                    } else if (文字.indexOf("zaaz") != -1) {
                        起始位 = 文字.indexOf("zaaz");
                        结束位 = 文字.indexOf("azza");
                        var 记录 = parseInt(文字.substring(起始位 + 4, 结束位));
                        if (记录 < 周收) {
                            log("记录：" + 记录 + "<" + "周收：" + 周收 + "    -修正");
                            项.longClick();
                            修改昵称(周收);
                        }
                    } else {
                        log("昵称：有收    -修正");
                        项.longClick();
                        修改昵称(周收);
                    }
                } else {
                    log("记录：" + 记录 + ">" + "周收：" + 周收 + "    不处理");
                }
            }
        });
    }

    function 开始() {
        var 开始数 = dialogs.input("输入开始好友数", 1); if (开始数 == null) { toast("已停止！"); exit(); }
        console.show();
        sleep(100);
        console.setPosition(500, 750);
        console.setSize(600, 600);
        if (textContains("好友分析 ").findOnce()) {
            back();
        }
        text("好友分析").findOne().click();
        末尾数 = textContains("好友分析 ").findOne().text().substring(0, 8).replace('好友分析 ', '');
        text("周收").findOne().click();
        sleep(1000);
        log("前往第" + 开始数 + "位处！");
        for (; ;) {
            if (textStartsWith(开始数 + ". ").findOnce()) {
                sleep(500);
                var bound = textContains(开始数 + ". ").findOne().bounds();
                swipe(bound.centerX(), bound.centerY(), bound.centerX(), 200, 300);
                log("已达开始数:" + 开始数);
                break;
            }
            scrollDown();
            sleep(100);
        }
    }

    var 末尾数 = 10;
    开始();

    for (; ;) {
        查一列();
        if (textContains(末尾数 + ". ").findOnce()) {
            toast("结束！");
            break;
        }
        scrollDown();
        log("下一页");
        sleep(200);
    }
}

function 低能好友选中() {
    var number = 0;
    var 停止控制 = 1;
    var time = new Date();
    var 年1 = time.getYear() + 1900;
    var 月1 = time.getMonth() + 1;
    var 日1 = time.getDate();

    function 日期减法(年1, 月1, 日1, 年2, 月2, 日2) {
        if (日1 >= 日2) {
            var 日 = 日1 - 日2;
        } else {
            月1 = 月1 - 1;
            if (月1 == 0) {
                月1 = 12;
                年1--;
            }
            var 日 = 日1 + 30 - 日2;
        }
        if (月1 >= 月2) {
            var 月 = 月1 - 月2;
        } else {
            年1--;
            var 月 = 月1 + 12 - 月2;
        }
        var 年 = 年1 - 年2;
        log("差：" + (年 * 360 + 月 * 30 + 日));
        return (年 * 360 + 月 * 30 + 日);
    }

    function 勾选() {
        className("ListView").findOne().children().forEach(function (删) {
            var 文字 = 删.child(1).text();
            if (文字 && 文字.indexOf("(0)") == -1) {
                var 起始位 = 文字.indexOf("周收");
                var 结束位 = 文字.indexOf("总收");
                var 周收 = parseInt(文字.substring(起始位 + 2, 结束位 - 1));
                if (周收 == 0) {
                    起始位 = 文字.indexOf("（");
                    var 年2 = parseInt(文字.substring(起始位 + 1, 起始位 + 5));
                    var 月2 = parseInt(文字.substring(起始位 + 6, 起始位 + 8));
                    var 日2 = parseInt(文字.substring(起始位 + 9, 起始位 + 11));
                    if (日期减法(年1, 月1, 日1, 年2, 月2, 日2) > 8) {
                        删.click();
                        number++;
                    }
                } else {
                    停止控制 = 0;
                    log("周收：" + 周收);
                }
            }
        });
    }

    sleep(500);
    if (textContains("好友分析 ").findOnce()) {
        back();
    }
    text("好友分析").findOne().click();
    text("周收").findOne().click();
    sleep(1000);
    for (; ;) {
        勾选();
        if (停止控制 == 0) {
            break;
        }
        scrollDown();
        sleep(250);

    }
    console.info("选中 " + number + " 人！");
}

function 友列加前缀() {
    var counts = 0;
    for (; ;) {
        var count = 0;
        idContains("account_contacts_list").findOne().children().every(function (list) {
            if (list.childCount() < 3) {

                var 子控件 = list.child(list.childCount() - 1).child(0);
                if (!子控件) {
                    return true;
                }
                var name = 子控件.child(子控件.childCount() - 1).child(0).text();
                log(name);
                if (name != "我" && name.indexOf("清风") != 0 && name.indexOf("(0)") != 0 && name.indexOf("提醒") != 0 && name.indexOf("zaaz") != 0 && name.indexOf("挂") != 0) {
                    count++;
                    子控件.parent().parent().longClick();
                    textContains("设置备注").findOne().parent().click();
                    textContains("备注名").findOne();
                    setText(0, "zaaz000azza");
                    for (var i = 0; i < 15; i++) {
                        if (text("完成").findOne().enabled()) {
                            textContains("完成").findOne().click();
                            break;
                        }
                        if (i > 10) {
                            log("昵称不变！");
                            back();
                            break;
                        }
                        sleep(200);
                    }
                    textContains("通讯录").findOne().click();
                    sleep(400);
                } else {
                    return true;
                }

            } else {
                return true;
            }
            return false;
        });
        log("count:" + count);
        if (count == 0) {
            counts++;
        } else {
            counts = 0;
        }
        log("counts:" + counts);
        if (counts >= 20) {
            if (textStartsWith("使用与帮助").findOnce()) {
                break;
            }
            swipe(540, 2300, 540, 250, 100);
        }
    }
}




var 功能 = dialogs.select("请选择 功能\n\n(返回退出脚本)", "● 群列加好友", "● 合列加好友", "● Q列发消息", "● xqe好友分析前缀", "● 低能好友选中", "● 友列加前缀"); if (功能 == -1) { toast("已停止！"); exit(); }

if (功能 == 0) {
    群列加好友();
}

if (功能 == 1) {
    合列加好友();
}

if (功能 == 2) {
    Q列发消息();
}

if (功能 == 3) {
    xqe好友分析前缀();
}

if (功能 == 4) {
    低能好友选中();
}

if (功能 == 5) {
    友列加前缀();
}

console.show();
sleep(100);
console.setPosition(400, 400);
console.setSize(730, 900);
console.info("任务完成！");
exit();





