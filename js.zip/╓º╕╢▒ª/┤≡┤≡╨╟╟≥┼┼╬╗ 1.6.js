//答答星球排位 1.6.js
//少量修改
auto.waitFor();
if (!requestScreenCapture()) {
    toast("请求截图失败！");
    exit();
}
var 篮球 = images.read("/sdcard/脚本/支付宝/附件/篮球.jpg");
var 篮框1 = images.read("/sdcard/脚本/支付宝/附件/篮框1.jpg");
var 篮框2 = images.read("/sdcard/脚本/支付宝/附件/篮框2.jpg");

var 账号 = [
    "18873292759",
    "511303a22tm.cdb@sina.cn",
    "13158507242",
    "13788131465",
    "18873208031",
    "hpp0165@163.com",
];
var 密码 = [
    "980118lw,",
    "980118lw,",
    "123456lw,",
    "1997qq",
    "1997qq",
    "123456lw,",
];
var 操作账号 = [0, 1, 2, 3, 4, 5];
var 次数 = 0;
var 添题参数 = 0;
var 题目 = new Array;
var 答案 = new Array;
var 新增题目 = new Array;
var 新增答案 = new Array;

var 当前运行账号 = dialogs.select("请选择 开始账号", 账号); if (当前运行账号 == -1) { toast("已停止！"); exit(); }
app.startActivity({
    action: "VIEW",
    data: "alipays://platformapi/startapp?appId=20000001"
});


function 退换账号() {
    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=20000001"
    });
    sleep(200);
    for (; ;) {
        if (text("换个账号").findOne(50)) {
            text("换个账号").findOne().click();
            sleep(100);
            break;
        }
        if (textContains("点击下方头像登录").findOne(50)) {
            text("换个账号登录").findOne().click();
            sleep(100);
            break;
        }
        if (textContains("账号在其他设备登录").findOne(50)) {
            text("好的").findOne().click();
            sleep(100);
            continue;
        }
        if (text("我的").findOne(50)) {
            text("我的").findOne();
            sleep(100);
            text("我的").findOne().parent().click();
            sleep(500);
            for (; ;) {
                if (idContains("right_container_2").findOnce()) {
                    idContains("right_container_2").findOne().click();
                }
                if (text("换账号登录").findOnce() || text("切换账号").findOnce()) {
                    break;
                }
                sleep(200);
            }
            sleep(100);
            for (; ;) {
                if (text("切换账号").findOnce()) {
                    text("切换账号").findOne().click();
                    break;
                }
                if (text("换账号登录").findOnce()) {
                    if (text("换账号登录").boundsInside(0, 1200, 1080, 1900).findOne().clickable()) {
                        text("换账号登录").boundsInside(0, 1200, 1080, 1900).findOne().click();
                    } else {
                        text("换账号登录").boundsInside(0, 1200, 1080, 1900).findOne().parent().parent().parent().parent().click();
                    }
                    break;
                }
            }
            sleep(100);
            idContains("otherAccountSwitcher").findOne().click();
            sleep(100);
            for (; ;) {
                if (className("android.widget.EditText").findOnce()) {
                    break;
                }
                if (textContains("等待").findOnce()) {
                    textContains("等待").findOne().click();
                }
            }
            break;
        }
        if (text("账号").findOnce()) {
            break;
        }
    }
    sleep(100);
    if (text("密码").findOnce()) {
        sleep(200);
        setText(0, 账号[当前运行账号]);
        setText(1, 密码[当前运行账号]);
        sleep(200);
        setText(0, 账号[当前运行账号]);
        setText(1, 密码[当前运行账号]);
    } else {
        sleep(200);
        setText(0, 账号[当前运行账号]);
        sleep(200);
        for (; ;) {
            if (className("android.widget.EditText").findOnce()) {
                break;
            }
            if (textContains("等待").findOnce()) {
                textContains("等待").findOne().click();
            }
        }
        idContains("nextButton").findOne().click();
        sleep(100);
        for (; ;) {
            if (text("密码").findOnce()) {
                break;
            }
            if (textContains("指纹").findOnce() || text("刷脸登录").findOnce() || text("短信验证码登录").findOnce()) {
                text("换个方式登录").findOne().click();
                text("密码登录").findOne().parent().click();
                sleep(100);
            }
            if (text("请将球滑向篮球框中").findOne(1000)) {
                for (; ;) {
                    if (text("请将球滑向篮球框中").findOne(500)) {
                        var co1 = findImage(captureScreen(), 篮球, { threshold: 0.7 });
                        var co2 = findImage(captureScreen(), 篮框1, { threshold: 0.7 });
                        var co3 = findImage(captureScreen(), 篮框2, { threshold: 0.7 });
                        if (co1 && (co2 || co3)) {
                            if (co2) {
                                swipe(co1.x + 50, co1.y + 50, co2.x + 100, co2.y + 80, 1500);
                                sleep(1000);
                            } else {
                                swipe(co1.x + 50, co1.y + 50, co3.x + 100, co3.y + 100, 500);
                                sleep(1000);
                            }
                        }
                    } else {
                        break;
                    }
                }
            }
        }
        sleep(100);
        setText(0, 账号[当前运行账号]);
        setText(1, 密码[当前运行账号]);
        sleep(200);
        setText(0, 账号[当前运行账号]);
        setText(1, 密码[当前运行账号]);
        for (; ;) {
            if (className("android.widget.EditText").findOnce()) {
                break;
            }
            if (textContains("等待").findOnce()) {
                textContains("等待").findOne().click();
            }
        }
    }
    idContains("loginButton").findOne().click();
    sleep(100);
    for (; ;) {
        if (textContains("选出").findOnce() || textContains("哪").findOnce() || textContains("发送短信验证码").findOnce()) {
            for (; ;) {
                device.vibrate(500);
                if (text("首页").findOne(1500)) {
                    break;
                }
            }
        }
        if (idContains("otherAccountSwitcher").findOnce() || textContains("登录成功").findOnce()) {
            app.startActivity({
                action: "VIEW",
                data: "alipays://platformapi/startapp?appId=20000001"
            });
            sleep(100);
        }
        if (textContains("支付宝本地服务").findOne(200)) {
            text("下一步").findOne().click();
            sleep(500);
            if (textContains("始终允许").findOne(500)) {
                textContains("始终允许").findOne().click();
            } else {
                text("仅在使用中允许").findOne().click();
            }
        }
        if (text("请将球滑向篮球框中").findOne(200)) {
            for (; ;) {
                if (text("请将球滑向篮球框中").findOne(500)) {
                    var co1 = findImage(captureScreen(), 篮球, { threshold: 0.7 });
                    var co2 = findImage(captureScreen(), 篮框1, { threshold: 0.7 });
                    var co3 = findImage(captureScreen(), 篮框2, { threshold: 0.7 });
                    if (co1 && (co2 || co3)) {
                        if (co2) {
                            swipe(co1.x + 50, co1.y + 50, co2.x + 100, co2.y + 80, 1500);
                            sleep(1000);
                        } else {
                            swipe(co1.x + 50, co1.y + 50, co3.x + 100, co3.y + 100, 500);
                            sleep(1000);
                        }
                    }
                } else {
                    break;
                }
            }
        }
        if (text("首页").findOne(200)) {
            break;
        }
    }
    sleep(300);
    if (textContains("支付宝本地服务").findOne(200)) {
        text("下一步").findOne().click();
        sleep(500);
        if (textContains("始终允许").findOne(200)) {
            textContains("始终允许").findOne().click();
        } else {
            text("仅在使用中允许").findOne().click();
        }
    }
    text("首页").findOne().parent().click();
    for (var i = 0; ; i++) {
        if (text("蚂蚁森林").findOnce()) {
            break;
        }
        if (i > 30) {
            home(); sleep(400); home(); sleep(400);
            if (device.brand == "HONOR") {
                for (; ;) {
                    if (text("一键优化").findOnce()) {
                        text("一键优化").findOne().click(); sleep(500); text("一键优化").findOne().click(); sleep(3000);
                        break;
                    }
                    if (text("一键清理").findOnce()) {
                        text("一键清理").findOne().click(); sleep(500); text("一键清理").findOne().click(); sleep(3000); break;
                    }
                    sleep(200);
                }
            } else {
                idContains("clear_icon").findOne().click(); sleep(500); idContains("clear_icon").findOne().click(); sleep(1000);
            }
            app.startActivity({
                action: "VIEW",
                data: "alipays://platformapi/startapp?appId=20000001"
            });
            i = 0;
            text("首页").findOne();
        }
        sleep(200);
    }
    toast("登录成功！");
    sleep(100);
}

function 领取体力() {
    var bound = text("50").findOne().bounds();
    sleep(800);
    click(bound.centerX(), bound.centerY());
    text("今日可用").findOne();
    sleep(300);
    var 分享体力 = text("分享传播").findOne().parent().parent().child(2).findOne(classNameContains("Button")).child(0);
    sleep(300);
    if (分享体力.text() != "已领取" && 分享体力.text() != "立即领取") {
        var bound = 分享体力.bounds();
        click(bound.centerX(), bound.centerY());
        sleep(800);
        text("QQ").findOne().parent().click();
        sleep(800);
        idContains("shareToken_close").findOne().click();
        sleep(800);
    }

    for (var i = 0; i < 5; i++) {
        if (text("立即领取").className("android.view.View").findOnce()) {
            var bound = text("立即领取").className("android.view.View").findOne().bounds();
            click(bound.centerX(), bound.centerY());
            sleep(800);
            if (textContains("体力已满").findOnce()) {
                sleep(1000);
                back();
                sleep(500);
                return;
            }

        }
        if (textContains("答题体力已满").findOnce()) {
            sleep(1000);
            back();
            sleep(500);
            return;
        }
        sleep(200);
    }

    back();
    text("安全知识力").findOne();
    sleep(500);
}

function 进入刷分页() {
    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=77700189"
    });
    for (var i = 0; i < 5;) {
        if (text("安全知识力").findOnce()) {
            i++;
            sleep(300);
        }
        if (text("继续答题赢大奖").findOnce()) {
            var bound = text("关闭弹层").findOne().bounds();
            sleep(100);
            click(bound.centerX(), bound.centerY());
            i = 0;
        }
    }

    // if (text("50").findOne().parent().child(1).text() < 25) {
    //     领取体力();
    // }
    次数 = parseInt(text("50").findOne().parent().child(1).text() / 5);
    click(715, 1250);
    click(715, 1250);
    sleep(300);
    var bound = textContains("排位赛·第").findOne().bounds();
    sleep(300);
    click(bound.centerX(), bound.centerY());
    textContains("单人挑战").findOne();
}

function 读取题库() {
    题目 = [];
    答案 = [];
    var i = 0;
    var text = open("/sdcard/脚本/支付宝/附件/题库.json", mode = "r", encoding = "utf-8");
    text.readlines().forEach(function (line) {
        题目[i] = line.match(/(\S*)\|\|/)[1];
        答案[i] = line.match(/\|\|(\S*)/)[1];
        i++;
    });
    log("读取题目数:" + i);
}

function 添加题库() {
    textContains("小局").findOne();
    sleep(2000);
    var bound = textContains("小局").findOne().bounds();
    for (var j = 0; j < 2; j++) {
        click(bound.centerX(), bound.centerY()); sleep(200);
    }
    textContains("正确答案").findOne();
    sleep(1000);
    var i = 0;
    textContains("正确答案").find().forEach(function (答案1) {
        新增题目[i] = 答案1.parent().parent().child(0).text();
        新增答案[i] = 答案1.text().replace('正确答案：', '');
        i++;
    });
    for (var i = 0, len1 = 新增题目.length; i < len1; i++) {
        for (var j = 0, len2 = 题目.length; j < len2; j++) {
            if (新增题目[i] == 题目[j]) {
                题目[j] = "null";
                答案[j] = "null";
                break;
            }
        }
    }
    for (var i = 0, len1 = 新增题目.length; i < len1; i++) {
        题目[题目.length] = 新增题目[i];
        答案[答案.length] = 新增答案[i];
    }
    files.write("/sdcard/脚本/支付宝/附件/题库.json", "", encoding = "utf-8");
    var 题目数 = 0;
    for (var i = 0, len = 题目.length; i < len; i++) {
        if (题目[i] != "null") {
            files.append("/sdcard/脚本/支付宝/附件/题库.json", 题目[i] + "||" + 答案[i] + "\n", encoding = "utf-8");
            题目数++;
        }
    }
    log("添加题目数:" + 题目数);
    back();
    textContains("小局").findOne();
    添题参数 = 0;
}

function 选答案() {
    var 成立控制 = 0;
    for (; ;) {
        var 页面 = textContains("/10").findOne().parent().parent().child(1);
        if (页面.childCount() == 2) {
            if (页面.child(0).childCount() == 1) {
                break;
            }
        }
    }
    var 题目1 = 页面.child(0).child(0).text();
    log(">当前题目：" + 题目1);
    for (var i = 0, len = 题目.length; i < len; i++) {
        if (题目1 == 题目[i]) {
            log("已有答案：" + 答案[i]);
            for (var k = 0; k < 1000; k++) {
                var answer = 页面.child(1).findOne(text(答案[i]));
                if (answer) {
                    var bound = answer.bounds();
                    var x = bound.centerX();
                    var y = bound.centerY()
                    click(x, y);
                    click(x, y);
                    click(x, y);
                    click(x, y);
                    click(x, y);
                    click(x, y);
                    click(x, y);
                    click(x, y);
                    click(x, y);
                    click(x, y);
                    click(x, y);
                    click(x, y);
                    click(x, y);
                    click(x, y);
                    click(x, y);
                    成立控制 = 1;
                    break;
                }
            }
            break;
        }
    }
    if (成立控制 == 0) {
        log("题库没有答案！");
        添题参数 = 1;
        for (; ;) {
            var 页面 = textContains("/10").findOne().parent().parent().child(1);
            if (页面.childCount() == 2) {
                if (页面.child(1).childCount() > 1) {
                    break;
                }
            }
        }
        var bound = 页面.child(1).child(1).bounds();
        for (var j = 0; j < 10; j++) {
            click(bound.centerX(), bound.centerY()); sleep(100);
        }
    }
}

function 答题主体() {
    var 挑战方式 = 0;
    log(">进入答题");
    if (挑战方式 == 0) {
        var bound = textContains("单人挑战").findOne().bounds();
    }
    if (挑战方式 == 1) {
        var bound = textContains("双人挑战").findOne().bounds();
    }
    click(bound.centerX(), bound.centerY());
    for (; ;) {
        if (textContains("/10").findOnce()) {
            sleep(100);
            break;
        }
        if (text("重试").findOnce()) {
            var bound = text("重试").findOne().bounds();
            sleep(500);
            click(bound.centerX(), bound.centerY());
            sleep(2000);
        }
        if (textContains("体力不足").findOnce()) {
            app.startActivity({
                action: "VIEW",
                data: "alipays://platformapi/startapp?appId=20000001"
            });
            console.hide();
            return 000;
        }
        if (textContains("上限").findOnce()) {
            console.info("运行结束！");
            exit();
        }
    }
    log("开始答题");
    for (var i = 1; i <= 10; i++) {
        for (; ;) {
            if (textContains((i + "/10")).findOnce()) {
                break;
            }
            sleep(200);
        }
        选答案();
    }

    log("<答题结束");
    for (; ;) {
        if (textContains("继续挑战").findOnce() || textContains("小局").findOnce() || textContains("下一步").findOnce() || textContains("双人对战").findOnce()) {
            break;
        }
        sleep(500);
    }
    sleep(1000);
}

function 判断胜负() {
    for (; ;) {
        if (textContains("胜利").findOnce()) {
            var bound = textContains("继续挑战").findOne().parent().parent().parent().child(0).bounds();
            click(bound.centerX(), bound.centerY());
            sleep(200);
        }
        if (textContains("下一步").findOnce()) {
            sleep(300);
            var bound = textContains("下一步").findOne().bounds();
            click(bound.centerX(), bound.centerY());
        }
        if (textContains("我知道了").findOnce()) {
            sleep(300);
            var bound = textContains("我知道了").findOne().bounds();
            click(bound.centerX(), bound.centerY());
            return;
        }
        if (textContains("失败").findOnce() || textContains("游戏结束").findOnce() || textContains("小局").findOnce() || textContains("双人对战").findOnce()) {
            return;
        }
        sleep(300);
    }
}

function 刷题整体() {
    console.show();
    sleep(100);
    console.setPosition(500, 50);
    console.setSize(600, 500);
    for (var i = 0; i < 次数; i++) {
        log("===第" + (i + 1) + "/" + 次数 + "次答题===");
        读取题库();
        if (答题主体() == 000) {
            console.hide();
            return;
        }
        判断胜负();
        if (textContains("小局").findOne(1000) && 添题参数 == 1) {
            device.vibrate(500);
            添加题库();
        }
        back();
        sleep(1000);
    }
    console.info("运行结束！");
    sleep(2000);
    console.hide();
}

function 判断任务完成() {
    var 完成数量 = 0;
    for (var i = 0; i < 操作账号.length; i++) {
        if (操作账号[i] == "null") {
            完成数量++;
        }
    }
    if (完成数量 == 6) {
        console.show();
        sleep(100);
        console.setPosition(500, 750);
        console.setSize(600, 500);
        files.append("/sdcard/脚本/刷积分日志.js", "=============================\n今日任务已完成！\n");
        console.info("今日任务已完成！");
        exit();
    }
}


for (; ; 当前运行账号++) {
    log("当前运行账号：" + 账号[当前运行账号]);
    files.append("/sdcard/脚本/刷积分日志.js", "=============================\n账号：" + 账号[当前运行账号] + "\n");
    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=20000001"
    });

    退换账号();
    进入刷分页();
    if (次数 >= 1) {
        刷题整体();
    } else {
        // console.show();
        // sleep(100);
        // console.setPosition(500, 50);
        // console.setSize(600, 500);
        log("当前运行账号 体力不足！");
        //log("等待10分钟恢复体力！");
        if (device.brand != "HONOR") {
            当前运行账号 = 0;
            console.hide();
            退换账号();
        }
        console.show();
        sleep(100);
        console.setPosition(500, 750);
        console.setSize(600, 500);
        console.info("本轮完成！");
        exit();
    }
    //判断任务完成();
    if (当前运行账号 == 5) {
        当前运行账号 = -1;
    }
    sleep(500);
}


