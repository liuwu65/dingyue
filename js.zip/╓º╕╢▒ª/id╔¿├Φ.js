auto.waitFor();
if (!requestScreenCapture()) {
    toast("请求截图失败！");
    exit();
}
if (device.brand == "HONOR") {
    var 开小差 = images.read("/sdcard/脚本/支付宝/附件/华为开小差.jpg");
} else {
    var 开小差 = images.read("/sdcard/脚本/支付宝/附件/开小差.jpg");
}
var 初始id = files.read("/sdcard/1/初始id.txt");
var 收集数量 = 0;
console.show();
sleep(100);
console.setPosition(500, 50);
console.setSize(600, 500);


threads.start(function () {
    for (; ;) {
        if (textContains("是否继续").findOnce()) {
            text("打开").findOne().click();
        }

        if (text("首页").findOnce()) {
            var link = "alipays://platformapi/startapp?saId=10000007&qrcode=https%3A%2F%2F60000002.h5app.alipay.com%2Fwww%2Fhome.html%3FuserId%3D" + 初始id;
            app.startActivity({
                action: "VIEW",
                data: link
            });
        }
        sleep(2000);
    }
});

function 进入判断() {
    for (; ;) {
        if (textContains("稍等片刻").findOnce()) {
            for (var i = 0; i < 30; i++) {
                var jpg = findImage(captureScreen(), 开小差);
                if (jpg) {
                    log("不存在");
                    sleep(2000);
                    return 0;
                }

                if (idContains("J_userEnergy").findOnce()) {
                    var g = idContains("J_userEnergy").findOne().text().replace('g', '');
                    if (g = null || g < 10) {
                        log("无能量");
                        return 0;
                    } else {
                        return 1;
                    }
                }

                if (i > 20) {
                    if (text("重新加载").findOnce()) {
                        text("重新加载").findOne().click();
                    }
                }

                sleep(200);
            }
        }
        sleep(200);
    }
}

function 清除缓存() {
    log("切换账号清除缓存！");
    home(); sleep(500);
    home(); sleep(500);
    home(); sleep(500);
    if (device.brand == "HONOR") {
        for (; ;) {
            if (text("一键优化").findOnce()) {
                text("一键优化").findOne().click();
                sleep(500);
                text("一键优化").findOne().click();
                sleep(5000);
                break;
            }
            if (text("一键清理").findOnce()) {
                text("一键清理").findOne().click();
                sleep(500);
                text("一键清理").findOne().click();
                sleep(5000);
                break;
            }
            sleep(200);
        }
        sleep(3000);
    } else {
        idContains("clear_icon").findOne().click();
        sleep(500);
        idContains("clear_icon").findOne().click();
        sleep(3000);
    }
}

for (var i = 0; i < 100000; 初始id++, i++) {
    if (i % 1000 == 999) {
        log("清除缓存");
        清除缓存();
    }
    log("第" + i + "次");
    var link = "alipays://platformapi/startapp?saId=10000007&qrcode=https%3A%2F%2F60000002.h5app.alipay.com%2Fwww%2Fhome.html%3FuserId%3D" + 初始id;
    app.startActivity({
        action: "VIEW",
        data: link
    });
    log("当前id:" + 初始id);
    if (进入判断() == 1) {
        files.append("/sdcard/1/收集id.txt", 初始id + "\n");
        收集数量++;
        console.info("可用id:" + 初始id);
    }
    files.write("/sdcard/1/初始id.txt", 初始id);
    log("已收集数量:" + 收集数量);
}

