
auto.waitFor();
if (!requestScreenCapture()) {
    toast("请求截图失败！");
    exit();
}
var 篮球 = images.read("/sdcard/脚本/支付宝/附件/篮球.jpg");
var 篮框1 = images.read("/sdcard/脚本/支付宝/附件/篮框1.jpg");
var 篮框2 = images.read("/sdcard/脚本/支付宝/附件/篮框2.jpg");

var 账号 = [
    "hpp0165@163.com",
    "13158507242",
    "18873208031",
    "511303a22tm.cdb@sina.cn",
    "13788131465",
    "18873292759"
];
var 密码 = [
    "123456lw,",
    "123456lw,",
    "1997qq",
    "980118lw,",
    "1997qq",
    "980118lw,"
];

function 退换账号() {
    text("我的").findOne().parent().click();
    sleep(1000);
    idContains("right_container_2").findOne().click();
    sleep(1000);
    text("换账号登录").findOne();
    sleep(200);
    text("换账号登录").boundsInside(0, 1360, 1080, 1900).findOne().parent().parent().parent().parent().click();
    sleep(200);
    idContains("otherAccountSwitcher").findOne().click();
    sleep(200);
    for (; ;) {
        if (className("android.widget.EditText").findOnce()) {
            break;
        }
        if (textContains("等待").findOnce()) {
            textContains("等待").findOne().click();
        }
    }
    sleep(200);
    setText(0, 账号[i]);
    sleep(200);
    for (; ;) {
        if (className("android.widget.EditText").findOnce()) {
            break;
        }
        if (textContains("等待").findOnce()) {
            textContains("等待").findOne().click();
        }
    }
    idContains("nextButton").findOne().click();
    for (; ;) {
        if (text("密码").findOnce()) {
            break;
        }
        if (text("刷脸登录").findOnce() || text("短信验证码登录").findOnce()) {
            text("换个方式登录").findOne().click();
            text("密码登录").findOne().parent().click();
            sleep(500);
        }
        if (text("请将球滑向篮球框中").findOne(1000)) {
            for (; ;) {
                if (text("请将球滑向篮球框中").findOne(500)) {
                    var co1 = findImage(captureScreen(), 篮球, { threshold: 0.7 });
                    var co2 = findImage(captureScreen(), 篮框1, { threshold: 0.7 });
                    var co3 = findImage(captureScreen(), 篮框2, { threshold: 0.7 });
                    if (co1 && (co2 || co3)) {
                        if (co2) {
                            swipe(co1.x + 50, co1.y + 50, co2.x + 100, co2.y + 80, 1500);
                            sleep(500);
                        } else {
                            swipe(co1.x + 50, co1.y + 50, co3.x + 100, co3.y + 100, 500);
                            sleep(500);
                        }
                    }
                } else {
                    break;
                }
            }
        }
    }
    sleep(200);
    setText(1, 密码[i]);
    for (; ;) {
        if (className("android.widget.EditText").findOnce()) {
            break;
        }
        if (textContains("等待").findOnce()) {
            textContains("等待").findOne().click();
        }
    }
    idContains("loginButton").findOne().click();
    for (; ;) {
        if (text("请将球滑向篮球框中").findOne(1000)) {
            for (; ;) {
                if (text("请将球滑向篮球框中").findOne(500)) {
                    var co1 = findImage(captureScreen(), 篮球, { threshold: 0.7 });
                    var co2 = findImage(captureScreen(), 篮框1, { threshold: 0.7 });
                    var co3 = findImage(captureScreen(), 篮框2, { threshold: 0.7 });
                    if (co1 && (co2 || co3)) {
                        if (co2) {
                            swipe(co1.x + 50, co1.y + 50, co2.x + 100, co2.y + 80, 1500);
                            sleep(500);
                        } else {
                            swipe(co1.x + 50, co1.y + 50, co3.x + 100, co3.y + 100, 500);
                            sleep(500);
                        }
                    }
                } else {
                    break;
                }
            }
        }

        if (idContains("otherAccountSwitcher").findOnce()) {
            app.startActivity({
                action: "VIEW",
                data: "alipays://platformapi/startapp?appId=20000001"
            });
            sleep(500);
        }
        
        if (textContains("选出您").findOnce() || textContains("哪个").findOnce()) {
            for (; ;) {
                device.vibrate(500);
                if (text("首页").findOne(1500)) {
                    files.append("/sdcard/脚本/切换账号日志.js", "登录验证： " + 账号[操作账号[i]] + "\n");
                    break;
                }
            }
        }

        if (text("首页").findOne(1000)) {
            break;
        }
    }
    sleep(200);
    text("首页").findOne();
    toast("登录成功！");
    sleep(1000);
}

function 抽奖() {
    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=20000160"
    });
    text("领积分").findOne().click();
    sleep(3000);
    text("积分任务 查看历史任务").findOne().parent().find(className("android.widget.ListView"))[0].child(1).child(0).click();
    for (; ;) {
        text("我的抽奖").findOne();
        if (textContains("积分参加").findOne(3000)) {
            textContains("积分参加").findOne().click();
            text("奖品详情").findOne();
            sleep(500);
            var bound = text("参与抽奖").findOne().bounds();
            click(bound.centerX(), bound.centerY());
            text("去看看").findOne();
            back();
            sleep(1500);
        } else {
            break;
        }
    }
    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=20000001"
    });
}

app.startActivity({
    action: "VIEW",
    data: "alipays://platformapi/startapp?appId=20000001"
});
text("首页").findOne();

for (var i = 0; i < 6; i++) {
    退换账号();
    抽奖();
}

console.show();
sleep(100);
console.setPosition(400, 400);
console.setSize(730, 900);
console.info("所有账号操作已完成！");