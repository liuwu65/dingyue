auto.waitFor();

var 题目 = new Array;
var 答案 = new Array;
console.show();
sleep(100);
console.setPosition(500, 50);
console.setSize(600, 500);
var 原始数量=0;
var 现在数量=0;


function 读取题库() {
    log(">开始读取题库");
    题目 = [];
    答案 = [];
    var i = 0;
    var text = open("/sdcard/1/QQfile_recv/题库.json", mode = "r", encoding = "utf-8", bufferSize = 8192);
    text.readlines().forEach(function (line) {
        if (i % 2 == 0) {
            题目[i / 2] = line;
            i++;
        } else {
            答案[Math.floor(i / 2)] = line;
            i++;
        }
    });
    sleep(2000);
    原始数量=题目.length;
    log("<读取成功");
}

function 添加题库() {
    for (var i = 0, len = 题目.length; i < len - 1; i++) {
        log(i+"："+题目[i]);
        for (var j = i + 1, len = 题目.length; j < len; j++) {
            if (题目[i] == 题目[j]) {
                题目[i] = "null";
                答案[i] = "null";
                break;
            }
        }
        log(i+"："+题目[i]);
    }
    files.write("/sdcard/1/QQfile_recv/题库.json", "", encoding = "utf-8");
    for (var i = 0, len = 题目.length; i < len; i++) {
        if (题目[i] != "null") {
            files.append("/sdcard/1/QQfile_recv/题库.json", 题目[i] + "\n", encoding = "utf-8");
            files.append("/sdcard/1/QQfile_recv/题库.json", 答案[i] + "\n", encoding = "utf-8");
            现在数量++;
        }
    }

    log("原始数量:" + 原始数量 + "\n现在数量:" + 现在数量);
    log("<题库添加成功");
}


读取题库();
添加题库();


