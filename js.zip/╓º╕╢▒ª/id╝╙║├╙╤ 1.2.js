//加优质好友 1.2
//优化结构
auto.waitFor();
if (!requestScreenCapture()) {
    toast("请求截图失败！");
    exit();
}
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}

threads.start(function () {
    for (; ;) {
        if (textContains("是否继续").findOnce()) {
            text("打开").findOne().click();
        }
        sleep(2000);
    }
});


var 操作频繁 = images.read("/sdcard/脚本/支付宝/附件/操作频繁.jpg");
if (device.brand == "HONOR") {
    var 开小差 = images.read("/sdcard/脚本/支付宝/附件/华为开小差.jpg");
} else {
    var 开小差 = images.read("/sdcard/脚本/支付宝/附件/开小差.jpg");
}
var id库 = new Array;


function 进入判断() {
    for (; ;) {
        if (textContains("稍等片刻").findOnce()) {
            for (var i = 0; i < 30; i++) {
                var jpg = findImage(captureScreen(), 开小差);
                if (jpg) {
                    log("不存在");
                    sleep(2000);
                    return 0;
                }
                if (textContains("此用户已注销").findOnce()) {
                    log("不存在");
                    sleep(2000);
                    return 0;
                }
                if (idContains("J_userEnergy").findOnce()) {
                    return 1;
                }

                if (i > 20) {
                    if (text("重新加载").findOnce()) {
                        text("重新加载").findOne().click();
                    }
                }

                sleep(200);
            }
        }
        sleep(200);
    }
}

function id加好友() {
    textContains("我的大树养成").findOne().click();
    textContains("转账").findOne();
    for (; ;) {
        if (textContains("发消息").findOnce()) {
            return;
        }
        if (textContains("加好友").findOnce()) {
            sleep(1000);
            break;
        }
    }
    textContains("加好友").findOne().click();
    for (var i = 0; i < 10; i++) {
        if (textContains("今天已经发送").findOne(500)) {
            toast("今日加好友已达上限！");
            return "end";
        }
        var jpg = findImage(captureScreen(), 操作频繁);
        if (jpg) {
            log("操作频繁");
            toast("操作频繁"); toast("操作频繁");
            return "end";
        }
        if (textContains("发消息").findOnce()) {
            sleep(500);
            return;
        }
        if (textContains("发送").findOnce()) {
            break;
        }
        if (i == 9) {
            return;
        }
        sleep(300);
    }
    setText(0, " ");
    sleep(200);
    textContains("发送").findOne().click();
    sleep(300);
}

function 读取id() {
    var i = 0;
    var textline = open("/sdcard/1/好友id.txt", mode = "r", encoding = "utf-8", bufferSize = 8192);
    textline.readlines().forEach(function (line) {
        id库[i] = line;
        i++;
    });
}

function 重写id() {
    files.write("/sdcard/1/好友id.txt", "", encoding = "utf-8");
    for (i = 0, len = id库.length; i < len; i++) {
        if (id库[i] != "null") {
            files.append("/sdcard/1/好友id.txt", id库[i] + "\n", encoding = "utf-8");
        }
    }
}


for (; ;) {
    读取id();
    var link = "alipays://platformapi/startapp?saId=10000007&qrcode=https%3A%2F%2F60000002.h5app.alipay.com%2Fwww%2Fhome.html%3FuserId%3D" + id库[0];
    app.startActivity({
        action: "VIEW",
        data: link
    });
    if (进入判断() != 0) {
        sleep(500);
        if (id加好友() == "end") {
            break;
        } else {
            id库[0] = "null";
        }
    } else {
        id库[0] = "null";
    }
    重写id();
}
exit();




























































































