//蚂蚁辅助 5.4.js
//小修改
auto.waitFor();
if (!requestScreenCapture()) {
    toast("请求截图失败！");
    exit();
}

var 账号 = [
    //"54mtk304@t.odmail.cn",
    // "656565651@t.odmail.cn",
    // "656565652@t.odmail.cn",
    // "656565653@t.odmail.cn",
    // "656565654@t.odmail.cn",
    // //"656565655@t.odmail.cn",
    // "656565656@t.odmail.cn",
    // //"656565657@t.odmail.cn",
    // //"656565658@t.odmail.cn",
    // "656565659@t.odmail.cn",
    // "6565656510@t.odmail.cn",
    // //"6565656511@t.odmail.cn",
    // //"6565656512@t.odmail.cn",
    // //"6565656513@t.odmail.cn",
    // //"6565656514@t.odmail.cn",
    // "lw0165656565@163.com",
    "hpp0165@163.com",
    //"hpp0265@163.com",
    //"hpp0365@163.com",
    //"hpp0465@163.com",
    //"hpp0565@163.com",
    //"15281718257",
    "13158507242",
    "18873208031",
    "511303a22tm.cdb@sina.cn",
    "13788131465",
    "18873292759"
];
var 密码 = [
    // "123456lw,",
    // "123456lw,",
    // "123456lw,",
    // "123456lw,",
    // "123456lw,",
    // "123456lw,",
    // "123456lw,",
    // "123456lw,",
    // "123456lw,",
    // "123456lw,",
    // "123456lw,",
    // "123456lw,",
    //"123456lw,",
    //"123456lw,",
    //"123456lw,",
    //"123456lw,",
    //"123456lw,",
    //"123456lw,",
    //"123456lw,",
    //"123456lw,",
    //"123456lw,",
    "123456lw,",
    "123456lw,",
    "1997qq",
    "980118lw,",
    "1997qq",
    "980118lw,"
];


function 退换账号() {
    if (功能 == 0) {
        if (出错账号 == 1) {
            for (var j = 0; ; j++) {
                if (i == 0)
                    break;
                sleep(1000);
                if ((间隔 - j) <= 0)
                    break;
                if ((间隔 - j) % 5 == 0) {
                    toast("还剩" + (间隔 - j) + "秒切换！");
                }
            }
        }
        text("我的").findOne().parent().click();
        sleep(1000);
        idContains("right_container_2").findOne().click();
        sleep(1000);
    }
    if (功能 == 1) {
        toast("需要换账号时，\n进入设置界面自动切换！");
        text("换账号登录").findOne();
    }
    if (功能 == 2) {
        text("我的").findOne().parent().click();
        sleep(1000);
        idContains("right_container_2").findOne().click();
        sleep(1000);
    }
    出错账号 = 1;

    for (; ;) {
        if (text("切换账号").findOnce()) {
            text("切换账号").findOne().click();
            break;
        }
        if (text("换账号登录").findOnce()) {
            if (text("换账号登录").boundsInside(0, 1200, 1080, 1900).findOne().clickable()) {
                text("换账号登录").boundsInside(0, 1200, 1080, 1900).findOne().click();
            } else {
                text("换账号登录").boundsInside(0, 1200, 1080, 1900).findOne().parent().parent().parent().parent().click();
            }
            break;
        }
    }
    sleep(200);
    idContains("otherAccountSwitcher").findOne().click();
    sleep(200);
    for (; ;) {
        if (className("android.widget.EditText").findOnce()) {
            break;
        }
        if (textContains("等待").findOnce()) {
            textContains("等待").findOne().click();
        }
    }
    sleep(200);
    setText(0, 账号[操作账号[i]]);
    sleep(200);
    for (; ;) {
        if (className("android.widget.EditText").findOnce()) {
            break;
        }
        if (textContains("等待").findOnce()) {
            textContains("等待").findOne().click();
        }
    }
    idContains("nextButton").findOne().click();
    for (; ;) {
        if (text("密码").findOnce()) {
            break;
        }
        if (text("刷脸登录").findOnce() || text("短信验证码登录").findOnce()) {
            text("换个方式登录").findOne().click();
            text("密码登录").findOne().parent().click();
            sleep(500);
        }
    }
    sleep(200);
    setText(0, 账号[操作账号[i]]);
    setText(1, 密码[操作账号[i]]);
    sleep(200);
    setText(0, 账号[操作账号[i]]);
    setText(1, 密码[操作账号[i]]);
    for (; ;) {
        if (className("android.widget.EditText").findOnce()) {
            break;
        }
        if (textContains("等待").findOnce()) {
            textContains("等待").findOne().click();
        }
    }
    idContains("loginButton").findOne().click();
    for (; ;) {
        if (idContains("otherAccountSwitcher").findOnce() || textContains("登录成功").findOnce() || textContains("指纹").findOnce()) {
            app.startActivity({
                action: "VIEW",
                data: "alipays://platformapi/startapp?appId=20000001"
            });
            sleep(100);
        }

        if (textContains("身份验证").findOnce()) {
            app.startActivity({
                action: "VIEW",
                data: "alipays://platformapi/startapp?appId=20000001"
            });
            files.append("/sdcard/脚本/切换账号日志.js", "登录失败： " + 账号[操作账号[i]] + "\n");
            出错账号 = 0;
            text("首页").findOne();
            break;
        }

        if (textContains("发送短信验证码").findOnce()) {
            if ((!textContains("131").findOne(500)) && (!textContains("131").findOne(500))) {
                app.startActivity({
                    action: "VIEW",
                    data: "alipays://platformapi/startapp?appId=20000001"
                });
                files.append("/sdcard/脚本/切换账号日志.js", "登录失败： " + 账号[操作账号[i]] + "\n");
                出错账号 = 0;
                text("首页").findOne();
                break;
            }
        }

        if (text("首页").findOne(1000)) {
            break;
        }
    }
    sleep(200);
    text("首页").findOne().parent().click();
    home(); sleep(400); home(); sleep(400);
    if (device.brand == "HONOR") {
        for (; ;) {
            if (text("一键优化").findOnce()) {
                text("一键优化").findOne().click(); sleep(500); text("一键优化").findOne().click(); sleep(3000);
                break;
            }
            if (text("一键清理").findOnce()) {
                text("一键清理").findOne().click(); sleep(500); text("一键清理").findOne().click(); sleep(3000); break;
            }
            sleep(200);
        }
    } else {
        idContains("clear_icon").findOne().click(); sleep(500); idContains("clear_icon").findOne().click(); sleep(1000);
    }
    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=20000001"
    });
    text("首页").findOne();
    toast("登录成功！");
    sleep(1000);
}


function 浇水() {
    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?saId=10000007&qrcode=https%3A%2F%2F60000002.h5app.alipay.com%2Fwww%2Fhome.html%3FuserId%3D2088422866277565"
    });
    for (; ;) {
        if (text("打开").findOnce()) {
            text("打开").findOne().click();
        }
        if (textContains("我的大树养成").findOnce()) {
            sleep(1000);
            break;
        }
    }
    for (; ;) {
        var 浇水按钮 = text("浇水").findOne().bounds();
        click(浇水按钮.centerX(), 浇水按钮.centerY());
        if (!textContains("提醒TA来收").findOne(5000)) {
            break;
        }
        sleep(1000);
        text("66克").findOne().click();
        sleep(1000);
        text("浇水送祝福").findOne().click();
        sleep(2000);
    }

    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?saId=10000007&qrcode=https%3A%2F%2F60000002.h5app.alipay.com%2Fwww%2Fhome.html%3FuserId%3D2088122572818057"
    });
    sleep(2000);
    if (text("打开").findOne(2000)) {
        text("打开").findOne().click();
    }
    sleep(2000);
    for (; ;) {
        if (textContains("我的大树养成").findOnce()) {
            sleep(1000);
            break;
        }
    }

    for (; ;) {
        var 浇水按钮 = text("浇水").findOne().bounds();
        click(浇水按钮.centerX(), 浇水按钮.centerY());
        if (!textContains("提醒TA来收").findOne(5000)) {
            break;
        }
        sleep(1000);
        text("66克").findOne().click();
        sleep(1000);
        text("浇水送祝福").findOne().click();
        sleep(2000);
    }

    app.startActivity({
        action: "VIEW",
        data: "alipays://platformapi/startapp?appId=20000001"
    });
    text("首页").findOne();
}






var 功能 = dialogs.select("请选择 功能\n\n(返回退出脚本)", "● 自动定时切号", "● 半自动切号", "● 自动浇水"); if (功能 == -1) { toast("已停止！"); exit(); }
var 出错账号 = 1;
var 默认选择项 = [''];
for (var i = 0; i < 账号.length; i++) {
    默认选择项[i] = i;
}





files.append("/sdcard/脚本/切换账号日志.js", "=============================\n");

if (功能 == 0) {
    var 间隔 = dialogs.input("输入切号间隔(单位秒)\n\n(返回退出脚本)", 20); if (间隔 == null) { toast("已停止！"); exit(); }
}

var 操作账号 = dialogs.multiChoice(
    "请选择操作账号",
    账号,
    默认选择项
);
app.startActivity({
    action: "VIEW",
    data: "alipays://platformapi/startapp?appId=20000001"
});
text("首页").findOne();

for (var i = 0; i < 操作账号.length; i++) {
    退换账号();
    if (功能 == 2) {
        if (账号[操作账号[i]] != "18873292759" && 账号[操作账号[i]] != "13788131465") {
            浇水();
        } else {
            sleep(20000);
        }
    }
}

console.show();
sleep(100);
console.setPosition(400, 400);
console.setSize(730, 900);
console.info("所有账号操作已完成！");
