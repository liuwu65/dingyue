auto.waitFor();

for (var i = 0; i < 5; i++) {
    if (text("使用").findOnce()) {
        var 父控件 = text("使用").findOne().parent();
        var 子控件 = 父控件.child(父控件.childCount() - 1);
        子控件.click();
        textContains("侯萍萍").findOne();
        sleep(300);
        var bound = textContains("侯萍萍").findOne().bounds();
        sleep(300);
        click(bound.centerX(), bound.centerY());
        text("赠送").findOne().click();
        sleep(1500);
        i = 0;
        continue;
    }
    sleep(500);
}

