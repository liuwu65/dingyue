auto.waitFor();

if (!requestScreenCapture()) {
    toast("请求截图失败！");
    exit();
}

var 闯关 = images.read("/sdcard/脚本/腾讯/附件/闯关.jpg");
var 跳过1 = images.read("/sdcard/脚本/腾讯/附件/跳过1.jpg");
var 跳过2 = images.read("/sdcard/脚本/腾讯/附件/跳过2.jpg");
var 确定 = images.read("/sdcard/脚本/腾讯/附件/确定.jpg");
var 点击屏幕继续 = images.read("/sdcard/脚本/腾讯/附件/点击屏幕继续.jpg");
var 再次挑战 = images.read("/sdcard/脚本/腾讯/附件/再次挑战.jpg");

for (var i = 0; i < 300;) {
    var jpg = captureScreen();

    var co = findImage(jpg, 闯关);
    if (co) {
        log("1");
        click(co.x + 50, co.y + 50);
        continue;
    }

    var co = findImage(jpg, 跳过1);
    if (co) {
        log("2");
        click(co.x + 50, co.y + 50);
        sleep(1000);
        continue;
    }

    var co = findImage(jpg, 跳过2);
    if (co) {
        log("2");
        click(co.x + 50, co.y + 50);
        sleep(1000);
        continue;
    }

    var co = findImage(jpg, 确定);
    if (co) {
        log("3");
        click(co.x + 50, co.y + 50);
        continue;
    }

    var co = findImage(jpg, 点击屏幕继续);
    if (co) {
        log("4");
        click(co.x + 50, co.y + 50);
        continue;
    }

    var co = findImage(jpg, 再次挑战);
    if (co) {
        log("5");
        click(co.x + 50, co.y + 50);
        i++;
        continue;
    }

}



























































