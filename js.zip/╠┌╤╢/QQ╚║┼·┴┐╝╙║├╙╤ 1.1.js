//QQ群批量加好友 1.1
//优化过程
auto.waitFor();
var t = 1;
var s = 0;
var 操作延迟 = 200;

function 加好友(){
    if(!textContains("添加好友").findOne(10000)){
        if(textContains("风险提示").exists()){
            text("取消").findOne().click();
        }
        if(textContains("无法添加").exists()){
            text("确定").findOne().click();
        }
        if(textContains("正在拉取验证信息").exists()){
            back();
        }
        return;
    }

    if(textContains("问题").exists()){
        text("取消").findOne().click();
        return;
    }

    if(text("填写验证信息").exists())
        className("android.widget.EditText").findOne().setText(" ");
    sleep(操作延迟);sleep(1000);

    if(textContains("加好友验证").exists()){
        back();sleep(1000);
        back();sleep(1000);
        text("取消").findOne().click();
        return;
    }
    text("发送").findOne().click();
    t++;
    sleep(500);

    if(textContains("添加失败").exists()){
        text("确定").findOne().click();sleep(1000);
        text("取消").findOne().click();sleep(1000);
        return;
    }
    
}

for(;;){
    var 加好友按钮=textContains("加好友").boundsInside(700,200,1080,500).findOne(500);
    if(加好友按钮){
        s=0;
        加好友按钮.click();
        加好友();
    }else{
        s++;
        if(s>11){
            break;
        }
    }
    textContains("群聊成员").findOne();
    sleep(操作延迟);
    swipe(540,977,540,800,200);
    if(t%21==0){
        for(var i=0;i<10;i++){
            toast("以防和谐，休息30秒！");
            sleep(3000);
        }
    }
}

toast("添加好友完成！！！")
toast("添加好友完成！！！")
toast("添加好友完成！！！")
