//一键换装 1.0
//
auto.waitFor();

function 名刀() {
    click(200, 470); sleep(40);
    click(350, 390); sleep(40);//
    click(1510, 310); sleep(40);//
    click(200, 470); sleep(40);
    click(2000, 860); sleep(40);
    click(1700, 940); sleep(40);
    click(2000, 860); sleep(40);
    click(2000, 100); sleep(40);
    click(320, 420); sleep(40);
}
function 复活甲() {
    click(200, 470); sleep(40);
    click(350, 620); sleep(40);//
    click(1680, 480); sleep(40);//
    click(200, 470); sleep(40);
    click(2000, 860); sleep(40);
    click(1700, 940); sleep(40);
    click(2000, 860); sleep(40);
    click(2000, 100); sleep(40);
    click(320, 420); sleep(40);
}
function 炽热() {
    click(200, 470); sleep(40);
    click(350, 500); sleep(40);//
    click(1510, 310); sleep(40);//
    click(200, 470); sleep(40);
    click(2000, 860); sleep(40);
    click(1700, 940); sleep(40);
    click(2000, 860); sleep(40);
    click(2000, 100); sleep(40);
    click(320, 420); sleep(40);
}
function 血魔() {
    click(200, 470); sleep(40);
    click(350, 620); sleep(40);//
    click(1670, 320); sleep(40);//
    click(200, 470); sleep(40);
    click(2000, 860); sleep(40);
    click(1700, 940); sleep(40);
    click(2000, 860); sleep(40);
    click(2000, 100); sleep(40);
    click(320, 420); sleep(80);
    click(2090, 410); 
}
function 救赎() {
    click(200, 470); sleep(40);
    click(350, 960); sleep(40);//
    click(850, 480); sleep(40);//
    click(200, 470); sleep(40);
    click(2000, 860); sleep(40);
    click(1700, 940); sleep(40);
    click(2000, 860); sleep(40);
    click(2000, 100); sleep(40);
    click(320, 420); sleep(80);
    click(2090, 410); 
}

var window = floaty.window(
    <vertical >
        <button  padding="0" gravity="center" id="a1" text="血魔" textColor="#000000" textSize="18sp"  w="80" h="30" bg="#44dddd00" />    
        <button  padding="0" gravity="center" id="a2" text="救赎" textColor="#000000" textSize="18sp"  w="80" h="30" bg="#44dddd00" />  
        <button  padding="0" gravity="center" id="a3" text="名刀" textColor="#000000" textSize="18sp"  w="80" h="30" bg="#44dddd00" />    
        <button  padding="0" gravity="center" id="a4" text="复活甲" textColor="#000000" textSize="18sp"  w="80" h="30" bg="#44dddd00" />    
        <button  padding="0" gravity="center" id="a5" text="炽热" textColor="#000000" textSize="18sp"  w="80" h="30" bg="#44dddd00" />    
    </vertical>
);
//window.setSize(500, 400);
window.setPosition(1750, 150);
//window.setAdjustEnabled(!window.isAdjustEnabled());
window.exitOnClose();
window.a1.on("click", () => {
    threads.start(function () {
        血魔();
    });
});
window.a2.on("click", () => {
    threads.start(function () {
        救赎();
    });
});
window.a3.on("click", () => {
    threads.start(function () {
        名刀();
    });
});
window.a4.on("click", () => {
    threads.start(function () {
        复活甲();
    });
});
window.a5.on("click", () => {
    threads.start(function () {
        炽热();
    });
});
setInterval(() => { }, 500);





