auto.waitFor();

var h = dialogs.rawInput("输入小时\n\n（如果小时为个位 需添0）", "1"); if (h == null) { toast("已停止！"); exit(); }
var m = dialogs.rawInput("输入整分钟数\n\n为分钟的十位数字(一个数字)", "3"); if (m == null) { toast("已停止！"); exit(); }
var 时间=h+":"+m;
for (; ;) {
    swipe(540, 300, 540, 1800, 200);
    if (textContains(时间).findOnce()) {
        break;
    }
    swipe(540, 300, 540, 1800, 200);
    if (textContains(时间).findOnce()) {
        break;
    }
    swipe(540, 300, 540, 1800, 200);
    if (textContains(时间).findOnce()) {
        break;
    }
    swipe(540, 300, 540, 1800, 200);
    if (textContains(时间).findOnce()) {
        break;
    }
    swipe(540, 300, 540, 1800, 1100);
    if (textContains(时间).findOnce()) {
        break;
    }
    sleep(300);

}
























