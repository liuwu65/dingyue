auto.waitFor();

if (!requestScreenCapture()) {
    toast("请求截图失败！");
    exit();
}

var 金币 = images.read("/sdcard/脚本/腾讯/金币.jpg");
var 点击领取 = images.read("/sdcard/脚本/腾讯/点击领取.jpg");





function 长按(){
    var thread = threads.start(function(){
        while(true){
            press(540,1700,9999);
        }
    });

}










for (var i = 0; i < 300; i++) {
    log(i);
    for (; ;) {
        sleep(200);
        var co = findImage(captureScreen(), 金币);
        if (co) {
            sleep(500);
            break;
        }
    }
    sleep(1000);
    click(540, 1800);
    sleep(1300);
    swipe(540,100, 540, device.height, 500);
    sleep(500);
    长按();
    for (; ;) {
        var co = findImage(captureScreen(), 点击领取);
        if (co) {
            threads.shutDownAll();
            click(co.x, co.y);
            sleep(500);
            break;
        }
    }
    sleep(1000);
}





