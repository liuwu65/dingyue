//QQ名片点赞 1.3
//自动停止
auto.waitFor();
app.launchApp("QQ");
sleep(1500);
for(;;){
    if(textContains("打卡").findOnce())
        break;
    click(80,130);
    sleep(1000);
}
click(800,200);
descContains("赞").findOne().click();descContains("谁赞过我").findOne();    //进入
//descContains("我赞过谁").findOne().click();     //进入

for(;;){
    desc("赞").find().forEach(function(赞){
        for(var i=0;i<10;i++){
            赞.click();
        }
    })

    if(textContains("显示更多").findOnce()){
            textContains("显示更多").findOne().parent().click();
            sleep(600);
        }
    if(textContains("先了解").findOnce()){
        idContains("h7s").findOne().click();
        sleep(600);
        continue;
    }

    //if(textContains("2020-01").boundsInside(0,1500,1080,1920).findOnce()){break;}
    if(textContains("暂无更多").boundsInside(0,1500,1080,1920).findOnce()){break;}
   
    swipe(540, 1800, 540, 100, 200);    //滑动
}

toast("今日点赞已完成！");
toast("今日点赞已完成！");

