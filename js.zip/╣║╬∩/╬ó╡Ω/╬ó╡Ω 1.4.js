var 名称版本 = "微店 1.4";
//提交按钮改为连续点击，以尝试解决不提交bug；修复未开售判断错误

auto.waitFor();
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}

{
    var 是否备注 = dialogs.select("是否备注？\n\n(返回退出脚本)\n", "● 备注", "● 不备注"); if (是否备注 == -1) { toast("已停止！"); exit(); }
    if (是否备注 == 0) {
        var 备注内容 = dialogs.rawInput("输入备注内容\n\n(返回退出脚本)", ""); if (备注内容 == null) { toast("已停止！"); exit(); }
    }
    var 是否勾选协议 = dialogs.select("是否勾选协议？\n\n(返回退出脚本)\n", "● 勾选", "● 不勾选"); if (是否勾选协议 == -1) { toast("已停止！"); exit(); }
    var 价格判断 = dialogs.select("是否判断价格？\n\n(返回退出脚本)\n", "● 判断价格", "● 不判断价格"); if (价格判断 == -1) { toast("已停止！"); exit(); }
    if (价格判断 == 0) {
        var 理想价格 = dialogs.input("输入物品理想价格\n\n(返回退出脚本)", 50); if (理想价格 == null) { toast("已停止！"); exit(); }
    }
    var 提交方式 = dialogs.select("选择提交方式\n\n(返回退出脚本)\n", "● 提交订单", "● 极速支付"); if (提交方式 == -1) { toast("已停止！"); exit(); }
    var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if (分 == null) { toast("已停止！"); exit(); }
    var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if (秒 == null) { toast("已停止！"); exit(); }
    var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if (延时 == null) { toast("已停止！"); exit(); }

    var time = new Date(http.get("http://www.baidu.com").headers["Date"]);
    var month = time.getMonth() + 1;
    var log = "/sdcard/脚本/日志" + month + "." + time.getDate() + ".js";
    var 日志字串1 = "\n================================\n" + time.getHours() + ":" + time.getMinutes() + ":" + time.getSeconds() + "\n    /----" + 名称版本 + "----/\n";
    if (是否备注 == 0) { var 日志字串2 = "是否备注：备注\n" }
    if (是否备注 == 1) { var 日志字串2 = "是否备注：不备注\n" }

    if (价格判断 == 0) { var 日志字串3 = "理想价格：" + 理想价格 + "\n"; } else { var 日志字串3 = "不判断价格！\n"; }
    if (提交方式 == 0) { var 日志字串4 = "提交方式：提交订单\n"; } else { var 日志字串4 = "极速支付\n"; }
    if (是否勾选协议 == 0) { var 日志字串5 = "勾选协议：勾选\n"; } else { var 日志字串5 = "勾选协议：不勾选\n"; }
    var 日志字串6 = "设定时间：" + 分 + ":" + 秒 + "\n延       时：" + 延时 + "\n";


    var 显示字串 = "      /----" + 名称版本 + "----/\n\n" + 日志字串2 + 日志字串3 + 日志字串4 + 日志字串5 + 日志字串6;
    var 日志字串7 = 日志字串1 + 日志字串2 + 日志字串3 + 日志字串4 + 日志字串5 + 日志字串6;
    files.append(log, 日志字串7);
    var 次数 = 0; var 实际价格 = -1;

}


function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info(显示字串 + "\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(100);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute == 分) {
            if (second <= 秒 - 6) {
                print(minute + ":" + second);
                sleep(800);
                continue;
            } else {
                console.info(minute + ":" + second);
                console.info("还有5秒");
                sleep(2000);
                toast("还有3秒!");
                console.hide();
                sleep(1000);
                break;
            }
        } else {
            sleep(800);
            continue;
        }
    }
    console.hide();
    for (; ;) {
        var second = new Date(http.get("http://www.baidu.com").headers["Date"]).getSeconds();
        if (second >= 秒) {
            sleep(延时);
            return;
        }
    }
}

function 进入判断() {
    for (; ;) {
        if (textContains("总额").findOnce()||textContains("提交订单").findOnce()) {
            return true;
        }
        if (textContains("休息会").findOnce()) {
            var 块 = idContains("nc_1_n1t").findOne().bounds();
            swipe(块.centerX(), 块.centerY(), device.width, 块.centerY(), 30);
            continue;
        }
        if (textContains("我知道了").findOnce()) {
            sleep(1500);
            textContains("我知道了").findOne().click();
            idContains("button_cart_charge").findOne().click();
            次数++;
            continue;
        }
    }
}

function 勾选协议() {
    for (var i = 0; i < 3; i++) {
        scrollDown();
        if (idContains("checkbox").findOnce()) {
            idContains("checkbox").click();
            return true;
        }
    }
    toast("没有协议选项！\n");
    files.append(log, "没有协议选项！\n");
    return false;
}

function 价格() {
    实际价格 = textContains("应付总额").findOne().parent().child(1).text().replace('¥', '');
    if (实际价格 < 理想价格) {
        return true;
    } else {
        return false;
    }
}

function 提交成功判断() {
    for (var i = 0; i < 10; i++) {
        if (textContains("收银台").findOnce()||textContains("支付成功").findOnce()) {
            是否成功 = 1;
            break;
        }
        sleep(300);
    }
}


function 结算模式() {
    toast("抢购开始！！！");
    次数 = 0;
    倒计时();
    for (var i = 0; i < 4; i++) {
        textContains("结算(").findOne().click();
        次数++;
        进入判断();
        if (textContains("商品尚未开售").findOnce() || textContains("购买数量超过").findOnce() || textContains("商品不能购买").findOnce() || textContains("已无库存").findOnce() || textContains("优惠信息变更").findOnce()) {
            back();
            是否成功 = 0;
            continue;
        }
        if (是否备注 == 0) {
            setText(0, 备注内容);
        }
        if (是否勾选协议 == 0) {
            勾选协议();
        }
        if (价格判断 == 0) {
            if (!价格()) {
                back();
                是否成功 = 0;
                continue;
            } 5
        }
        if (提交方式 == 0) {
            for (; ;) {
                text("提交订单").idContains("tv_name").findOne().parent().click();
                if (text("提交订单").idContains("tv_name").findOnce()) {
                    continue;
                } else {
                    break;
                }
            }
        } else {
            for (; ;) {
                text("极速支付").idContains("tv_name").findOne().parent().click();
                if (text("极速支付").idContains("tv_name").findOnce()) {
                    continue;
                } else {
                    break;
                }
            }

        }
        提交成功判断();
        break;
    }
    files.append(log, "最后显示价格：￥ " + 实际价格 + "\n进入次数统计：" + 次数 + "\n===============================\n");
}
结算模式();

