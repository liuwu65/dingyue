var 名称版本 = "购物车 3.8";
//提交订单修改
auto.waitFor();
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}

//设定
{
    var 抢购模式 = dialogs.select("购物车\n\n请选择 抢购模式\n\n(返回退出脚本)\n", "● 结算", "● 刷新", "● 捡漏"); if (抢购模式 == -1) { toast("已停止！"); exit(); }
    if (抢购模式 < 2) {
        var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if (分 == null) { toast("已停止！"); exit(); }
        var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if (秒 == null) { toast("已停止！"); exit(); }
        var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if (延时 == null) { toast("已停止！"); exit(); }
    }
    var 价格判断 = dialogs.select("是否判断价格？\n\n(返回退出脚本)\n", "● 判断价格", "● 不判断价格"); if (价格判断 == -1) { toast("已停止！"); exit(); }
    if (价格判断 == 0) {
        var 理想价格 = dialogs.input("输入物品理想价格\n\n(返回退出脚本)", 50); if (理想价格 == null) { toast("已停止！"); exit(); }
    }
    var 提交延时 = dialogs.input("输入提交延时ms\n\n(返回退出脚本)", 150); if (提交延时 == null) { toast("已停止！"); exit(); }
    var 是否付款 = dialogs.select("是否付款？\n\n(返回退出脚本)\n", "● 付款", "● 不付款"); if (是否付款 == -1) { toast("已停止！"); exit(); }
    if (是否付款 == 0) {
        var 付款密码 = dialogs.select("选择密码\n\n(返回退出脚本)\n", "● 我", "● 小武"); if (付款密码 == -1) { toast("已停止！"); exit(); }
    }
    var 次数 = 0; var 实际价格 = -1; var 是否成功 = 0;
}

//显示
{
    var time = new Date(http.get("http://www.baidu.com").headers["Date"]);
    var month = time.getMonth() + 1;
    var log = "/sdcard/脚本/日志" + month + "." + time.getDate() + ".js";
    var 日志字串1 = "\n================================\n" + time.getHours() + ":" + time.getMinutes() + ":" + time.getSeconds() + "\n    /----" + 名称版本 + "----/\n";
    if (抢购模式 == 0) { var 日志字串2 = "抢购模式：结算模式\n" }
    if (抢购模式 == 1) { var 日志字串2 = "抢购模式：刷新模式\n" }
    if (抢购模式 == 2) { var 日志字串2 = "抢购模式：捡漏模式\n" }
    if (抢购模式 < 2) { var 日志字串3 = "设定时间：" + 分 + ":" + 秒 + "\n延     时：" + 延时 + "\n"; }
    else { var 日志字串3 = ""; }
    if (价格判断 == 0) { var 日志字串4 = "理想价格：" + 理想价格 + "\n"; }
    else { var 日志字串4 = "不判断价格！\n"; }
    if (是否付款 == 0) {
        var 日志字串5 = "付款密码：";
        if (付款密码 == 0) { var 日志字串6 = "我\n提交延时：" + 提交延时 + "\n"; } else { var 日志字串6 = "小武\n提交延时：" + 提交延时 + "\n"; }
    } else {
        var 日志字串5 = "不付款！\n提交延时：" + 提交延时 + "\n"; var 日志字串6 = "";
    }
    var 显示字串 = "      /----" + 名称版本 + "----/\n\n" + 日志字串2 + 日志字串3 + 日志字串4 + 日志字串5 + 日志字串6;
    var 日志字串7 = 日志字串1 + 日志字串2 + 日志字串3 + 日志字串4 + 日志字串5 + 日志字串6;
    files.append(log, 日志字串7);

}

function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info(显示字串 + "\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(100);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute == 分) {
            if (second <= 秒 - 6) {
                print(minute + ":" + second);
                sleep(800);
                continue;
            } else {
                console.info(minute + ":" + second);
                console.info("还有5秒");
                sleep(2000);
                toast("还有3秒!");
                console.hide();
                sleep(1000);
                break;
            }
        } else {
            sleep(800);
            continue;
        }
    }
    console.hide();
    for (; ;) {
        var second = new Date(http.get("http://www.baidu.com").headers["Date"]).getSeconds();
        if (second >= 秒) {
            sleep(延时);
            return;
        }
    }
}

function 进入判断() {
    for (; ;) {
        if (textContains("提交").findOnce()) {
            return true;
        }
        if (textContains("休息会").findOnce()) {
            var 块 = idContains("nc_1_n1t").findOne().bounds();
            swipe(块.centerX(), 块.centerY(), device.width, 块.centerY(), 30);
            continue;
        }
        if (textContains("我知道了").findOnce()) {
            sleep(1500);
            textContains("我知道了").findOne().click();
            idContains("button_cart_charge").findOne().click();
            次数++;
            continue;
        }
    }
}

function 价格() {
    实际价格 = textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥', '');
    if (实际价格 < 理想价格) {
        return true;
    } else {
        return false;
    }
}

function 提交成功判断() {
    for (; ;) {
        if (textContains("我知道了").findOnce()) {
            sleep(1500);
            textContains("我知道了").findOne().click();
            是否成功 = 0;
            break;
        }
        if (textContains("付款详情").findOnce() || textContains("支付宝账号").findOnce() || textContains("免密支付").findOnce()) {
            是否成功 = 1;
            toast("抢购成功！");
            if (是否付款 == 0) {
                付款();
            }
            toast("可在当天日志文件中查看该次抢购相关参数！");
            break;
        }
    }
}

function 付款() {
    for (; ;) {
        if (textContains("立即付款").findOnce()) {
            textContains("立即付款").findOne().parent().parent().click();
            for (; ;) {
                if (textContains("使用密码").findOnce()) {
                    textContains("使用密码").findOne().click();
                }
                if (textContains("请输入支付密码").findOnce()) {
                    break;
                }
            }

            if (付款密码 == 0) {
                text("1").findOne().click();
                text("9").findOne().click();
                text("9").findOne().click();
                text("7").findOne().click();
                text("7").findOne().click();
                text("1").findOne().click();
            } else {
                text("6").findOne().click();
                text("5").findOne().click();
                text("5").findOne().click();
                text("6").findOne().click();
                text("6").findOne().click();
                text("5").findOne().click();
            }
            return;
        }
        if (textContains("免密支付").findOnce()) {
            var 免密 = textContains("可在我的淘宝").findOne().parent().parent();
            免密.child(免密.childCount() - 3).child(0).click();
            return;
        }
    }
}




function 结算模式() {
    toast("抢购开始！！！");
    次数 = 0;
    倒计时();
    for (var i = 0; i < 4; i++) {
        idContains("button_cart_charge").findOne().click();
        次数++;
        进入判断();
        if (textContains("购买数量超过").findOnce() || textContains("商品不能购买").findOnce() || textContains("已无库存").findOnce() || textContains("优惠信息变更").findOnce()) {
            back();
            是否成功 = 0;
            continue;
        }
        if (价格判断 == 0) {
            if (!价格()) {
                back();
                是否成功 = 0;
                continue;
            }
        }
        sleep(提交延时);
        for (; ;) {
            //text("提交订单").findOne().click();
            if (!text("提交订单").findOnce()) {
                break;
            }
            sleep(50);
        }
        提交成功判断();
        break;
    }
    files.append(log, "最后显示价格：￥ " + 实际价格 + "\n进入次数统计：" + 次数 + "\n===============================\n");
    if (是否成功 == 0) {
        toast("抢购失败！自动进入捡漏模式！");
        捡漏模式();
    }
}

function 刷新模式() {
    toast("抢购开始！！！");
    次数 = 0;
    倒计时();
    for (var i = 0; i < 6; i++) {
        swipe(540, 165, 540, 1800, 330);
        次数++;
        textContains("释放刷新").findOne();
        textContains("下拉刷新").findOne();
        text("购物车").boundsInside(0, 0, 540, 250).findOne();
        var checkbox = classNameEndsWith("CheckBox").boundsInside(0, 0, 1080, 510).findOne();
        if (checkbox.enabled()) {
            checkbox.click();
            break;
        }
    }
    textContains("结算(").findOne();
    textContains("结算(").findOne().click();
    进入判断();
    if (价格判断 == 0) {
        if (价格()) {
            sleep(提交延时);
            for (; ;) {
                //text("提交订单").findOne().click();
                if (!text("提交订单").findOnce()) {
                    break;
                }
                sleep(50);
            }
            提交成功判断();
        } else {
            back();
            toast("价格变更！抢购失败！");
        }
    } else {
        sleep(提交延时);
        for (; ;) {
            //text("提交订单").findOne().click();
            if (!text("提交订单").findOnce()) {
                break;
            }
            sleep(50);
        }
        提交成功判断();
    }
    files.append(log, "最后显示价格：￥ " + 实际价格 + "\n刷新次数统计：" + 次数 + "\n===============================\n");
    if (是否成功 == 0) {
        toast("抢购失败！自动进入捡漏模式！");
        捡漏模式();
    }
}

function 捡漏模式() {
    toast("捡漏开始！！！");
    次数 = 0;
    for (; ;) {
        idContains("button_cart_charge").findOne().click();
        进入判断();
        if (textContains("商品不能购买").findOnce()) {
            实际价格 = textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥', '');
            files.append(log, "最后显示价格：￥ " + 实际价格 + "\n捡漏次数统计：" + 次数 + "\n================================\n");
            toast("商品不能购买！可能已下架！");
            exit();
        }
        if (textContains("购买数量超过").findOnce() || textContains("已无库存").findOnce() || textContains("优惠信息变更").findOnce()) {
            sleep(1100);
            back();
            continue;
        }
        if (价格判断 == 0) {
            if (!价格()) {
                sleep(1100);
                back();
                continue;
            }
        }
        sleep(提交延时);
        for (; ;) {
            //text("提交订单").findOne().click();
            if (!text("提交订单").findOnce()) {
                break;
            }
            sleep(50);
        }
        if (textContains("我知道了").findOne(1000)) {
            sleep(1500);
            textContains("我知道了").findOne().click();
            continue;
        } else {
            toast("捡漏成功！！！");
            break;
        }
    }
    files.append(log, "最后显示价格：￥ " + 实际价格 + "\n捡漏次数统计：" + 次数 + "\n================================\n");
    toast("捡漏结束。。。");
    toast("可在当天日志文件中查看该次抢购相关参数！");
}


if (抢购模式 == 0) { 结算模式(); }
if (抢购模式 == 1) { 刷新模式(); }
if (抢购模式 == 2) { 捡漏模式(); }