auto.waitFor();
if (!requestScreenCapture()) { toast("请求截图失败"); exit(); }
var mission_options = dialogs.multiChoice("选择要完成的任务", ['包裹任务', '聚财气红包', '芭芭农场', '天猫农场', '淘金币'], [0, 1, 2, 3, 4])



function package_combat() {
    function Enter_package() {
        if (text("任务数量").findOnce() || text("做任务得包裹").findOnce()) {
            text("做任务得包裹").findOne().parent().parent().click();
            toastLog("已进入任务页面");
            sleep(3000);
        } else {
            launchApp("淘宝");
            toast("等待进入首页");
            desc("首页").findOne();
            toast("进入消息页");
            desc("消息").findOne().click();
            sleep(2000);
            desc("打卡签到群").findOne().parent().click();
            var text1 = 100 * Math.random();
            var url = "https://page.cainiao.com/mcn/pack-factory/index.html?app=ali_tb&cpp=1&&suid=ABA027CE-C341-453B-A542-5405547B2773#/\n----\n复制到淘宝任意一个聊天窗口可以看到活动" + text1;
            classNameContains("EditText").findOne();
            sleep(2000);
            classNameContains("EditText").findOne().setText(url);
            desc("发送").classNameContains("RelativeLayout").findOne().click();
            sleep(1000);
            var bound = desc(url).findOne().bounds();
            click(bound.centerX(), bound.centerY());
            text("做任务得包裹").findOne().parent().parent().click();
            text("任务数量").findOne();
            toastLog("已进入任务页面");
            sleep(3000);
        }
    }

    function mission_exit(text1) {
        if (textContains(text1).findOnce()) {
            click_button = textContains(text1).findOne().parent().parent().parent().child(2);
            if (click_button.text() == "已完成") {
                return 0;
            }
            if (click_button.text() == "去完成") {
                click_button.click();
                return 1;
            }
        }
        return 0;
    }

    function Answer_Question() {
        for (; ;) {
            if (textContains("C、").findOnce()) {
                textContains("C、").findOne().parent().click();
            } else if (textContains("B、").findOnce()) {
                textContains("B、").findOne().parent().click();
            } else {
                textContains("A、").findOne().parent().click();
            }
            sleep(800);
            if (text("换一题").findOnce()) {
                text("换一题").findOne().click();
                sleep(500);
            }
            if (textContains("关闭(").findOnce()) {
                textContains("关闭(").findOne().click();
                break;
            }
        }
        sleep(2000);
    }

    function Shopping_Cart() {
        for (var i = 0; i < 5; i++) {
            var bound = textContains("¥").findOne().bounds();
            click(bound.centerX(), bound.centerY());
            sleep(1000);
            back();
            textContains("上门好服务").findOne();
            sleep(500);
            if (!textContains("加入购物车，即可完成任务").findOnce()) {
                text("做任务得包裹").findOne().parent().parent().click();
                break;
            }
        }
        sleep(2000);
    }

    function day_Shopping_Cart() {
        if (textContains("恭喜获得天天红包").findOne(4000)) {
            text("x").findOne().click();
        }
        sleep(1000);
        for (var i = 0; i < 4; i++) {
            var bound = textContains("￥").findOne().bounds();
            click(bound.centerX(), bound.centerY());
            sleep(2000);
            back();
            text("天天领红包").findOne();
            sleep(500);
            if (textContains("已完成任务").findOnce()) {
                back();
                sleep(1000);
                if (textContains("忍痛离开").findOnce()) {
                    textContains("忍痛离开").findOne().click();
                    back();
                    break;
                }
                break;
            }
        }
        sleep(2000);
    }

    function add_package() {
        var rand_number = "2100";
        for (var i = 0; i < 8; i++) {
            rand_number = rand_number + Math.floor(Math.random() * 10);
        }
        textContains("输入快递单号").findOne();
        sleep(1000);
        classNameContains("EditText").findOne().setText(rand_number);
        sleep(3000);
        var bound = text("添加到包裹列表").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        sleep(2000);
        desc("返回").findOne().click();
        sleep(2000);
    }

    function Browse_goods() {
        for (; ;) {
            if (textContains("滑动开始计时").findOnce() || textContains("浏览主会场商品").findOnce()) {
                break;
            }
            sleep(1000);
        }
        swipe(540, 1800, 540, 300, 500);
        sleep(1000);
        swipe(540, 1800, 540, 300, 500);
        sleep(1000);
        swipe(540, 1800, 540, 300, 500);
        sleep(18000);
        text("做任务得包裹").findOne().parent().parent().click();
        sleep(1000);
    }

    function fruit_sign() {
        sleep(5000);
        click(360, 920);
        sleep(3000); back_mission();
    }

    function back_5() {
        toastLog("5秒返回");
        sleep(5000); back_mission();
    }

    function back_15() {
        toastLog("滑动浏览，约15秒返回");
        sleep(3000); swipe(540, 1800, 540, 300, 500);
        sleep(1000); swipe(540, 1800, 540, 300, 500);
        sleep(1000); swipe(540, 1800, 540, 300, 500);
        sleep(15000);
        for (; ;) {
            if (text("任务完成").findOnce() || text("已完成浏览任务").findOnce()) {
                sleep(2000);
                break;
            }
        }
        for (; ;) {
            if (text("忍痛离开").findOnce()) {
                text("忍痛离开").findOne().click(); sleep(2000);
            }
            if (text("x").findOnce()) {
                text("x").findOne().click(); sleep(1000);
            }
            if (text("任务数量").findOnce()) {
                break;
            }
            back(); sleep(1000);
        }
    }

    function back_mission() {
        for (; ;) {
            if (text("任务数量").findOnce()) { sleep(1000); break; }
            back();
            sleep(1000);
        }
    }

    Enter_package();
    for (; ;) {
        if (text("领取").findOnce()) {
            text("领取").findOne().click();
            sleep(1500);
        }
        if (text("已完成12/12").findOne(1000)) {
            toastLog("任务已完成");
            toastLog("任务已完成");
            toastLog("任务已完成");
            back_home();
            break;
        }

        if (mission_exit("浏览会场宝贝")) { Browse_goods(); continue; }
        if (mission_exit("去探索")) { back_5(); continue; }
        if (mission_exit("浏览超惠寄")) { back_5(); continue; }
        if (mission_exit("用能量喂养")) { back_5(); continue; }
        if (mission_exit("参与1次")) { Answer_Question(); continue; }


        if (mission_exit("逛一逛裹裹")) { back_15(); continue; }
        if (mission_exit("添加1个包裹")) { add_package(); continue; }
        if (mission_exit("浏览天天")) { back_15(); continue; }
        if (mission_exit("加购3个天天")) { day_Shopping_Cart(); continue; }
        if (mission_exit("完成1次")) { fruit_sign(); continue; }

        toastLog("已完成包裹任务");
        toastLog("已完成包裹任务");
        toastLog("已完成包裹任务");
        back_home();
        break;
    }

}

function red_envelope() {
    function Enter_red_envelope() {
        for (; ;) {
            if (desc("首页").findOnce()) {
                var panrent_view = classNameContains("android.support.v4.view.ViewPager").findOne().child(1).child(0).child(1).child(0);
                var son_view = panrent_view.child(panrent_view.childCount() - 1).child(0).child(0);
                son_view.click();
                text("聚财气").findOne().parent().click();
                text("已攒红包池").findOne();
            } else {
                toast("等待进入首页");
                sleep(3000);
                continue;
            }
            sleep(1000);
            var parent_view = text("已攒红包池").findOne().parent().parent().parent();
            parent_view.child(parent_view.childCount() - 1).click();
            sleep(1000);
            text("关闭").findOne();
            sleep(2000);
            break;
        }
    }

    function mission_exit(text1) {
        if (textContains(text1).findOnce()) {
            click_button = textContains(text1).findOne().parent().parent().child(1);
            if (click_button.text() == "已完成") {
                return 0;
            }
            if (click_button.text() == "去完成") {
                sleep(1000);
                click_button.click();
                return 1;
            }
        }
        return 0;
    }

    function back_5() {
        toastLog("5秒返回");
        sleep(5000); back_mission();
    }

    function back_15() {
        toastLog("滑动浏览，约15秒返回");
        textContains("浏览得").findOne(3000);
        sleep(1000); swipe(540, 1800, 540, 300, 500);
        sleep(1000); swipe(540, 1800, 540, 300, 500);
        sleep(1000); swipe(540, 1800, 540, 300, 500);
        for (; ;) {
            if (textContains("任务完成").findOnce() || textContains("返回重试").findOnce() || descContains("任务完成").findOnce() || descContains("返回重试").findOnce()) { break; }
            sleep(1000);
        }
        sleep(1000); back_mission();
    }

    function tianmao() {
        sleep(4000);
        for (; ;) {
            if (textContains("明日来可领").findOnce()) { sleep(1000); break; }
            back();
            sleep(4000);
        }
        back_15();
    }

    function back_mission() {
        for (; ;) {
            if (text("关闭").findOnce()) { sleep(1000); break; }
            back();
            sleep(1000);
        }
    }


    Enter_red_envelope();
    toastLog("开始浏览任务");
    for (; ;) {
        if (mission_exit("看看下次在哪里")) { back_5(); continue; }
        if (mission_exit("逛\"")) { back_5(); continue; }
        if (mission_exit("逛大牌")) { back_5(); continue; }
        if (mission_exit("每日品牌")) { back_5(); continue; }
        if (mission_exit("天天可抢")) { back_5(); continue; }
        if (mission_exit("活力开练")) { back_5(); continue; }
        if (mission_exit("逛淘宝人生")) { back_5(); continue; }
        if (mission_exit("玩跨栏")) { back_5(); continue; }
        if (mission_exit("看天猫星选")) { back_5(); continue; }

        if (mission_exit("逛聚划算")) { back_15(); continue; }
        if (mission_exit("薅羊毛")) { back_15(); continue; }
        if (mission_exit("来小黑盒")) { back_15(); continue; }
        if (mission_exit("攒油滴")) { back_15(); continue; }
        if (mission_exit("浏览心仪")) { back_15(); continue; }

        if (mission_exit("领天猫")) { tianmao(); continue; }

        toastLog("聚财气红包任务完成");
        toastLog("聚财气红包任务完成");
        toastLog("聚财气红包任务完成");
        back_home();
        break;
    }

}

function bb_farm() {
    function enter_bb_farm() {
        for (; ;) {
            if (desc("首页").findOnce()) {
                desc("芭芭农场").findOne().click();
                sleep(4000);
                for (; ;) {
                    if (text("关闭").findOnce()) {
                        text("关闭").findOne().click();
                        sleep(2000);
                    }
                    if (text("继续努力").findOnce()) {
                        text("继续努力").findOne().click();
                        sleep(2000);
                    }
                    if (text("我").findOnce()) {
                        sleep(1000);
                        break;
                    }
                }
                click(870, 1300); sleep(2000);
                if (textContains("赚更多肥料").findOnce()) {
                    textContains("赚更多肥料").findOne().parent().parent().child(5).click();
                }
                // text("我").findOne().parent().parent().parent().parent().parent().parent().child(0).child(0).child(1).child(3).click();
                // text("好友管理").findOne();
                // if (text("点我领肥料").findOnce()) {
                //         text("点我领肥料").findOne().click();
                //         sleep(2000);
                // }
                text("我").findOne().parent().parent().parent().parent().parent().parent().child(0).child(0).child(1).child(4).click();
                text("关闭").findOne();
                sleep(2000);
                if (text("去签到").findOnce()) {
                    text("去签到").findOne().click();
                }
                break;
            } else {
                toast("等待进入首页");
                sleep(3000);
                continue;
            }
        }
    }

    function mission_exit(text1) {
        if (textContains(text1).findOnce()) {
            click_button = textContains(text1).findOne().parent().parent().child(1);
            if (click_button.text() == "已完成" || click_button.text().indexOf(":") != -1) { return 0; }
            if (click_button.text() == "去浏览" || click_button.text() == "去逛逛" || click_button.text() == "去领取" || click_button.text() == "去完成") { click_button.click(); return 1; }
        }
        return 0;
    }

    function back_mission() {
        for (; ;) {
            if (text("关闭").findOnce()) { sleep(1000); break; }
            back();
            sleep(1000);
        }
    }

    function back_15() {
        toastLog("15秒返回");
        sleep(3000); swipe(540, 1800, 540, 300, 500);
        sleep(1000); swipe(540, 1800, 540, 300, 500);
        sleep(1000); swipe(540, 1800, 540, 300, 500);
        for (; ;) {
            sleep(1000);
            if (textContains("任务已").findOnce() || textContains("浏览完成").findOnce()) {
                sleep(1000);
                break;
            }
        }
        back_mission();
    }

    function back_15() {
        toastLog("15秒返回");
        sleep(3000); swipe(540, 1800, 540, 300, 500);
        sleep(1000); swipe(540, 300, 540, 1800, 500);
        sleep(1000); swipe(540, 1800, 540, 300, 500);
        sleep(1000); swipe(540, 300, 540, 1800, 500);
        for (; ;) {
            sleep(1000);
            if (textContains("任务已").findOnce() || textContains("浏览完成").findOnce() || descContains("任务已").findOnce() || descContains("浏览完成").findOnce()) {
                sleep(1000);
                break;
            }
        }
        back_mission();
    }

    function swipe_15() {
        sleep(3000);
        for (var i = 0; i < 9; i++) {
            sleep(300); swipe(540, 1800, 540, 300, 700);
            sleep(300); swipe(540, 600, 540, 1800, 700);
        }
        back_mission();
    }

    function tao_life() {
        sleep(5000);
        click(540, 2240);
        sleep(3000);
        back_mission();
    }

    function my_to_farm() {
        text("打开链接").findOne().click();
        textContains("合种加速").findOne().parent().parent().parent().parent().parent().child(0).child(0).child(1).child(4).click();
        text("关闭").findOne();
    }

    function invite_friends() {
        descContains("天空嗯").findOne();
        sleep(1000);
        descContains("天空嗯").findOne().parent().click();
        sleep(3000);
        back_mission();
    }

    enter_bb_farm();
    for (; ;) {
        if (mission_exit("领400")) { continue; }
        if (mission_exit("逛精选商品")) { back_15(); continue; }
        if (mission_exit("浏览超惠")) { back_15(); continue; }
        if (mission_exit("浏览金币小镇")) { back_15(); continue; }
        if (mission_exit("观看\"")) { back_15(); continue; }

        if (mission_exit("去淘宝人生")) { tao_life(); continue; }
        if (mission_exit("从我的淘宝")) { my_to_farm(); continue; }
        if (mission_exit("逛精选好物")) { swipe_15(); continue; }
        //if (mission_exit("邀请好友")) { invite_friends(); }

        back_home();
        toastLog("任务已全部完成");
        toastLog("任务已全部完成");
        break;
    }
}

function tianmao_farm() {

    function enter_sunshine() {
        desc("芭芭农场").findOne().click();
        sleep(4000);
        for (; ;) {
            if (text("关闭").findOnce()) {
                text("关闭").findOne().click();
                sleep(2000);
            }
            if (text("继续努力").findOnce()) {
                text("继续努力").findOne().click();
                sleep(2000);
            }
            if (text("我").findOnce()) {
                sleep(1000);
                break;
            }
        }
        click(870, 1300); sleep(2000);
        if (textContains("赚更多肥料").findOnce()) {
            textContains("赚更多肥料").findOne().parent().parent().child(5).click();
        }
        sleep(2000);
        click(950, 860);
        sleep(4000);
        text("兑换专享好券").findOne();
        sleep(1000);
        if (text("立即去收").findOnce()) {
            text("立即去收").classNameContains("android.widget.Button").findOne().click();
            sleep(2000);
        }
    }

    function jude() {
        if (textContains("立即查看").findOnce()) {
            var parent_view = textContains("立即查看").findOne().parent();
            parent_view.child(parent_view.childCount() - 1).click();
            sleep(500);
        }
        if (textContains("TB1flfbqDM11u4jSZPxXXahcXXa-72-72").findOnce()) {
            var parent_view = textContains("TB1flfbqDM11u4jSZPxXXahcXXa").findOne().parent();
            parent_view.child(parent_view.childCount() - 1).click();
            sleep(500);
        }
    }

    enter_sunshine();
    for (var i = 300; i < 900; i = i + 100) {
        for (var j = 700; j < 1650; j = j + 100) {
            if (!text("兑换专享好券").findOnce()) {
                back(); sleep(500);
            }
            click(i, j); jude();
        }
    }
    for (var i = 200; i < 1000; i = i + 100) {
        for (var j = 900; j < 1650; j = j + 100) {
            if (!text("兑换专享好券").findOnce()) {
                back(); sleep(500);
            }
            click(i, j); jude();
        }
    }
    for (var i = 300; i < 900; i = i + 100) {
        for (var j = 700; j < 1650; j = j + 100) {
            if (!text("兑换专享好券").findOnce()) {
                back(); sleep(500);
            }
            click(i, j); jude();
        }
    }
    for (var i = 200; i < 1000; i = i + 100) {
        for (var j = 900; j < 1650; j = j + 100) {
            if (!text("兑换专享好券").findOnce()) {
                back(); sleep(500);
            }
            click(i, j); jude();
        }
    }
    back_home();
}

function taobao_coins() {
    var click_button;

    function enter_coins() {
        for (; ;) {
            if (desc("首页").findOnce()) {
                desc("领淘金币").findOne().click();
                text("赚金币").findOne().click();
                text("今日任务").findOne();
                sleep(2000);
                break;
            } else {
                launchApp("淘宝");
                toast("等待进入首页");
                sleep(3000);
                continue;
            }
        }
    }

    function cs_click(num, rgb, xr, yr, wr, hr, flipup) {
        while (num--) {
            let img = captureScreen()
            if (flipup != undefined) img = images.rotate(img, 180)
            let point = findColor(img, rgb, { region: [img.getWidth() * xr, img.getHeight() * yr, img.getWidth() * wr, img.getHeight() * hr], threshold: 8 })
            if (point) {
                if (flipup != undefined) {
                    point.x = img.getWidth() - point.x; point.y = img.getHeight() - point.y
                }
                return click(point.x, point.y);
            }
            if (num) sleep(1000)
        }
        return false
    }

    function mission_exit(text1) {
        if (textContains(text1).findOnce()) {
            click_button = textContains(text1).findOne().parent().parent().child(1);
            if (click_button.text() == "已完成") {
                sleep(300); return 0;
            }
            if (click_button.text().indexOf(":") != -1) {
                return 0;
            }
            if (click_button.text() == "去完成" || click_button.text() == "去施肥") {
                click_button.click();
                return 1;
            }
            if (click_button.text() == "领取奖励") {
                click_button.click();
                sleep(1500);
            }
        }
        sleep(300); return 0;
    }

    function back_mission() {
        for (; ;) {
            if (text("今日任务").findOnce()) { sleep(1000); break; }
            back();
            sleep(1000);
        }
    }


    function back_5() {
        toastLog("5秒返回");
        sleep(5000); back_mission();
    }

    function back_10() {
        toastLog("10秒返回");
        sleep(3000); swipe(540, 1800, 540, 300, 500);
        sleep(1000); swipe(540, 300, 540, 1800, 500);
        sleep(1000); swipe(540, 1800, 540, 300, 500);
        sleep(1000); swipe(540, 300, 540, 1800, 500);
        for (; ;) {
            sleep(1000);
            if (textContains("任务已").findOnce() || textContains("浏览完成").findOnce() || descContains("任务已").findOnce() || descContains("浏览完成").findOnce()) {
                sleep(1000);
                break;
            }
        }
        back_mission();
    }

    function swipe_10() {
        sleep(2000);
        for (var i = 0; i < 8; i++) {
            sleep(300); swipe(540, 1800, 540, 300, 700);
            sleep(300); swipe(540, 600, 540, 1800, 700);
        }
        back_mission();
    }

    function ant_farm() {
        sleep(3000);
        back_mission();
    }

    function tao_life() {
        sleep(6000);
        cs_click(3, '#fe5200', 0.2, 0.5, 0.3, 0.2);
        cs_click(3, '#fee998', 0.2, 0.2, 0.7, 0.8);
        for (let i = 0; i < 5; i++) {
            cs_click(1, '#ff7d44', 0.1, 0.15, 0.2, 0.5, true); sleep(500)
        }
        sleep(1000);
        cs_click(5, '#fff89d', 0.3, 0.5, 0.3, 0.2); sleep(2000)
        cs_click(2, '#ff7d44', 0.1, 0.15, 0.2, 0.5, true);
        back(); sleep(1000);
        cs_click(3, '#ff7d44', 0.1, 0.15, 0.2, 0.5, true)
        if (text('立刻离开').findOne(1000)) {
            text('立刻离开').findOne().click();
        }
        text("今日任务").findOne(); sleep(1000);
    }

    function tao_achievement() {
        text("成就签到").findOne(); sleep(1000);
        var parent_view = text("成就签到").findOne().parent();
        parent_view.child(parent_view.childCount() - 1).click();
        sleep(1000); back_mission();
    }

    function read_book() {
        text("5").findOne(); sleep(2000);
        text("5").findOne().click();
        textContains("左滑进入").findOne(); sleep(2000);
        textContains("左滑进入").findOne().click();
        sleep(3000);
        for (var i = 0; i < 3; i++) {
            swipe(540, 1800, 540, 300, 500); sleep(1000);
        }
        sleep(7000);
        back_mission();
    }

    enter_coins();
    for (; ;) {
        sleep(1000);
        if (text("领取奖励").findOnce()) {
            text("领取奖励").findOne().click();
            sleep(1500);
        }

        if (mission_exit("每日来访")) { continue; }
        if (mission_exit("蚂蚁")) { ant_farm(); continue; }
        if (mission_exit("支付宝")) { ant_farm(); continue; }
        if (mission_exit("淘宝人生")) { tao_life(); continue; }
        if (mission_exit("淘宝成就签到")) { tao_achievement(); continue; }
        if (mission_exit("看免费小说")) { read_book(); continue; }

        if (mission_exit("逛心愿好货")) { back_5(); continue; }

        if (mission_exit("逛特卖超级")) { back_10(); continue; }
        if (mission_exit("浏览福利中心")) { back_10(); continue; }
        if (mission_exit("好店浏览")) { back_10(); continue; }
        if (mission_exit("逛淘宝吃货")) { back_10(); continue; }
        if (mission_exit("逛好店")) { back_10(); continue; }
        if (mission_exit("逛聚划算")) { back_10(); continue; }
        if (mission_exit("逛逛")) { back_10(); continue; }
        if (mission_exit("浏览黑白")) { back_10(); continue; }
        if (mission_exit("观看\"")) { back_10(); continue; }
        if (mission_exit("进直播间")) { back_10(); continue; }
        if (mission_exit("领话费充值")) { back_10(); continue; }



        if (mission_exit("逛猜你喜欢")) { swipe_10(); continue; }
        if (mission_exit("逛为你精选")) { swipe_10(); continue; }
        if (mission_exit("逛高比例")) { swipe_10(); continue; }
        if (mission_exit("逛淘金币专属")) { swipe_10(); continue; }
        if (mission_exit("浏览精选宝贝")) { swipe_10(); continue; }
        if (mission_exit("逛币囤")) { swipe_10(); continue; }

        toastLog("淘金币任务完成");
        toastLog("淘金币任务完成");
        toastLog("淘金币任务完成");
        back_home();
        break;
    }
}


function enter_tao() {
    launchApp("淘宝");
    for (; ;) {
        if (desc("首页").findOnce()) {
            desc("首页").findOne().click();
            break;
        } else {
            toast("等待进入首页");
            sleep(3000);
            continue;
        }
    }
}

function back_home() {
    for (; ;) {
        sleep(2000);
        if (desc("首页").findOnce()) {
            desc("首页").findOne().click();
            break;
        }
        back();
    }
}


enter_tao();
for (var i = 0; i < mission_options.length; i++) {
    if (mission_options[i] == 0) { package_combat(); }
    if (mission_options[i] == 1) { red_envelope(); }
    if (mission_options[i] == 2) { bb_farm(); }
    if (mission_options[i] == 3) { tianmao_farm(); }
    if (mission_options[i] == 4) { taobao_coins(); }

}

toast("所有任务完成");
toast("所有任务完成");
toast("所有任务完成");
