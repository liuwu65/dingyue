var 名称版本 = "收藏夹-聚划算 4.8";
//兼容天猫收藏夹
auto.waitFor();
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}

var time = new Date(http.get("http://www.baidu.com").headers["Date"]);
var month = time.getMonth() + 1;
var log = "/sdcard/脚本/日志" + month + "." + time.getDate() + ".js";


var 选项关键字符 = dialogs.rawInput("输入选项关键字符\n\n(返回退出脚本)", ""); if (选项关键字符 == null) { toast("已停止！"); exit(); }
//var 抢购模式 = dialogs.select("请选择 抢购模式\n\n(返回退出脚本)", "● 准点模式", "● 捡漏模式"); if (抢购模式 == -1) { toast("已停止！"); exit(); }
var 抢购模式 = 0;
if (抢购模式 == 0) {
    var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if (分 == null) { toast("已停止！"); exit(); }
    var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if (秒 == null) { toast("已停止！"); exit(); }
    var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 4); if (延时 == null) { toast("已停止！"); exit(); }
} else {
    var 分 = 0;
    var 秒 = 0;
    var 延时 = 0;
}
// var options = ["● 判断中间步骤  -  提交", "● 有中间步骤    -    提交", "● 无中间步骤    -    提交", "● 自动选择规格  -  提交", "● 指定规格      -      提交"];
// var 提交方式 = dialogs.select("请选择 提交方式\n\n(若不清楚是否有中间步骤\n请选择 判断中间步骤)\n\n(返回退出脚本)", options); if (提交方式 == -1) { toast("已停止！"); exit(); }
var 提交方式 = 4;
// if (提交方式 == 4) {
//     var 类别数 = dialogs.singleChoice("请选择类别数量\n\n(只有一个选项的类不计算)", ["1", "2", "3", "4", "5"]) + 1; if (类别数 == -1) { toast("已停止！"); exit(); };
//     var 类别选择 = [''];
//     for (var i = 0; i < 类别数; i++) {
//         类别选择[i] = dialogs.singleChoice("第" + (i + 1) + "类选择第几个？", ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25"]); if (类别选择[i] == -1) { toast("已停止！"); exit(); };
//     }
// }
var 价格判断 = 1;
var 理想价格 = "null";
// var 价格判断 = dialogs.select("是否判断价格？\n\n(返回退出脚本)\n", "● 判断价格", "● 不判断价格"); if (价格判断 == -1) { toast("已停止！"); exit(); }
// if (价格判断 == 0) {
//     var 价格1 = null;
//     var 理想价格 = dialogs.input("输入物品理想价格\n\n(返回退出脚本)", 50); if (理想价格 == null) { toast("已停止！"); exit(); }
// }
var time = new Date(http.get("http://www.baidu.com").headers["Date"]);
var 日志字串1 = "\n================================\n" + time.getHours() + ":" + time.getMinutes() + ":" + time.getSeconds() + "\n    /----" + 名称版本 + "----/\n";
var 日志字串2 = "";
if (!抢购模式) { var 日志字串3 = "抢购模式：准点模式\n" } else { var 日志字串3 = "抢购模式：捡漏模式\n" };
if (提交方式 == 0) { var 日志字串4 = "提交方式：判断中间步骤\n" }
if (提交方式 == 1) { var 日志字串4 = "提交方式：有中间步骤\n" }
if (提交方式 == 2) { var 日志字串4 = "提交方式：无中间步骤\n" }
if (提交方式 == 3) { var 日志字串4 = "提交方式：自动选择规格\n" }
if (提交方式 == 4) { var 日志字串4 = "提交方式：指定规格\n关 键 字：" + 选项关键字符 + "\n" }
var 日志字串5 = 日志字串1 + 日志字串2 + 日志字串3 + 日志字串4 + "设定时间：" + 分 + ":" + 秒 + "\n延    时：" + 延时 + "\n" + "理想价格：" + 理想价格 + "\n";
var 显示字串 = "/----" + 名称版本 + "----/\n\n" + 日志字串2 + 日志字串3 + 日志字串4 + "开始时间：" + 分 + ":" + 秒 + "\n延       时：" + 延时 + "\n" + "理想价格：￥ " + 理想价格 + "\n";
files.append(log, 日志字串5);
var 成立控制 = 0; var 次数 = 0;




function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info(显示字串 + "\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(100);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute == 分) {
            if (second <= 秒 - 6) {
                print(minute + ":" + second);
                sleep(800);
                continue;
            } else {
                console.info(minute + ":" + second);
                console.info("还有5秒");
                sleep(2000);
                toast("还有3秒!");
                console.hide();
                sleep(1000);
                break;
            }
        } else {
            sleep(800);
            continue;
        }
    }
    console.hide();
    for (; ;) {
        var second = new Date(http.get("http://www.baidu.com").headers["Date"]).getSeconds();
        if (second >= 秒) {
            sleep(延时);
            return;
        }
    }
}

function 购买点击() {
    textContains("客服").findOne();
    if (idContains("detail_main_sys_button").findOnce()) {
        var 购买按钮 = idContains("detail_main_sys_button").find()[1];
    } else {
        var 购买按钮 = idContains("ll_bottom_bar_content").findOne().child(0).child(0).child(2).find(classNameContains("LinearLayout"))[2];
    }
    if (购买按钮 && 购买按钮.enabled()) {
        购买按钮.click();
        成立控制 = 1;
    } else {
        back();
        return false;
    }
    return true;
}

function 规格页进入判断() {
    textContains("库存").findOne();
}

function 指定规格操作() {
    if (descContains(选项关键字符).findOnce()) {
        var 按钮 = descContains(选项关键字符).findOne();
    } else {
        var 按钮 = textContains(选项关键字符).findOne();
    }
    if (按钮.enabled() && (按钮.desc() == null || 按钮.desc().indexOf("不可选") == -1)) {
        按钮.click();
        成立控制 = 1;
        return true;
    } else {
        back();
        text("客服").findOne();
        back();
        成立控制 = 0;
        return false;
    }
}

function 确定点击() {
    for (; ;) {
        if (id("confirm").findOnce()) {
            id("confirm").findOne().click();
            if (text("提交订单").findOnce()) {
                break;
            } else {
                continue;
            }
        }
        if (text("立即购买").boundsInside(0, 1600, device.width, device.height
        ).findOnce()) {
            var 范围 = text("立即购买").boundsInside(0, 1600, device.width, device.height
            ).findOne().bounds();
            click(范围.centerX(), 范围.centerY());
            if (text("提交订单").findOnce()) {
                break;
            } else {
                continue;
            }
        }
        if (text("确定").boundsInside(0, 1600, device.width, device.height
        ).findOnce()) {
            var 范围 = text("确定").boundsInside(0, 1600, device.width, device.height
            ).findOne().bounds();
            click(范围.centerX(), 范围.centerY());
            if (text("提交订单").findOnce()) {
                break;
            } else {
                continue;
            }
        }
        if (textContains("确认").boundsInside(0, 1600, device.width, device.height
        ).findOnce()) {
            var 范围 = textContains("确认").boundsInside(0, 1600, device.width, device.height
            ).findOne().bounds();
            click(范围.centerX(), 范围.centerY());
            if (text("提交订单").findOnce()) {
                break;
            } else {
                continue;
            }
        }
        if (textContains("马上抢").boundsInside(0, 1600, device.width, device.height
        ).findOnce()) {
            var 范围 = textContains("马上抢").boundsInside(0, 1600, device.width, device.height
            ).findOne().bounds();
            click(范围.centerX(), 范围.centerY());
            if (text("提交订单").findOnce()) {
                break;
            } else {
                continue;
            }
        }
        if (text("领券购买").boundsInside(0, 1600, device.width, device.height
        ).findOnce()) {
            var 范围 = text("领券购买").boundsInside(0, 1600, device.width, device.height
            ).findOne().bounds();
            click(范围.centerX(), 范围.centerY());
            if (text("提交订单").findOnce()) {
                break;
            } else {
                continue;
            }
        }
    }
}

function 返回再进入() {
    for (; ;) {
        console.info("5656566");
        if (textContains("客服").findOnce()) {
            if (idContains("detail_main_sys_button").findOnce()) {
                var 购买按钮 = idContains("detail_main_sys_button").find()[1];
            } else {
                var 购买按钮 = idContains("ll_bottom_bar_content").findOne().child(0).child(0).child(2).find(classNameContains("LinearLayout"))[2];
            }
            购买按钮.click();
            规格页进入判断();
            确定点击();
            break;
        }
        if (textContains("库存").findOnce()) {
            确定点击();
            break;
        }
        back();
    }
}



function 不判断价格抢购() {
    if (!购买点击()) {
        return;
    }
    if (提交方式 == 4) {
        规格页进入判断();
        if (!指定规格操作()) {
            return;
        }
        确定点击();
        for (; ;) {
            // for (; ;) {
            //     text("提交订单").findOne();
            //     //if (true) {
            //     // if (textContains("购买数量超过").findOnce() || textContains("商品不能购买").findOnce() || textContains("已无库存").findOnce()) {
            //     //     sleep(1100);
            //     //     back();
            //     //     返回再进入();
            //     //     continue;
            //     // } else {
            //     //     break;
            //     // }
            // }

            text("仅限中国大陆手机号").findOne().setText("18583681780");
            text("选填,请先和商家协商一致").findOne().setText("熊静");



            //text("提交订单").findOne().click();
            console.info("66666");
            break;
            // if (textContains("我知道了").findOne(500)) {
            //     textContains("我知道了").findOne().click();
            //     返回再进入();
            //     continue;
            // } else {
            //     break;
            // }
        }


        toast("抢购完成！！！");
    }
}

function 不判断价格() {
    toast("抢购开始。。。");
    if (抢购模式 == 0) {
        倒计时();
    }
    for (; ;) {
        click(350, 650);
        sleep(20);
        click(350, 650);
        次数++;
        不判断价格抢购();
        if (成立控制 == 1) {
            break;
        }
        for (; ;) {
            if (desc("管理").findOnce() || text("个护").findOnce() || text("全部类目").findOnce()) {
                break;
            }
        }
    }
    files.append(log, "\n    进入次数统计：" + 次数 + "\n================================\n");
    if (成立控制 == 1) {
        toast("抢购结束！！！");
    }
}


if (价格判断 == 1) {
    不判断价格();
}
