//批量评价 1.0
//去掉公开按钮
auto.waitFor();
app.startActivity({
    packageName: "com.taobao.taobao",
    className: "com.taobao.tao.TBMainActivity"
});
waitForActivity("com.taobao.tao.TBMainActivity");
var pl = ["还不错，好东西","可以可以","挺好的","很不错的东西"];
toast("评价开始");sleep(1000);
for(;;){
    desc("我的淘宝").findOne().click();
    descContains("评价").findOne().click();
    if(!desc("评价").findOne(3000))
    break;
    desc("评价").findOne().parent().click();
    className("EditText").findOne().setText(pl[random(0, pl.length-1)]);
    swipe(540, 1800, 540, 50, 400);sleep(300);
    for(;;){
        if(desc("5星").findOne(500))
        desc("5星").findOne().click();
        else
        break;
    }
    if(text("公开").findOne(500))
    text("公开").findOne().click();
    text("发布").findOne().click();
    desc("返回首页").findOne().parent().click();
}
toast("评价完成");