
// var start = confirm("说明：\n1.软件需要先打开无障碍权限，基本的读写权限，悬浮框权限再运行\n\n2.按音量上键停止运行\n\n3.本软件不收集任何信息，不放心可以看源码\n\n4.打开权限后，点击确定开始任务");
// if (!start) {
//     exit();
// }
auto.waitFor();
toast("开始运行");

function 进入() {
    app.startActivity({
        packageName: "com.taobao.taobao",
        className: "com.taobao.search.searchdoor.SearchDoorActivity"
    });
    waitForActivity("com.taobao.search.searchdoor.SearchDoorActivity");
    sleep(1000);
    setText("超级星猫秀");
    sleep(1000);
    text("搜索").findOne().click();
    sleep(3000);
    for (; ;) {
        if (idContains("_CLOSE").findOnce()) {
            var bound = idContains("_CLOSE").findOne().bounds();
            sleep(300);
            click(bound.centerX(), bound.centerY());
        }
        if (text("活动链接").findOnce()) {
            text("活动链接").findOne().click();
        }
        if (text("赚喵币").findOnce()) {
            if (textContains("喵币点击领取").findOnce()) {
                textContains("喵币点击领取").findOne().click();
            }
            sleep(2000);
            text("赚喵币").findOne().click();
            break;
        }
        sleep(1000);
    }
    text("关闭").findOne();
    sleep(1000);
    if (textContains("每日签到").findOnce()) {
        textContains("每日签到").findOne().parent().parent().child(1).click();
        sleep(1500);
    }
    log("进入成功");
}

function 去浏览() {
    var 找空次数 = 0;
    for (; ;) {
        if (text("去浏览").findOnce()) {
            log(text("去浏览").findOne().parent().child(0).child(0).text());
            text("去浏览").findOne().click();
            找空次数 = 0;
            for (var i = 0; i < 10; i++) {
                if (!text("关闭").findOnce()) {
                    break;
                }
                sleep(1000);
            }
            sleep(2000);
            for (var i = 0; i < 11; i++) {
                if (text("今日已达上限").findOnce()) {
                    break;
                }
                if (textContains("跟主播聊什么").findOnce()) {
                    sleep(1000);
                } else {
                    swipe(540, 1000, 540, 800, 300);
                    sleep(1000);
                }
                if (text("全部完成啦").findOnce() || text("任务完成").findOnce() || text("任务已完成").findOnce() || descContains("任务已完成").findOnce() || descContains("任务完成").findOnce() || descContains("全部完成啦").findOnce()|| textContains("重试").findOnce()) {
                    break;
                }
            }
            back();
            for (; ;) {
                if (text("签到").findOnce() || text("已完成").findOnce() || text("关闭").findOnce()) {
                    sleep(3000);
                    break;
                }
                sleep(1000);
            }
        } else {
            找空次数++;
            sleep(1000);
        }
        if (找空次数 == 5) {
            break;
        }
    }
    sleep(1000);
}

function 去逛逛() {
    if (text("去逛逛").findOnce()) {
        log(text("去逛逛").findOne().parent().child(0).child(0).text());
        text("去逛逛").findOne().click();
        for (; ;) {
            if (text("全部完成啦").findOnce() || text("任务完成").findOnce() || text("任务已完成").findOnce() || descContains("任务已完成").findOnce() || descContains("任务完成").findOnce() || descContains("全部完成啦").findOnce()|| textContains("重试").findOnce()) {
                break;
            }
        }
        back();
        for (; ;) {
            if (text("签到").findOnce() || text("已完成").findOnce() || text("关闭").findOnce()) {
                break;
            }
            sleep(2000);
        }
    }
}

function 逛一逛() {
    if (textContains("逛一逛").findOnce()) {
        log(textContains("逛一逛").findOne().text());
        textContains("逛一逛").findOne().parent().parent().child(1).click();
        for (var i = 0; i < 10; i++) {
            if (!text("关闭").findOnce()) {
                break;
            }
            sleep(1000);
            if (i > 5) {
                return;
            }
        }
        for (; ;) {
            if (text("全部完成啦").findOnce() || text("任务完成").findOnce() || text("任务已完成").findOnce() || descContains("任务已完成").findOnce() || descContains("任务完成").findOnce() || descContains("全部完成啦").findOnce()|| textContains("重试").findOnce()) {
                break;
            }

        }
        back();
        for (; ;) {
            if (text("签到").findOnce() || text("已完成").findOnce() || text("关闭").findOnce()) {
                sleep(2000);
                break;
            }
            sleep(1000);
        }
    }
}

function 直播盛典() {
    if (textContains("直播盛典").findOnce()) {
        log(textContains("直播盛典").findOne().text());
        textContains("直播盛典").findOne().parent().parent().child(1).click();
        for (var i = 0; i < 10; i++) {
            if (!text("关闭").findOnce()) {
                break;
            }
            sleep(1000);
            if (i > 5) {
                return;
            }
        }
        for (; ;) {
            if (text("全部完成啦").findOnce() || text("任务完成").findOnce() || text("任务已完成").findOnce() || descContains("任务已完成").findOnce() || descContains("任务完成").findOnce() || descContains("全部完成啦").findOnce()|| textContains("重试").findOnce()) {
                break;
            }

        }
        back();
        for (; ;) {
            if (text("签到").findOnce() || text("已完成").findOnce() || text("关闭").findOnce()) {
                sleep(2000);
                break;
            }
            sleep(1000);
        }
    }
}

function 搜一搜() {
    if (textContains("搜一搜").findOnce()) {
        log(textContains("搜一搜").findOne().text());
        textContains("搜一搜").findOne().parent().parent().child(1).click();
        for (var i = 0; i < 10; i++) {
            if (!text("关闭").findOnce()) {
                break;
            }
            sleep(1000);
            if (i > 5) {
                return;
            }
        }
        for (; ;) {
            if (text("全部完成啦").findOnce() || text("任务完成").findOnce() || text("任务已完成").findOnce() || descContains("任务已完成").findOnce() || descContains("任务完成").findOnce() || descContains("全部完成啦").findOnce()|| textContains("重试").findOnce()) {
                break;
            }

        }
        back();
        for (; ;) {
            if (text("签到").findOnce() || text("已完成").findOnce() || text("关闭").findOnce()) {
                sleep(2000);
                break;
            }
            sleep(1000);
        }
    }
}

function 领取奖励() {
    for (; ;) {
        if (text("领取奖励").findOnce()) {
            text("领取奖励").findOne().click();
            sleep(1500);
        } else {
            break;
        }
    }
}

function 撸猫() {
    text("关闭").findOne().click();
    text("赚喵币").findOne();
    var 我的喵币 = textContains("我的喵币").findOne().text().replace('我的喵币,', '');
    for (var i = 0; i < 100; i++) {
        textContains("点击撸猫").findOne().click();
        if (textContains("我的喵币").findOne().text().replace('我的喵币,', '') != 我的喵币) {
            i = 0;
        } else {
            i++;
        }
        var 我的喵币 = textContains("我的喵币").findOne().text().replace('我的喵币,', '');
        sleep(150);
    }
}


var 找空数 = 0;
进入();
for (; ;) {
    console.show();
    sleep(100);
    console.setPosition(device.width / 2 - 100, 50);
    console.setSize(device.width / 2, 600);
    if (text("去浏览").findOnce()) {
        log("开始去浏览");
        去浏览();
        log("去浏览结束");
        找空数 = 0;
    }

    if (text("去逛逛").findOnce()) {
        log("开始去逛逛");
        去逛逛();
        log("去逛逛结束");
        找空数 = 0;
    }

    if (textContains("逛一逛").findOnce()) {
        if (textContains("逛一逛").findOne().parent().parent().child(1).text() != "已完成") {
            log("开始逛一逛");
            逛一逛();
            log("逛一逛结束");
            找空数 = 0;
        }
    }
    if (textContains("搜一搜").findOnce()) {
        if (textContains("搜一搜").findOne().parent().parent().child(1).text() != "已完成") {
            log("开始搜一搜");
            搜一搜();
            log("搜一搜结束");
            找空数 = 0;
        }
    }

    if (textContains("直播盛典").findOnce()) {
        if (textContains("直播盛典").findOne().parent().parent().child(1).text() != "已完成") {
            log("开始逛直播盛典");
            直播盛典();
            log("逛直播盛典结束");
            找空数 = 0;
        }
    }

    if (text("领取奖励").findOnce()) {
        log("领取奖励");
        领取奖励();
        log("已领取奖励");
        找空数 = 0;
    }

    sleep(1000);
    找空数++;
    log("找空次数：" + 找空数);
    if (找空数 == 5) {
        log("开始撸猫");
        撸猫();
        console.info("任务已完成");
        break;
    }
}

