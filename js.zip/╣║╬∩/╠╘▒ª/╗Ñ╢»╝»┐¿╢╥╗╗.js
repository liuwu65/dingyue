auto.waitFor();

// var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if(分==null){toast("已停止！");exit();}
// var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if(秒==null){toast("已停止！");exit();}
// var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if(延时==null){toast("已停止！");exit();}


var 类别数 =1;// dialogs.singleChoice("请选择类别数量\n\n(只有一个选项的类不计算)",["1","2","3","4","5"])+1; if(类别数==-1){toast("已停止！");exit();};
var 类别选择=[''];
for(var i=0;i<类别数;i++){
    类别选择[i] = dialogs.singleChoice("第"+(i+1)+"类选择第几个？",["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25"]); if(类别选择[i]==-1){toast("已停止！");exit();};
}


// function 倒计时(){
//     console.show();
//     sleep(100);
//     console.setPosition(400,400);
//     console.setSize(730,900);
//     console.info("脚本已运行！\n"+"最后一分钟开始计时！");
//     sleep(1000);

//     for(;;){                //获取时间、判断开始
//         var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]); //把Date转换成时间对象
//         //var hour = internetdDate .getHours();
//         var minute = internetdDate .getMinutes();
//         var second = internetdDate .getSeconds();
//         //print(minute+":"+second);
//         if(minute>=分&&second>=秒){   //！！时间控制！！！！
//             sleep(延时);//延迟时间
//             break;
//         }
//         if(minute==分&&second<=秒-10){
//             print(minute+":"+second);
//             sleep(800);
//         }
//         if(minute==分&&second==秒-9){
//             print(minute+":"+second);
//             console.info("还有9秒");
//             toast("还有9秒!\n请等待！");
//             sleep(2000);
//             toast("还有7秒!\n请等待！");
//             console.hide();
//             toast("还有5秒!\n马上开始！");
//             toast("还有3秒!\n马上开始！");
//         }
//     }
//     return;
// }

// 倒计时();
// //兑换部分
// for (var i=0;i<60 ;i++) {
//     text("爱互动").findOne();
//     idContains("spendListsTask").findOne().child(0).click();
//     var 按钮 = className("android.widget.Button").findOne();
//     if (按钮.clickable()) {
//         按钮.click();
//         break;
//     } else {
//         back();
//     }
// }

// //购买部分
// text("确认").findOne().click();
text("查看商品详情").findOne().click();
var i=0;
textContains("客服").findOne();
var 购买按钮=idContains("detail_main_sys_button").find()[1];
购买按钮.click();
textContains("购买数量").findOne();

descContains("ml").find().every(function (选项) {
    if (选项.desc().indexOf("7") != -1) {
        if (选项.desc().indexOf("不可选择") != -1) {
            descContains("ml").find().every(function (选项) {
                if (选项.desc().indexOf("不可选择") != -1) {
                    return true;
                } else {
                    选项.click();
                    return false;
                }
            });
            return true;
        } else {
            选项.click();
            return false;
        }
    }
    return true;
});


idContains("confirm").findOne().click();
textStartsWith("提交订单").findOne().click();
toast("抢购完成！！！");




