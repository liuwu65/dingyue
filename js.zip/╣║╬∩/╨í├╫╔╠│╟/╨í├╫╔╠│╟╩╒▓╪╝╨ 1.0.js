var 名称版本 = "小米商城收藏夹 1.0";
//
auto.waitFor();
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}

//设定
{
    var time = new Date(http.get("http://www.baidu.com").headers["Date"]);
    var month = time.getMonth() + 1;
    var log = "/sdcard/脚本/日志" + month + "." + time.getDate() + ".js";
    var 成立控制 = 0; var 次数 = 0;

    var 关键字 = rawInput("请输入商品关键字", "十年献礼"); if (关键字 == null) { toast("已停止！"); exit(); }
    var 抢购模式 = 0;
    if (抢购模式 == 0) {
        var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if (分 == null) { toast("已停止！"); exit(); }
        var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if (秒 == null) { toast("已停止！"); exit(); }
        var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 4); if (延时 == null) { toast("已停止！"); exit(); }
    } else {
        var 分 = 0;
        var 秒 = 0;
        var 延时 = 0;
    }
}
//显示
{
    var time = new Date(http.get("http://www.baidu.com").headers["Date"]);
    var 日志字串1 = "\n================================\n" + time.getHours() + ":" + time.getMinutes() + ":" + time.getSeconds() + "\n    /----" + 名称版本 + "----/\n";
    var 日志字串2 = "关 键 字：" + 关键字 + "\n";
    var 日志字串3 = "";
    var 日志字串4 = "";
    var 日志字串5 = 日志字串1 + 日志字串2 + 日志字串3 + 日志字串4 + "设定时间：" + 分 + ":" + 秒 + "\n延     时：" + 延时 + "\n";
    var 显示字串 = "/----" + 名称版本 + "----/\n\n" + 日志字串2 + 日志字串3 + 日志字串4 + "开始时间：" + 分 + ":" + 秒 + "\n延       时：" + 延时 + "\n";
    files.append(log, 日志字串5);

}


function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info(显示字串 + "\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(100);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute == 分) {
            if (second <= 秒 - 6) {
                print(minute + ":" + second);
                sleep(800);
                continue;
            } else {
                console.info(minute + ":" + second);
                console.info("还有5秒");
                sleep(2000);
                toast("还有3秒!");
                console.hide();
                sleep(1000);
                break;
            }
        } else {
            sleep(800);
            continue;
        }
    }
    console.hide();
    for (; ;) {
        var second = new Date(http.get("http://www.baidu.com").headers["Date"]).getSeconds();
        if (second >= 秒) {
            sleep(延时);
            return;
        }
    }
}

function 购买点击() {
    console.info("1");
    for (; ;) {
        if (text("加入购物车").findOnce()) {
            click(777, 2220);
            sleep(10);
            click(777, 2220);
            console.info("2");
            text("极夜黑").findOne().parent().click();
            text("8GB+512GB").findOne().parent().click();
            for (; ;) {
                if (text("加入购物车").findOnce()) {
                    text("加入购物车").findOne().click();
                    break;
                }
                if (text("确定").findOnce()) {
                    text("确定").findOne().click();
                    break;
                }
                if (textContains("距开售").findOnce() || text("暂时缺货").findOnce()) {
                    console.info("3");
                    back();
                    text("客服").findOne();
                    return false;
                }
            }
            return true;
        }
        if (textContains("距开售").findOnce() || text("暂时缺货").findOnce()) {
            console.info("4");
            return false;
        }
    }
}


toast("抢购开始。。。");
倒计时();
for (; ;) {
    var 关键字1 = textContains(关键字).findOnce();
    if (关键字1) {
        var bounds = 关键字1.bounds();
    } else {
        var bounds = descContains(关键字).findOne().bounds();
    }
    click(bounds.centerX(), bounds.centerY());
    次数++;
    if (购买点击()) {
        console.info("6666");
        break;

    } else {
        console.info("0000");
        back();
        text("收藏夹").findOne();
        continue;
    }
}
files.append(log, "\n小米商城进入次数统计：" + 次数 + "\n================================\n");
//text("去付款").findOne().click();



