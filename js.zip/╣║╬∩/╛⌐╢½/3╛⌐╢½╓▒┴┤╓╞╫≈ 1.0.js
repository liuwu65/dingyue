auto.waitFor();

停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}
text("店铺").findOne();
descStartsWith("分享").findOne().click();
text("复制链接").findOne().parent().click();
launchApp("Auto.js");
text("Auto.js").findOne();
sleep(2000);
for (; ;) {
    var url1 = getClip().substr(getClip().indexOf("https://"), 50);
    if (url1.indexOf("https://")!=-1) {
        break;
    }
}
log(url1);
var id=url1.match(/product.*?(?=.html)/gi)[0].replace('product/','');
var url2="https://p.m.jd.com/norder/order.action?wareId="+id+"&wareNum=1&enterOrder=true";
log(url2);
launchApp("京东");
idContains("app1").findOne().click();
sleep(1000);
desc("分享").findOne().parent().child(1).click();
text("消息").findOne().parent().click();
var bound = text("京东客服").findOne().bounds();
click(bound.centerX(), bound.centerY());
idContains("inputBox").findOne().setText(url2);
sleep(500);
text("发送").findOne().click();


toast("链接已发送！");
toast("链接已发送！");
