var 名称版本 = "京东直链抢购 1.0";
//
auto.waitFor();
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}

//设定
{
    var time = new Date(http.get("http://www.baidu.com").headers["Date"]);
    var month = time.getMonth() + 1;
    var log = "/sdcard/脚本/日志" + month + "." + time.getDate() + ".js";

    var 抢购模式 = dialogs.select("请选择 抢购模式\n\n(返回退出脚本)", "● 准点模式", "● 捡漏模式"); if (抢购模式 == -1) { toast("已停止！"); exit(); }
    if (抢购模式 == 0) {
        var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if (分 == null) { toast("已停止！"); exit(); }
        var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if (秒 == null) { toast("已停止！"); exit(); }
        var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 4); if (延时 == null) { toast("已停止！"); exit(); }
    } else {
        var 分 = 0;
        var 秒 = 0;
        var 延时 = 0;
    }
    var 价格判断 = dialogs.select("是否判断价格？\n\n(返回退出脚本)\n", "● 判断价格", "● 不判断价格"); if (价格判断 == -1) { toast("已停止！"); exit(); }
    if (价格判断 == 0) {
        var 价格1 = null;
        var 理想价格 = dialogs.input("输入物品理想价格\n\n(返回退出脚本)", 50); if (理想价格 == null) { toast("已停止！"); exit(); }
    }
    var 是否确定 = 0;
}
//显示
{
    var time = new Date(http.get("http://www.baidu.com").headers["Date"]);
    var 日志字串1 = "\n================================\n" + time.getHours() + ":" + time.getMinutes() + ":" + time.getSeconds() + "\n    /----" + 名称版本 + "----/\n";

    if (!抢购模式) { var 日志字串3 = "抢购模式：准点模式\n" } else { var 日志字串3 = "抢购模式：捡漏模式\n" };
    var 日志字串4 = "";
    var 日志字串5 = 日志字串1 + 日志字串3 + 日志字串4 + "设定时间：" + 分 + ":" + 秒 + "\n延   时：" + 延时 + "\n" + "理想价格：" + 理想价格 + "\n";
    var 显示字串 = "/----" + 名称版本 + "----/\n\n" + 日志字串3 + 日志字串4 + "开始时间：" + 分 + ":" + 秒 + "\n延       时：" + 延时 + "\n" + "理想价格：￥ " + 理想价格 + "\n";
    files.append(log, 日志字串5);
}



function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info(显示字串 + "\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(100);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute == 分) {
            if (second <= 秒 - 6) {
                print(minute + ":" + second);
                sleep(800);
                continue;
            } else {
                console.info(minute + ":" + second);
                console.info("还有5秒");
                sleep(2000);
                toast("还有3秒!");
                console.hide();
                sleep(1000);
                break;
            }
        } else {
            sleep(800);
            continue;
        }
    }
    console.hide();
    for (; ;) {
        var second = new Date(http.get("http://www.baidu.com").headers["Date"]).getSeconds();
        if (second >= 秒) {
            sleep(延时);
            return;
        }
    }
}

function 进入() {
    textContains("专属客服").findOne();
    var url_view = textContains("https://p.m.jd.com/norder/order.action").find();
    var bound = url_view[url_view.length - 1].bounds();
    click(bound.centerX(), bound.centerY());
    for (; ;) {
        if (textContains("总计：").findOnce()) {
            break;
        }
        if (text("重试").findOnce()) {
            text("重试").findOne().click();
        }
    }
}

function 判断价格() {
    var 价格 = textContains("总计：").findOne().parent().child(2).text().replace('¥', '');
    toast(价格);
    if (价格 < 理想价格) {
        return true;
    } else {
        back();
        textContains("专属客服").findOne();
        return false;
    }
}

function 成功判断() {
    for (; ;) {
        if (textContains("京东收银台").findOne(2000)) {
            toast("购买成功！！！");
            return true;
        }
        if (textContains("返回购物车").findOnce()) {
            return false;
        }
    }
}



function 抢购() {
    倒计时();
    for (var i = 0; ; i++) {
        if (i > 4) {
            toast("抢购失败！");
            files.append(log, "\n进入次数统计：" + i + "\n================================\n");
            exit();
        }
        进入();
        if (价格判断 == 0) {
            if (!判断价格()) {
                continue;
            }
        }
        textContains("在线支付").findOne().click();
        files.append(log, "\n进入次数统计：" + i + "\n================================\n");
        // if (!成功判断()) {
        //     continue;
        // }
    }
}

function 捡漏() {
    for (var i = 0; ; i++) {
        进入();
        if (价格判断 == 0) {
            if (!判断价格()) {
                continue;
            }
        }
        textContains("在线支付").findOne().click();
        files.append(log, "\n进入次数统计：" + i + "\n================================\n");
        // if (!成功判断()) {
        //     continue;
        // }
    }
}



if (抢购模式 == 0) {
    抢购();
}
if (抢购模式 == 1) {
    捡漏();
}




