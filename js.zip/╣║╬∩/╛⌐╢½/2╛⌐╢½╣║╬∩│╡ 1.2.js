var 脚本名称 = "京东购物车 1.2.js";
//修复
auto.waitFor();
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}

var time = new Date(http.get("http://www.baidu.com").headers["Date"]);
var month = time.getMonth() + 1;
var log = "/sdcard/脚本/日志" + month + "." + time.getDate() + ".js";



var 成立控制 = 0;var 进入次数=0;

var 模式 = dialogs.select("选择模式\n\n(返回退出脚本)\n", "● 定时抢购", "● 捡漏"); if (价格判断 == -1) { toast("已停止！"); exit(); }

if (模式 == 0) {
    var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if (分 == null) { toast("已停止！"); exit(); }
    var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if (秒 == null) { toast("已停止！"); exit(); }
    var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if (延时 == null) { toast("已停止！"); exit(); }
}else{
    var 分 = 0;
    var 秒 = 0;
    var 延时 = 0;
}
var 价格判断 = dialogs.select("是否判断价格？\n\n(返回退出脚本)\n", "● 判断价格", "● 不判断价格"); if (价格判断 == -1) { toast("已停止！"); exit(); }
if (价格判断 == 0) {
    var 理想价格 = dialogs.input("输入物品理想价格\n\n(返回退出脚本)", 50); if (理想价格 == null) { toast("已停止！"); exit(); }
}
var 提交延时 = dialogs.input("输入提交延时\n\n(返回退出脚本)", 100); if (提交延时 == null) { toast("已停止！"); exit(); }


var 日志字串1 = "\n/===== " + 脚本名称 + " =====/\n" + time.getMinutes() + ":" + time.getSeconds() + "\n";
if (模式 == 0) { var 日志字串2 = "运行模式：定时抢购\n" }
if (模式 == 1) { var 日志字串2 = "运行模式：捡漏\n" }
var 日志字串3 = "开始时间： " + 分 + ":" + 秒 + "\n延       时：" + 延时 + "\n提交延时：" + 提交延时 + "\n";
if (价格判断 == 0) { var 日志字串4 = "理想价格：" + 理想价格 + " ¥\n\n" }
if (价格判断 == 1) { var 日志字串4 = "不判断价格！\n\n" }

var 日志字串5 = 日志字串1 + 日志字串2 + 日志字串3 + 日志字串4;
var 显示字串 = "      /===== " + 脚本名称 + " =====/\n\n" + 日志字串2 + 日志字串3 + 日志字串4;
files.append(log, 日志字串5);




function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info(显示字串 + "\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(100);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute == 分) {
            if (second <= 秒 - 6) {
                print(minute + ":" + second);
                sleep(800);
                continue;
            } else {
                console.info(minute + ":" + second);
                console.info("还有5秒");
                sleep(2000);
                toast("还有3秒!");
                console.hide();
                sleep(1000);
                break;
            }
        } else {
            sleep(800);
            continue;
        }
    }
    console.hide();
    for (; ;) {
        var second = new Date(http.get("http://www.baidu.com").headers["Date"]).getSeconds();
        if (second >= 秒) {
            sleep(延时);
            return;
        }
    }
}



function 勾选第一个() {
    classNameContains("android.support.v7.widget.RecyclerView").findOne().children().every(function (选项) {
        if (选项.className().indexOf("RelativeLayout") != -1) {
            选项.child(0).child(0).click();
            return false;
        }
        return true;
    });
}



if (模式 == 0) {
    倒计时();
}

for (; ;) {
    textContains("去结算(").findOne().click();
    进入次数++;
    files.append(log, "进入 "+进入次数+" 次\n");
    for (; ;) {
        if (textContains("提交订单").findOnce()) {
            成立控制 = 0;
            sleep(提交延时);
            break;
        }
        if(textContains("确定").findOnce()){
            textContains("确定").findOne().click();
            continue;
        }
        if (textContains("返回购物车").findOnce()) {
            sleep(提交延时);
            textContains("返回购物车").findOne().click();
            成立控制 = 1;
            break;
        }
    }
    if (成立控制 == 1) {
        continue;
    }

    if (价格判断 == 0) {
        var 价格 = textContains("提交订单").findOne().parent().parent().findOne(textContains("¥")).text().replace('¥', '');
        files.append(log, "此次价格："+价格+" ¥\n");
        if (价格 < 理想价格) {
            textContains("提交订单").findOne().click();
        } else {
            back();
            continue;
        }
    }
    if (textContains("返回购物车").findOne(500)) {
        sleep(提交延时);
        textContains("返回购物车").findOne().click();
        成立控制 = 1;
        continue;
    }
    if (价格判断 == 1) {
        textContains("提交订单").findOne().click();
    }

    for (; ;) {
        if (textContains("京东收银台").findOne(1000)) {
            toast("购买成功！！！");
            成立控制 = 0;
            break;
        }
        if (textContains("确定").findOnce()) {
            textContains("确定").findOne().click();
            sleep(300);
            back();
            成立控制 = 0;
            break;
        }
        if (textContains("返回购物车").findOne(500)) {
            sleep(提交延时);
            textContains("返回购物车").findOne().click();
            //勾选第一个();
            成立控制 = 1;
            break;
        }
    }
    if (成立控制 == 1) {
        continue;
    } else {
        break;
    }
}
