auto.waitFor();




var 模式 = dialogs.select("请选择 模式\n\n(返回退出脚本)", "● 领取试用", "● 试用报告", "● 收货", "● 评价"); if (模式 == -1) { toast("已停止！"); exit(); }


function 领取试用() {
    for (; ;) {
        var bound = text("领取商品").boundsInside(0, 200, 1080, 2100).findOne().bounds();
        click(bound.centerX(), bound.centerY());
        text("工作日、双休日及节假日均可送货").findOne();
        sleep(1000);
        text("提交订单").findOne().click();
        text("支付方式：在线支付").findOne();
        sleep(500);
        back();
        text("我的试用").findOne();
        sleep(1000);
    }
}

function 试用报告() {
    for (; ;) {
        text("商品亮点及建议").findOne();
        var bound = text("性别").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        sleep(500);
        var bound = text("男").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        sleep(500);
        var bound = text("年龄").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        sleep(500);
        var bound = text("21-25岁").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        sleep(500);
        var bound = text("身份").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        sleep(500);
        var bound = text("职员/工人").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        sleep(500);
        // setText(0, "名流这款002致薄避孕套，质量非常好，值得推荐");
        // setText(1, "名流这款002致薄避孕套，质量非常好，值得推荐，东西包装很好，两层包装，而且店家的隐私性做的很好，打开套套盒子看起来就很有质感，昨天晚上使用了一次，油量很大，用着也不干感觉也很薄");
        setText(0, "酒精消毒湿巾，很实用，值得推荐");
        setText(1, "首先商家包装真的很用心，是单片装。清洁湿巾很实用，用来擦手机、电视、电脑屏、键盘、鼠标都可以既能起到清洁的作用又能消毒。");
        sleep(1000);
        swipe(540, 1800, 540, 300, 500);
        sleep(500);
        var bound = text("点击添加或更改图1").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        textContains("最近添加").findOne(); sleep(500);
        idContains("lib_ec_photo_album_recyclerView").findOne().child(3).click();
        sleep(4000);
        var bound = text("点击添加或更改图2").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        textContains("最近添加").findOne(); sleep(500);
        idContains("lib_ec_photo_album_recyclerView").findOne().child(2).click();
        sleep(4000);
        var bound = text("点击添加或更改图3").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        textContains("最近添加").findOne(); sleep(500);
        idContains("lib_ec_photo_album_recyclerView").findOne().child(1).click();
        sleep(4000);
        // setText(2, "名流这款002致薄避孕套，质量非常好，值得推荐，正品防伪，使用放心，大家可以放心购买，东西包装很好，两层包装，而且店家的隐私性做的很好，打开套套盒子看起来就很有质感，昨天晚上使用了一次，油量很大，用着也不干感觉也很薄，很舒服");
        // setText(3, "名流这款002致薄避孕套，质量非常好，值得推荐，东西包装很好，两层包装，而且店家的隐私性做的很好，打开套套盒子看起来就很有质感，昨天晚上使用了一次，油量很大，用着也不干感觉也很薄，撕开包装袋，感觉油量还挺大的，能很好地起到润滑作用。确实非常薄，实际用的时候几乎感受不到它的存在。建议可以体验一下。");
        // setText(4, "很幸运能收到这次的试用品。名流是一直在用的品牌，这种致薄002还是头一次接触。外包装盒设计很大方简洁，看着很舒服。名流这款002致薄避孕套，质量非常好，值得推荐，东西包装很好，两层包装，而且店家的隐私性做的很好，打开套套盒子看起来就很有质感，昨天晚上使用了一次，油量很大，用着也不干感觉也很薄");
        setText(2, "清洁湿巾很实用，用来擦手机、电视、电脑屏、键盘、鼠标都可以既能起到清洁的作用又能消毒。方便携带，每片大概有一张面巾纸那么大的尺寸，优点：及擦及干擦过后无水渍、无痕迹，对手机屏上的指纹汗渍等异物有很好的清洁消毒作用");
        setText(3, "打开有一点酒精味，不重，有一种清新的味道， 清洁湿巾很实用，用来擦手机、电视、电脑屏、键盘、鼠标都可以既能起到清洁的作用又能消毒。方便携带，每片大概有一张面巾纸那么大的尺寸，尺寸很大擦手机绰绰有余，擦过手机还能擦别的东西这样能做到最大的使用程度。");
        setText(4, "物流速度很快，湿巾效果不错， 清洁湿巾很实用，用来擦手机、电视、电脑屏、键盘、鼠标都可以既能起到清洁的作用又能消毒。方便携带，每片大概有一张面巾纸那么大的尺寸，尺寸很大擦手机绰绰有余，擦过手机还能擦别的东西这样能做到最大的使用程度。优点：及擦及干擦过后无水渍、无痕迹，对手机屏上的指纹汗渍等异物有很好的清洁消毒作用。");
        sleep(500);
        click(540, 2100);
        sleep(1000);
    }
}

function 收货() {
    for (; ;) {
        textContains("[南充市]").findOne().parent().parent().parent().child(3).child(1).child(3).click();
        text("已收货").findOne().click();
        text("确认收货成功").findOne();
        back();
    }
}

function 评价() {
    for (; ;) {
        text("评价").findOne().click();
        text("提交").findOne();
        var rand_number = " ";
        for (var i = 0; i < 5; i++) {
            rand_number = rand_number + Math.floor(Math.random() * 10);
        }
        setText("物流速度很快，东西质量也不错哦" + rand_number + " 非常满意的一次购物");
        sleep(300);
        for (var i = 1400; i < 2000; i = i + 50) {
            click(750, i);
        }
        sleep(300);
        text("提交").findOne().click();
    }
}

if (模式 == 0) { 领取试用(); }
if (模式 == 1) { 试用报告(); }
if (模式 == 2) { 收货(); }
if (模式 == 3) { 评价(); }