//京东签到 1.1
//
auto.waitFor();

var 账号 = [
    "18873292759",
    "13158507242",
    "18873208031",
    "13788131465"
];
var 密码 = [
    "123456lw,",
    "980118lw,",
    "1997qq",
    "199771qq"
];
var 操作账号 = [0, 1, 2, 3];
var 当前运行账号 = dialogs.select("请选择 开始账号", 账号); if (当前运行账号 == -1) { toast("已停止！"); exit(); }

function 进入京东() {
    launchApp("京东");
    idContains("app1").findOne().click();
    if (text("允许").findOne(500)) {
        text("允许").findOne().click();
    }
    desc("我的").findOne().click();
}

function 签到() {
    text("京豆").findOne().parent().parent().click();
    text("我的京豆").findOne();
    sleep(500);
    if (text("已签到").findOnce()) {
        back();
        console.info("1");
        toast("签到已完成");
        return;
    }
    var bound = textContains("去签到领").findOne().bounds();
    sleep(300);
    console.info("2");
    click(bound.centerX(), bound.centerY());
    sleep(300);
    var bound = text("签到领京豆").findOne().bounds();
    sleep(300);
    click(bound.centerX(), bound.centerY());
    sleep(300);
    for (; ;) {
        if (textContains("签到成功").findOnce() || textContains("获得连签奖励").findOnce() || textContains("获得奖励").findOnce()) {
            break;
        }
        sleep(300);
    }
    back();
    text("进店领豆").findOne();
    back();
    text("帮助说明").findOne();
    back();
    desc("我的").findOne();
    toast("签到已完成");
}

function 换号() {
    desc("我的").findOne().click();
    desc("设置").findOne().click();
    text("退出登录").findOne().click();
    text("确定").findOne().click();
    desc("我的").findOne();
    sleep(500);
    var bound = text("登录/注册").findOne().bounds();
    sleep(300);
    click(bound.centerX(), bound.centerY());
    sleep(300);
    text("账号密码登录").findOne().click();
    text("短信验证码登录").findOne();
    sleep(300);
    setText(0, 账号[当前运行账号]);
    sleep(200);
    setText(1, 密码[当前运行账号]);
    sleep(200);
    text("登录").findOne().click();
    for (; ;) {
        if (textContains("安全验证").findOne(300)) {
            device.vibrate(300);
        }
        if (desc("我的").findOne(700)) {
            break;
        }
    }
}



进入京东();
for (var i = 0; i < 4; i++, 当前运行账号++) {
    换号();
    签到();
    if (当前运行账号 == 3) {
        当前运行账号 = -1;
    }
}
console.show();
sleep(100);
console.setPosition(400, 400);
console.setSize(730, 900);
console.info("任务完成！");







