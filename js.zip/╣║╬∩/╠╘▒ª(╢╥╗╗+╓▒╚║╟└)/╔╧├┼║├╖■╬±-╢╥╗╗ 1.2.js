auto.waitFor();

var good_array = [''];

var parent_view = text("2~10元").findOne().parent();
var text1 = "你有  铜" + parent_view.child(0).child(1).text() + "  银" + parent_view.child(2).child(1).text() + "  金" + parent_view.child(4).child(1).text() + "  钻" + parent_view.child(6).child(1).text() + "\n选择一个物品兑换";
var parent_view = text("包裹兑换").findOne().parent().parent();
var good_count = parent_view.childCount();
for (var i = 0; i < good_count; i++) {
    var single_good = parent_view.child(i);
    if (single_good.childCount() == 8) {
        var good_name = parent_view.child(i).child(4).text();
        var cost_view = parent_view.child(i).child(7);
        var good_cost = cost_view.child(1).text() + cost_view.child(2).text();
        good_array[i] = (i + 1) + ". " + good_name + "\n   ￥" + good_cost;
    } else {
        var good_name = parent_view.child(i).child(3).text();
        var cost_view = parent_view.child(i).child(6);
        var good_cost = "已兑换完，今日不可再次兑换";
        good_array[i] = (i + 1) + ". " + good_name + "\n   ￥" + good_cost;
    }
}
var choose_number = dialogs.select(text1, good_array); if (choose_number == null) { toast("未选择！"); exit(); }
log(choose_number)

var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if (分 == null) { toast("已停止！"); exit(); }
var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if (秒 == null) { toast("已停止！"); exit(); }
var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if (延时 == null) { toast("已停止！"); exit(); }
var 日志字串3 = "设定时间：" + 分 + ":" + 秒 + "\n延     时：" + 延时 + "\n";
var 显示字串 = "已选择：" + good_array[choose_number] + "\n" + 日志字串3;


function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info(显示字串 + "\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(100);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute == 分) {
            if (second <= 秒 - 6) {
                print(minute + ":" + second);
                sleep(800);
                continue;
            } else {
                console.info(minute + ":" + second);
                console.info("还有5秒");
                sleep(2000);
                toast("还有3秒!");
                console.hide();
                sleep(1000);
                break;
            }
        } else {
            sleep(800);
            continue;
        }
    }
    console.hide();
    for (; ;) {
        var second = new Date(http.get("http://www.baidu.com").headers["Date"]).getSeconds();
        if (second >= 秒) {
            sleep(延时);
            return;
        }
    }
}





倒计时();
desc(":刷新").findOne().click();
var click_button = text("包裹兑换").findOne().parent().parent().child(choose_number).child(7);
click_button.click();
className("android.widget.Button").text("兑换").findOne().click();
