//
//
auto.waitFor();
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}


for (; ;) {
    if (descStartsWith("更多").findOnce()) {
        descStartsWith("更多").findOne().parent().child(2).click();
        break;
    }
    if (textContains("ꄪ").findOnce()) {
        textContains("ꄪ").findOne().click();
        break;
    }
}
desc("复制链接").findOne().parent().click();

home(); sleep(200); home(); sleep(200); home(); sleep(200);
desc("浏览器").findOne().longClick();
text("应用信息").findOne().parent().click();
var 结束运行 = text("结束运行").findOne().parent();
if (结束运行.enabled()) {
    结束运行.click();
    text("确定").findOne().click();
}
launchApp("浏览器");
desc("扫描二维码").findOne().parent().child(1).click();
//text("取消").findOne();
//sleep(20000000);
sleep(200);
var url1 = textContains("最新复制的内容").findOne().parent().child(1).text().substr(textContains("最新复制的内容").findOne().parent().child(1).text().indexOf("https://"), 36);
setText(url1);
text("前往").findOne().click();
for (; ;) {
    toast("请选择好规格，再点击地址栏");
    for (var i = 0; i < 10; i++) {
        if (text("复制").findOnce()) {
            break;
        }
        if (textContains("网页请求打开").findOnce()) {
            textContains("网页请求打开").findOne().parent().parent().parent().parent().find(text("取消")).click();
        }
        if (textContains("请选择要").findOnce()) {
            text("取消").findOne().click();
        }

        sleep(200);
    }
    if (text("复制").findOnce()) {
        break;
    }
}

var url2 = text("复制").findOne().parent().parent().child(1).text();
log(url2);
var id = url2.substr(url2.indexOf("id="), 15).replace('id=', '');
if (url2.indexOf("skuId=") != -1) {
    var skuId = url2.substr(url2.indexOf("skuId="), 20).replace('skuId=', '');
} else {
    var skuId = "0";
}
//var url3 = "https://h5.m.taobao.com/cart/order.html?itemId=" + id + "&item_num_id=615424415550&_input_charset=utf-8&buyNow=true&v=0&skuId=" + skuId + "&quantity=1";

var url3 = "https://h5.m.taobao.com/cart/order.html?buyParam=" + id + "_" + "1" + "_" + skuId;




launchApp("淘宝");
idContains("app1").findOne().click();
var bound = descContains("打卡签").findOne().bounds();
click(bound.centerX(), bound.centerY());
idContains("msgcenter_panel_input_edit").className("android.widget.EditText").findOne().setText(url3);
text("发送").findOne().parent().click();

log(url3);
toast("链接已发送！");
toast("链接已发送！");
