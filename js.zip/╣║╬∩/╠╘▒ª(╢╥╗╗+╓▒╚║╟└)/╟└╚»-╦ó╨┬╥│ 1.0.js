var 名称版本 = "刷新抢券 1.0";
//
auto.waitFor();
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}

//var 关键字 = dialogs.rawInput("输入选项关键字符\n\n(返回退出脚本)", ""); if (关键字 == null) { toast("已停止！"); exit(); }
var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if (分 == null) { toast("已停止！"); exit(); }
var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if (秒 == null) { toast("已停止！"); exit(); }
var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 4); if (延时 == null) { toast("已停止！"); exit(); }
var 次数 = 0;

var time = new Date(http.get("http://www.baidu.com").headers["Date"]);
var month = time.getMonth() + 1;
var log = "/sdcard/脚本/日志" + month + "." + time.getDate() + ".js";
var 日志字串1 = "\n===============================\n" + time.getHours() + ":" + time.getMinutes() + ":" + time.getSeconds() + "\n    /----" + 名称版本 + "----/\n";
var 显示字串 = "/----" + 名称版本 + "----/\n\n" + "开始时间：" + 分 + ":" + 秒 + "\n延       时：" + 延时 + "\n" ;
var 日志字串5 = 日志字串1 + "开始时间：" + 分 + ":" + 秒 + "\n延     时：" + 延时 + "\n" ;
files.append(log, 日志字串5);


function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info(显示字串 + "\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(100);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute == 分) {
            if (second <= 秒 - 6) {
                print(minute + ":" + second);
                sleep(800);
                continue;
            } else {
                console.info(minute + ":" + second);
                console.info("还有5秒");
                sleep(2000);
                toast("还有3秒!");
                console.hide();
                sleep(1000);
                break;
            }
        } else {
            sleep(800);
            continue;
        }
    }
    console.hide();
    for (; ;) {
        var second = new Date(http.get("http://www.baidu.com").headers["Date"]).getSeconds();
        if (second >= 秒) {
            sleep(延时);
            return;
        }
    }
}

function 刷新() {
    desc(":刷新").findOne().click();
    for (; ;) {
        if (textContains("新国货券").findOnce()) {
            break;
        }
    }
    for (; ;) {
        if (!textContains("新国货券").findOnce()) {
            break;
        }
    }
}

function 点击() {
    var 父控件 = textContains("满100可用").findOne().parent().parent();
    var 子控件 = 父控件.child(父控件.childCount() - 1).child(0);
    files.append(log, "\n控件名字：" + 子控件.child(0).text());
    if (子控件.child(0).text() != "22:00开抢") {
        子控件.click();
        return true;
    } else {
        return false;
    }
}


倒计时();
for (; ;) {
    刷新();
    if (点击()) {
        toast("抢购成功！");
        files.append(log, "\n    进入次数统计：" + 次数 + "\n================================\n");
        break;
    } else {
        continue;
    }
}





