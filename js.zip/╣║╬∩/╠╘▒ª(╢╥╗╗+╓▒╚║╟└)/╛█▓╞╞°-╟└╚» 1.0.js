auto.waitFor();

var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if (分 == null) { toast("已停止！"); exit(); }
var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if (秒 == null) { toast("已停止！"); exit(); }
var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if (延时 == null) { toast("已停止！"); exit(); }
var 关键字 = dialogs.rawInput("输入关键字\n\n(返回退出脚本)", ""); if (关键字 == null) { toast("已停止！"); exit(); }
var 显示字串 = "关键字：" + 关键字 + "\n开始时间：" + 分 + ":" + 秒 + "\n延       时：" + 延时 + "\n";

function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info(显示字串 + "\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(100);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute == 分) {
            if (second <= 秒 - 6) {
                print(minute + ":" + second);
                sleep(800);
                continue;
            } else {
                console.info(minute + ":" + second);
                console.info("还有5秒");
                sleep(2000);
                toast("还有3秒!");
                console.hide();
                sleep(1000);
                break;
            }
        } else {
            sleep(800);
            continue;
        }
    }
    console.hide();
    for (; ;) {
        var second = new Date(http.get("http://www.baidu.com").headers["Date"]).getSeconds();
        if (second >= 秒) {
            sleep(延时);
            return;
        }
    }
}

倒计时();
for (; ;) {
    var parent_view = text("已攒红包池").findOne().parent().parent();
    parent_view.child(parent_view.childCount() - 1).click();
    textContains("爆款好券").findOne().click();
    textContains("神券").findOne();
    if (textContains(关键字).findOnce()) {
        log(3445756);
        var parent_view = textContains(关键字).findOne().parent();
        var click_button = parent_view.child(parent_view.childCount() - 1);
        click_button.click();
        text("确认兑换").findOne().click();
        toastLog("兑换成功");
        break;
    } else {
        back();
        continue;
    }
}


