var 名称版本 = "直连抢购 1.6";
//修改提交订单
auto.waitFor();
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}

//设定
{
    var 抢购模式 = dialogs.select("请选择 抢购模式\n\n(返回退出脚本)\n", "● 直抢+捡漏", "● 捡漏"); if (抢购模式 == -1) { toast("已停止！"); exit(); }
    if (抢购模式 == 0) {
        var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if (分 == null) { toast("已停止！"); exit(); }
        var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if (秒 == null) { toast("已停止！"); exit(); }
        var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if (延时 == null) { toast("已停止！"); exit(); }
    }
    var 价格判断 = dialogs.select("是否判断价格？\n\n(返回退出脚本)\n", "● 判断价格", "● 不判断价格"); if (价格判断 == -1) { toast("已停止！"); exit(); }
    if (价格判断 == 0) {
        var 理想价格 = dialogs.input("输入物品理想价格\n\n(返回退出脚本)", 50); if (理想价格 == null) { toast("已停止！"); exit(); }
    }
    var 开关选项 = dialogs.select("是否打开开关？\n\n(返回退出脚本)\n", "● 打开开关", "● 不打开"); if (开关选项 == -1) { toast("已停止！"); exit(); }
    var 提交延时 = dialogs.input("输入提交延时ms\n\n(返回退出脚本)", 150); if (提交延时 == null) { toast("已停止！"); exit(); }
    var 是否付款 = dialogs.select("是否付款？\n\n(返回退出脚本)\n", "● 付款", "● 不付款"); if (是否付款 == -1) { toast("已停止！"); exit(); }
    if (是否付款 == 0) {
        var 付款密码 = dialogs.select("选择密码\n\n(返回退出脚本)\n", "● 我", "● 小武"); if (付款密码 == -1) { toast("已停止！"); exit(); }
    }
}

//显示
{
    var time = new Date(http.get("http://www.baidu.com").headers["Date"]);
    var month = time.getMonth() + 1;
    var log = "/sdcard/脚本/日志" + month + "." + time.getDate() + ".js";
    var 日志字串1 = "\n================================\n" + time.getHours() + ":" + time.getMinutes() + ":" + time.getSeconds() + "\n    /----" + 名称版本 + "----/\n";
    if (抢购模式 == 0) {
        var 日志字串2 = "抢购模式：直抢+捡漏\n";
        var 日志字串3 = "设定时间：" + 分 + ":" + 秒 + "\n延    时：" + 延时 + "\n";
    }
    if (抢购模式 == 1) {
        var 日志字串2 = "抢购模式：捡漏模式\n";
        var 日志字串3 = "";
    }
    if (价格判断 == 0) { var 日志字串4 = "理想价格：" + 理想价格 + "\n"; } else { var 日志字串4 = "不判断价格！\n"; }
    if (开关选项 == 0) { var 日志字串5 = "开关选项：打开开关\n提交延时：" + 提交延时 + "\n"; } else { var 日志字串5 = "开关选项：不打开\n提交延时：" + 提交延时 + "\n"; }
    if (是否付款 == 0) {
        if (付款密码 == 0) { var 日志字串6 = "付款密码：我\n"; } else { var 日志字串6 = "付款密码：小武\n"; }
    } else {
        var 日志字串6 = "不付款！\n";
    }
    var 显示字串 = "      /----" + 名称版本 + "----/\n\n" + 日志字串2 + 日志字串3 + 日志字串4 + 日志字串5 + 日志字串6 + "\n";
    var 日志字串7 = 日志字串1 + 日志字串2 + 日志字串3 + 日志字串4 + 日志字串5 + 日志字串6 + "\n";
    files.append(log, 日志字串7);
    var 次数 = 0; var 实际价格 = -1; var 是否成功 = 0;
    var bound = idContains("msgcenter_panel_input_edit").findOne().bounds();
    var x = 300; var y = bound.centerY() - 250;
}


function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info(显示字串 + "\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(100);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute == 分) {
            if (second <= 秒 - 6) {
                print(minute + ":" + second);
                sleep(800);
                continue;
            } else {
                console.info(minute + ":" + second);
                console.info("还有5秒");
                sleep(2000);
                toast("还有3秒!");
                console.hide();
                sleep(1000);
                break;
            }
        } else {
            sleep(800);
            continue;
        }
    }
    console.hide();
    for (; ;) {
        var second = new Date(http.get("http://www.baidu.com").headers["Date"]).getSeconds();
        if (second >= 秒) {
            sleep(延时);
            return;
        }
    }
}

function 进入判断() {
    for (; ;) {
        if (text("提交订单").findOne(1000)) {
            return true;
        }
        if (textContains("休息会").findOnce()) {
            var 块 = idContains("nc_1_n1t").findOne().bounds();
            swipe(块.centerX(), 块.centerY(), device.width, 块.centerY(), 30);
            continue;
        }
        if (textContains("我知道了").findOnce()) {
            sleep(1500);
            idContains("msgcenter_panel_input_edit").className("android.widget.EditText").findOne();
            click(x, y);
            次数++;
            continue;
        }
        click(x, y);
    }
}

function 价格() {
    实际价格 = textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥', '');
    if (实际价格 > 理想价格) {
        return false;
    } else {
        return true;
    }
}

function 打开开关() {
    for (; ;) {
        swipe(540, 1600, 540, 300, 100);
        if (desc("关闭").findOnce()) {
            break;
        }
    }
    desc("关闭").findOne().click();
    desc("打开").findOne();
}

function 提交成功判断() {
    for (; ;) {
        if (textContains("我知道了").findOnce()) {
            sleep(1500);
            textContains("我知道了").findOne().click();
            是否成功 = 0;
            break;
        }
        if (textContains("付款详情").findOnce() || textContains("支付宝账号").findOnce() || textContains("免密支付").findOnce()) {
            是否成功 = 1;
            toast("抢购成功！");
            if (是否付款 == 0) {
                付款();
            }
            toast("可在当天日志文件中查看该次抢购相关参数！");
            break;
        }
    }
}

function 付款() {
    for (; ;) {
        if (textContains("立即付款").findOnce()) {
            textContains("立即付款").findOne().parent().parent().click();
            for (; ;) {
                if (textContains("使用密码").findOnce()) {
                    textContains("使用密码").findOne().click();
                }
                if (textContains("请输入支付密码").findOnce()) {
                    break;
                }
            }

            if (付款密码 == 0) {
                text("1").findOne().click();
                text("9").findOne().click();
                text("9").findOne().click();
                text("7").findOne().click();
                text("7").findOne().click();
                text("1").findOne().click();
            } else {
                text("6").findOne().click();
                text("5").findOne().click();
                text("5").findOne().click();
                text("6").findOne().click();
                text("6").findOne().click();
                text("5").findOne().click();
            }
            return;
        }
        if (textContains("免密支付").findOnce()) {
            var 免密 = textContains("可在我的淘宝").findOne().parent().parent();
            免密.child(免密.childCount() - 3).child(0).click();
            return;
        }
    }
}



function 直抢模式() {
    倒计时();
    for (次数 = 0; 次数 < 4; 次数++) {
        idContains("msgcenter_panel_input_edit").className("android.widget.EditText").findOne();
        bound = idContains("msgcenter_panel_input_edit").findOne().bounds();
        x = 300; var y = bound.centerY() - 250;
        click(x, y);
        进入判断();
        if (textContains("购买数量超过").findOnce()) {
            back();
            files.append(log, "购买数量超过" + "  次数：" + 次数 + "\n");
            continue;
        }
        if (textContains("商品不能购买").findOnce()) {
            back();
            files.append(log, "商品不能购买" + "  次数：" + 次数 + "\n");
            continue;
        }
        if (textContains("已无库存").findOnce()) {
            back();
            files.append(log, "已无库存" + "  次数：" + 次数 + "\n");
            continue;
        }
        if (textContains("优惠信息变更").findOnce()) {
            back();
            files.append(log, "优惠信息变更" + "  次数：" + 次数 + "\n");
            continue;
        }
        if (textContains("该商品不支持").findOnce()) {
            back();
            files.append(log, "该商品不支持" + "  次数：" + 次数 + "\n");
            continue;
        }
        if (textContains("该宝贝不支持").findOnce()) {
            back();
            files.append(log, "该宝贝不支持" + "  次数：" + 次数 + "\n");
            continue;
        }
        if (开关选项 == 0) {
            打开开关();
        }
        if (价格判断 == 0) {
            if (!价格()) {
                back();
                files.append(log, "价格：￥ " + 实际价格 + "  次数：" + 次数 + "\n");
                continue;
            }
        }
        sleep(提交延时);
        for (; ;) {
            text("提交订单").findOne().click();
            if (!text("提交订单").findOnce()) {
                break;
            }
            sleep(50);
        }
        if (!提交成功判断()) {
            continue;
        } else {
            break;
        }
    }
    files.append(log, "最后显示价格：￥ " + 实际价格 + "\n进入次数统计：" + 次数 + "\n===============================\n");
    if (是否成功 == 0) {
        toast("抢购失败！自动进入捡漏模式！");
        捡漏模式();
    }
}

function 捡漏模式() {
    var 捡漏延时 = dialogs.input("输入捡漏延时(单位毫秒)\n\n(返回退出脚本)", 10); if (捡漏延时 == null) { toast("已停止！"); exit(); }
    for (; ;) {
        idContains("msgcenter_panel_input_edit").className("android.widget.EditText").findOne();
        bound = idContains("msgcenter_panel_input_edit").findOne().bounds();
        x = 300; var y = bound.centerY() - 250;
        click(x, y);
        进入判断();
        if (textContains("购买数量超过").findOnce()) {
            back();
            continue;
        }
        if (textContains("商品不能购买").findOnce()) {
            back();
            continue;
        }
        if (textContains("已无库存").findOnce()) {
            back();
            continue;
        }
        if (textContains("优惠信息变更").findOnce()) {
            back();
            continue;
        }
        if (textContains("该商品不支持").findOnce()) {
            back();
            continue;
        }
        if (开关选项 == 0) {
            打开开关();
        }
        if (价格判断 == 0) {
            if (!价格()) {
                sleep(捡漏延时);
                back();
                continue;
            }
        }
        sleep(提交延时);
        for (; ;) {
            text("提交订单").findOne().click();
            if (!text("提交订单").findOnce()) {
                break;
            }
            sleep(50);
        }
        if (!提交成功判断()) {
            continue;
        } else {
            break;
        }
    }
    files.append(log, "最后显示价格：￥ " + 实际价格 + "\n===============================\n");
}

if (抢购模式 == 0) { 直抢模式(); }
if (抢购模式 == 1) { 捡漏模式(); }
