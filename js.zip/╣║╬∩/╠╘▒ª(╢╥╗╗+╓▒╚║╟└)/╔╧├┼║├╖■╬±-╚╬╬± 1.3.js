auto.waitFor();


function Enter_package() {
    if (text("任务数量").findOnce() || text("做任务得包裹").findOnce()) {
        text("做任务得包裹").findOne().parent().parent().click();
        toastLog("已进入任务页面");
        sleep(3000);
    } else {
        launchApp("淘宝");
        toast("等待进入首页");
        desc("首页").findOne();
        toast("进入消息页");
        desc("消息").findOne().click();
        sleep(2000);
        desc("打卡签到群").findOne().parent().click();
        var text1 = 100 * Math.random();
        var url = "https://page.cainiao.com/mcn/pack-factory/index.html?app=ali_tb&cpp=1&&suid=ABA027CE-C341-453B-A542-5405547B2773#/\n----\n复制到淘宝任意一个聊天窗口可以看到活动" + text1;
        classNameContains("EditText").findOne();
        sleep(2000);
        classNameContains("EditText").findOne().setText(url);
        desc("发送").classNameContains("RelativeLayout").findOne().click();
        sleep(1000);
        var bound = desc(url).findOne().bounds();
        click(bound.centerX(), bound.centerY());
        text("做任务得包裹").findOne().parent().parent().click();
        text("任务数量").findOne();
        toastLog("已进入任务页面");
        sleep(3000);
    }
}

function mission_exit(text1) {
    if (textContains(text1).findOnce()) {
        click_button = textContains(text1).findOne().parent().parent().parent().child(2);
        if (click_button.text() == "已完成") {
            return 0;
        }
        if (click_button.text() == "去完成") {
            click_button.click();
            return 1;
        }
    }
    return 0;
}

function Answer_Question() {
    for (; ;) {
        if (textContains("C、").findOnce()) {
            textContains("C、").findOne().parent().click();
        } else if (textContains("B、").findOnce()) {
            textContains("B、").findOne().parent().click();
        } else {
            textContains("A、").findOne().parent().click();
        }
        sleep(800);
        if (text("换一题").findOnce()) {
            text("换一题").findOne().click();
            sleep(500);
        }
        if (textContains("关闭(").findOnce()) {
            textContains("关闭(").findOne().click();
            break;
        }
    }
    sleep(2000);
}

function Shopping_Cart() {
    for (var i = 0; i < 5; i++) {
        var bound = textContains("¥").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        sleep(1000);
        back();
        textContains("上门好服务").findOne();
        sleep(500);
        if (!textContains("加入购物车，即可完成任务").findOnce()) {
            text("做任务得包裹").findOne().parent().parent().click();
            break;
        }
    }
    sleep(2000);
}

function day_Shopping_Cart() {
    if (textContains("恭喜获得天天红包").findOne(4000)) {
        text("x").findOne().click();
    }
    sleep(1000);
    for (var i = 0; i < 4; i++) {
        var bound = textContains("￥").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        sleep(2000);
        back();
        text("天天领红包").findOne();
        sleep(500);
        if (textContains("已完成任务").findOnce()) {
            back();
            sleep(1000);
            if (textContains("忍痛离开").findOnce()) {
                textContains("忍痛离开").findOne().click();
                back();
                break;
            }
            break;
        }
    }
    sleep(2000);
}

function add_package() {
    var rand_number = "43";
    for (var i = 0; i < 11; i++) {
        rand_number = rand_number + Math.floor(Math.random() * 10);
    }
    textContains("输入快递单号").findOne();
    sleep(1000);
    classNameContains("EditText").findOne().setText(rand_number);
    sleep(3000);
    var bound = text("添加到包裹列表").findOne().bounds();
    click(bound.centerX(), bound.centerY());
    sleep(2000);
    desc("返回").findOne().click();
    sleep(2000);
}

function Browse_goods() {
    for (; ;) {
        if (textContains("滑动开始计时").findOnce() || textContains("浏览主会场商品").findOnce()) {
            break;
        }
        sleep(1000);
    }
    swipe(540, 1800, 540, 300, 500);
    sleep(1000);
    swipe(540, 1800, 540, 300, 500);
    sleep(1000);
    swipe(540, 1800, 540, 300, 500);
    sleep(18000);
    text("做任务得包裹").findOne().parent().parent().click();
    sleep(1000);
}

function fruit_sign() {
    sleep(5000);
    click(360, 920);
    sleep(3000); back_mission();
}

function back_5() {
    toastLog("5秒返回");
    sleep(5000); back_mission();
}

function back_15() {
    toastLog("滑动浏览，约15秒返回");
    sleep(3000); swipe(540, 1800, 540, 300, 500);
    sleep(1000); swipe(540, 1800, 540, 300, 500);
    sleep(1000); swipe(540, 1800, 540, 300, 500);
    sleep(15000);
    for (; ;) {
        if (text("任务完成").findOnce() || text("已完成浏览任务").findOnce()) {
            sleep(2000);
            break;
        }
    }
    for (; ;) {
        if (text("忍痛离开").findOnce()) {
            text("忍痛离开").findOne().click(); sleep(2000);
        }
        if (text("x").findOnce()) {
            text("x").findOne().click(); sleep(1000);
        }
        if (text("任务数量").findOnce()) {
            break;
        }
        back(); sleep(1000);
    }
}

function back_mission() {
    for (; ;) {
        if (text("任务数量").findOnce()) { sleep(1000); break; }
        back();
        sleep(1000);
    }
}

Enter_package();
for (; ;) {
    if (text("领取").findOnce()) {
        text("领取").findOne().click();
        sleep(1500);
    }
    if (text("已完成12/12").findOne(1000)) {
        toastLog("任务已完成");
        toastLog("任务已完成");
        toastLog("任务已完成");
        break;
    }

    if (mission_exit("浏览会场宝贝")) { Browse_goods(); continue; }
    if (mission_exit("去探索")) { back_5(); continue; }
    if (mission_exit("浏览超惠寄")) { back_5(); continue; }
    if (mission_exit("用能量喂养")) { back_5(); continue; }
    if (mission_exit("参与1次")) { Answer_Question(); continue; }


    if (mission_exit("逛一逛裹裹")) { back_15(); continue; }
    if (mission_exit("添加1个包裹")) { add_package(); continue; }
    if (mission_exit("浏览天天")) { back_15(); continue; }
    if (mission_exit("加购3个天天")) { day_Shopping_Cart(); continue; }
    if (mission_exit("完成1次")) { fruit_sign(); continue; }

    toastLog("已完成所有可执行任务");
    toastLog("已完成所有可执行任务");
    toastLog("已完成所有可执行任务");
    break;
}

