auto.waitFor();

var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if (分 == null) { toast("已停止！"); exit(); }
var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if (秒 == null) { toast("已停止！"); exit(); }
var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 4); if (延时 == null) { toast("已停止！"); exit(); }
var bound = idContains("msgcenter_panel_input_edit").findOne().bounds();
var x = 300; var y = bound.centerY() - 250;
var 显示字串 = "开始时间：" + 分 + ":" + 秒 + "\n延       时：" + 延时 + "\n";


function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info(显示字串 + "\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(100);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute == 分) {
            if (second <= 秒 - 6) {
                print(minute + ":" + second);
                sleep(800);
                continue;
            } else {
                console.info(minute + ":" + second);
                console.info("还有5秒");
                sleep(2000);
                toast("还有3秒!");
                console.hide();
                sleep(1000);
                break;
            }
        } else {
            sleep(800);
            continue;
        }
    }
    console.hide();
    for (; ;) {
        var second = new Date(http.get("http://www.baidu.com").headers["Date"]).getSeconds();
        if (second >= 秒) {
            sleep(延时);
            return;
        }
    }
}

function 进入() {
    idContains("msgcenter_panel_input_edit").className("android.widget.EditText").findOne();
    bound = idContains("msgcenter_panel_input_edit").findOne().bounds();
    x = 300; y = bound.centerY() - 250;
    click(x, y);
    for (; ;) {
        click(x, y);
        if (text("国际直营指定商品使用").findOnce()) {
            break;
        }
    }
}

function 点击() {
    var click_button = text("国际直营指定商品使用").findOne().parent().parent().child(4).child(0);
    //var click_button = text("天猫国际指定商品使用").findOne().parent().parent().child(4).child(0);
    if (click_button.child(0).text() == "立即抢") {
        click_button.click(); sleep(300);
        click_button.click(); sleep(300);
        click_button.click(); sleep(300);
        click_button.click(); sleep(300);
        return 1;
    } else {
        back();
        return 0;
    }
}


倒计时();
for (; ;) {
    进入();
    if (点击()) {
        toast("抢购成功！");
        break;
    } else {
        continue;
    }
}

