//礼品兑换 1.2
//矫正
auto.waitFor();
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}

var time = new Date(http.get("http://www.baidu.com").headers["Date"]);
var month = time.getMonth()+1;
var log = "/sdcard/脚本/日志"+month+"."+time.getDate()+".js";
files.append(log, "\n======礼品兑换======\n");

var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if (分 == null) { toast("已停止！"); exit(); }
var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if (秒 == null) { toast("已停止！"); exit(); }
var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if (延时 == null) { toast("已停止！"); exit(); }



function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info("\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(100);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute == 分) {
            if (second <= 秒 - 6) {
                print(minute + ":" + second);
                sleep(800);
                continue;
            } else {
                console.info(minute + ":" + second);
                console.info("还有5秒");
                sleep(2000);
                toast("还有3秒!");
                console.hide();
                sleep(1000);
                break;
            }
        } else {
            sleep(800);
            continue;
        }
    }
    console.hide();
    for (; ;) {
        var second = new Date(http.get("http://www.baidu.com").headers["Date"]).getSeconds();
        if (second >= 秒) {
            sleep(延时);
            return;
        }
    }
}


function 礼品兑换(){
    swipe(540, 300, 540, 1800, 300);
    for (;;) {
        if (textContains("加载中").findOnce()) {
            break;
        }
    }
    for (; ;) {
        if (!textContains("加载中").findOnce()) {
            break;
        }
    }

    for (; ;) {
        if (text("立即兑换").findOnce()) {
            for (; ;) {
                text("立即兑换").findOne().click();
                if (text("确定").findOnce()) {
                    if (textContains("当前无法兑换").findOnce()) {
                        return false;
                    }
                    if (textContains("今日礼品已全部兑光").findOnce()) {
                        exit();
                    }
                    break;
                }
            }
            break;
        }
    }
    var k = 0;
    for (; ;) {
        text("确定").findOne().click();
        if (!text("确定").findOnce()) {
            k++;
            if (k == 10) {
                break;
            }
        }
    }
    return true;
}



倒计时();
for (var i=1; ;i++) {
    files.append(log, "第"+i+"次\n");
    if (礼品兑换()) {
        files.append(log, "兑换成功！\n============\n");
        break;
    }
}

















