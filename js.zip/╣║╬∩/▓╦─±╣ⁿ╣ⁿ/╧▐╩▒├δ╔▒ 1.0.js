var 名称版本 = "限时秒杀 1.0.js";
auto.waitFor();
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}

//设定
{
    var good_array = [''];
    var click_buttuns = [''];
    var array_number = 0;

    textContains("0场").find().each(function (项) {
        var parent_view = 项.parent();
        var good_name = parent_view.child(2).text();
        var coast_number = parent_view.child(5).text() + parent_view.child(6).text();
        var click_buttun = parent_view.child(8);
        good_array[array_number] = good_name + "\n消耗 " + coast_number;
        click_buttuns[array_number] = click_buttun;
        array_number++;
    });
    var choose_number = dialogs.select("选择一个物品兑换", good_array); if (choose_number == null) { toast("未选择！"); exit(); }
    var bound = click_buttuns[choose_number].bounds();

    var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if (分 == null) { toast("已停止！"); exit(); }
    var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if (秒 == null) { toast("已停止！"); exit(); }
    var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if (延时 == null) { toast("已停止！"); exit(); }
}
//显示
{
    var time = new Date(http.get("http://www.baidu.com").headers["Date"]);
    var month = time.getMonth() + 1;
    var log = "/sdcard/脚本/日志" + month + "." + time.getDate() + ".js";
    var 日志字串1 = "\n================================\n" + time.getHours() + ":" + time.getMinutes() + ":" + time.getSeconds() + "\n    /----" + 名称版本 + "----/\n";
    var 日志字串2 = "";
    var 日志字串3 = "";
    var 日志字串4 = "设定时间：" + 分 + ":" + 秒 + "\n延   时：" + 延时 + "\n";
    var 显示字串 = "      /----" + 名称版本 + "----/\n\n" + 日志字串2 + 日志字串3 + 日志字串4;
    var 日志字串5 = 日志字串1 + 日志字串2 + 日志字串3 + 日志字串4;
    files.append(log, 日志字串5);
}



function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info(显示字串 + "\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(1000);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute >= 分 && second >= 秒) {
            sleep(延时);
            break;
        }
        if (minute == 分 && second <= 秒 - 10) {
            print(minute + ":" + second);
            sleep(800);
        }
        if (minute == 分 && second == 秒 - 9) {
            print(minute + ":" + second);
            console.info("还有9秒");
            toast("还有9秒!\n请等待！");
            sleep(2000);
            toast("还有7秒!\n请等待！");
            console.hide();
            toast("还有5秒!\n马上开始！");
            toast("还有3秒!\n马上开始！");
        }
    }
    return;
}

倒计时();

for (; ;) {
    click(bound.centerX(),bound.centerY());
    if (text("确认").findOnce()) {
        text("确认").findOne().click();
        toast("操作完成");
        break;
    }
}




