//裹酱打卡 2.1
//版本更新

auto.waitFor();

var mission_number = 0;
var 控件;
var number;
var 操作账号 = [0, 1, 2];


var 账号 = [
    "18873292759",
    "511303a22tm.cdb@sina.cn",
    "13158507242",
    "13788131465",
    "18873208031",
    "hpp0165@163.com"
];
var 密码 = [
    "980118lw,",
    "980118lw,",
    "123456lw,",
    "1997qq",
    "1997qq",
    "123456lw,"
];
var 当前运行账号 = dialogs.select("请选择 开始账号", 账号); if (当前运行账号 == -1) { toast("已停止！"); exit(); }


function 进入首页() {
    launchApp("菜鸟");
    toast("正在启动app");
    for (; ;) {
        if (textContains("开启通知实时掌握").findOnce()) {
            idContains("sys_notify_setting_dialog_close").findOne().click();
            sleep(1000);
        }
        if (desc("我的").findOnce()) {
            break;
        }
    }
    text("我的").findOne();
    sleep(1000);
}

{
    function 进入裹酱() {
        sleep(1000);
        for (; ;) {
            if (textContains("裹酱积分").findOnce()) {
                textContains("裹酱积分").findOne().parent().parent().parent().click();
                sleep(1000);
                break;
            } else {
                desc("我的").findOne().parent().child(0).click();
                sleep(1000);
            }
        }
        text("赚裹酱").findOne();
        sleep(1000);
        text("赚裹酱").findOne().click();
        textContains("逛裹酱商城").findOne();
        sleep(1500);
    }

    function 领取裹酱() {
        if (text("领取裹酱").findOnce()) {
            text("领取裹酱").findOne().click();
            sleep(2000);
        }
    }

    function 逛商城() {
        sleep(15000);
        textContains("已完成浏览").findOne();
        for (; ;) {
            if (textContains("已完成浏览").findOne(500)) {
                back();
                sleep(1500);
            }
            if (textContains("+10").findOne(500)) {
                sleep(2000);
                break;
            }
        }
    }

    function 查物流() {
        sleep(3000);
        var bound = idContains("package_list_listview").findOne().child(0).bounds();
        click(bound.centerX(), bound.centerY());
        textContains("客服").findOne();
        sleep(2000);
        back_mission();
    }

    function 观看短视频() {
        sleep(2000);

        if (text("反馈").findOnce()) {
            //sleep(1000);
            var bound = text("反馈").findOne().parent().child(1).bounds();
            click(bound.centerX(), bound.centerY());
        }
        idContains("tt_video_ad_close_layout").findOne().click();
        for (; ;) {
            if (text("放弃奖励").findOnce()) {
                text("放弃奖励").findOne().click();
            }
            if (textContains("+10").findOnce()) {
                break;
            }
        }
        sleep(2000);
    }

    function 每日首次添加包裹() {
        var rand_number = "2100";
        for (var i = 0; i < 8; i++) {
            rand_number = rand_number + Math.floor(Math.random() * 10);
        }
        textContains("输入快递单号").findOne().setText(rand_number);
        sleep(2000);
        var bound = text("添加到包裹列表").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        sleep(3000);
        if (text("赚裹酱").findOnce()) {
            return;
        } else {
            idContains("package_query_import_iv_close").findOne().click();
            text("赚裹酱").findOne();
        }
    }

    function 五秒返回() {
        sleep(5000);
        back_mission();
    }

    function back_mission() {
        for (; ;) {
            if (textContains("+10").findOnce()) { sleep(1000); break; }
            back();
            sleep(1000);
        }
    }


    function find_number(text1) {
        for (var i = 0; i < number; i++) {
            var 任务控件 = 控件[i].text();
            if (任务控件.indexOf(text1) != -1) {
                return i;
            }
        }
    }

    function minssion_judge(mission_number, button_offset) {
        for (; ;) {
            控件 = textContains("逛裹酱商城").findOne().parent().children();
            if (控件[mission_number + button_offset].text() == "明日再来") {
                log("明日再来");
                return 0;
            }
            if (控件[mission_number + button_offset].text() == "领取裹酱") {
                log("领取裹酱");
                领取裹酱();

            }
            if (控件[mission_number + button_offset].text() == "立即完成") {
                log("立即完成");
                控件[mission_number + button_offset].click();
                return 1;
            }
        }
    }

    function mission(text1, offset) {
        log(text1);
        领取裹酱();
        控件 = textContains("逛裹酱商城").findOne().parent().children();
        number = textContains("逛裹酱商城").findOne().parent().childCount();
        mission_number = find_number(text1);
        if (mission_number && minssion_judge(mission_number, offset)) {
            if (text1 == "逛裹酱商城20s") { 逛商城(); }
            if (text1.indexOf("观看完整短视频") != -1) { 观看短视频(); }
            if (text1 == "每日首次查件") { 查物流(); }
            if (text1 == "每日首次添加包裹") { 每日首次添加包裹(); }


            if (text1 == "去抓娃娃") { 五秒返回(); }
            if (text1 == "去逛裹裹购") { 五秒返回(); }
            if (text1.indexOf("去菜鸟海洋") != -1) { 五秒返回(); }
            if (text1.indexOf("来天猫") != -1) { 五秒返回(); }

            if (text1 == "去参与618瓜分1亿活动") { 五秒返回(); }
            if (text1 == "618专享抢最高10元红包") { 五秒返回(); }
            if (text1 == "首次打开签到提醒") { ; }

            log("任务完成"); return 1;
        } else {
            log("任务完成跳过"); return 0;
        }
    }

}//做任务

function 做任务() {
    进入裹酱();
    toast("开始做任务");
    sleep(2000);
    for (; ;) {
        if (mission("逛裹酱商城20s", 3)) { continue; }
        if (mission("观看完整短视频", 2)) { continue; }
        if (mission("去菜鸟海洋", 2)) { continue; }
        if (mission("去抓娃娃", 2)) { continue; }
        if (mission("每日首次查件", 2)) { continue; }
        if (mission("去逛裹裹购", 2)) { continue; }
        if (mission("每日首次添加包裹", 2)) { continue; }
        if (mission("来天猫", 2)) { continue; }

        if (mission("去参与618瓜分1亿活动", 2)) { continue; }
        if (mission("618专享抢最高10元红包", 2)) { continue; }
        if (mission("首次打开签到提醒", 2)) { continue; }

        toastLog("当前帐号任务已完成");
        sleep(2000);
        break;
    }
    for (; ;) {
        back();
        if (text("我的").findOne(2000)) {
            break;
        }
    }
}

function one_billion() {

    function Enter_1() {
        for (; ;) {
            if (textContains("包裹梦工厂").findOnce()) {
                textContains("包裹梦工厂").findOne().parent().parent().parent().click();
                sleep(1000);
                break;
            } else {
                desc("我的").findOne().parent().child(0).click();
                sleep(1000);
            }
        }
        text("做任务得包裹").findOne().parent().parent().click();
        text("任务数量").findOne();
        toastLog("已进入任务页面");
        sleep(3000);

    }

    function mission_exit(text1) {
        if (textContains(text1).findOnce()) {
            click_button = textContains(text1).findOne().parent().parent().parent().child(2);
            if (click_button.text() == "已完成") {
                return 0;
            }
            if (click_button.text() == "去完成") {
                click_button.click();
                return 1;
            }
        }
        return 0;
    }

    function Answer_Question() {
        for (; ;) {
            if (textContains("C、").findOnce()) {
                textContains("C、").findOne().parent().click();
            } else if (textContains("B、").findOnce()) {
                textContains("B、").findOne().parent().click();
            } else {
                textContains("A、").findOne().parent().click();
            }
            sleep(800);
            if (text("换一题").findOnce()) {
                text("换一题").findOne().click();
                sleep(500);
            }
            if (textContains("关闭(").findOnce()) {
                textContains("关闭(").findOne().click();
                break;
            }
        }
        sleep(2000);
    }


    function day_Shopping_Cart() {
        if (textContains("恭喜获得天天红包").findOne(4000)) {
            text("x").findOne().click();
        }
        sleep(1000);
        for (var i = 0; i < 4; i++) {
            var bound = textContains("￥").findOne().bounds();
            click(bound.centerX(), bound.centerY());
            sleep(2000);
            back();
            text("天天领红包").findOne();
            sleep(500);
            if (textContains("已完成任务").findOnce()) {
                back();
                sleep(1000);
                if (textContains("忍痛离开").findOnce()) {
                    textContains("忍痛离开").findOne().click();
                    back();
                    break;
                }
                break;
            }
        }
        sleep(2000);
    }

    function add_package() {
        var rand_number = "43";
        for (var i = 0; i < 11; i++) {
            rand_number = rand_number + Math.floor(Math.random() * 10);
        }
        textContains("输入快递单号").findOne();
        sleep(1000);
        classNameContains("EditText").findOne().setText(rand_number);
        sleep(3000);
        var bound = text("添加到包裹列表").findOne().bounds();
        click(bound.centerX(), bound.centerY());
        sleep(2000);
        desc("返回").findOne().click();
        sleep(2000);
    }

    function Browse_goods() {
        sleep(2000);
        if (textContains("滑动开始计时").findOnce() || textContains("浏览主会场商品").findOnce()) {
            swipe(540, 1800, 540, 300, 500);
            sleep(1000);
            swipe(540, 1800, 540, 300, 500);
            sleep(1000);
            swipe(540, 1800, 540, 300, 500);
            sleep(20000);
            text("做任务得包裹").findOne().parent().parent().click();
            sleep(1000);
        }
    }

    function fruit_sign() {
        sleep(5000);
        click(360, 920);
        sleep(1000); back(); text("任务数量").findOne(); sleep(1000);
    }

    function back_5() {
        toastLog("5秒返回");
        sleep(5000); back(); text("任务数量").findOne(); sleep(1000);
    }

    function back_15() {
        toastLog("滑动浏览，约15秒返回");
        sleep(1000); swipe(540, 1800, 540, 300, 500);
        sleep(1000); swipe(540, 1800, 540, 300, 500);
        sleep(1000); swipe(540, 1800, 540, 300, 500);
        sleep(15000);
        for (; ;) {
            if (text("任务完成").findOnce() || text("已完成浏览任务").findOnce()) {
                sleep(2000);
                break;
            }
        }
        for (; ;) {
            if (text("忍痛离开").findOnce()) {
                text("忍痛离开").findOne().click(); sleep(2000);
            }
            if (text("x").findOnce()) {
                text("x").findOne().click(); sleep(1000);
            }
            if (text("任务数量").findOnce()) {
                break;
            }
            back(); sleep(1000);
        }
    }

    Enter_1();
    for (; ;) {
        if (text("领取").findOnce()) {
            text("领取").findOne().click();
            sleep(1500);
        }
        if (text("已完成12/12").findOne(1000)) {
            toastLog("任务已完成");
            toastLog("任务已完成");
            toastLog("任务已完成");
            break;
        }

        if (mission_exit("去探索")) { back_5(); continue; }
        if (mission_exit("浏览超惠寄")) { back_5(); continue; }
        if (mission_exit("用能量喂养")) { back_5(); continue; }
        if (mission_exit("参与1次")) { Answer_Question(); continue; }

        if (mission_exit("逛一逛裹裹")) { back_15(); continue; }
        if (mission_exit("添加1个包裹")) { add_package(); continue; }
        if (mission_exit("浏览会场宝贝")) { Browse_goods(); continue; }
        if (mission_exit("浏览天天")) { back_15(); continue; }
        if (mission_exit("加购3个天天")) { day_Shopping_Cart(); continue; }
        if (mission_exit("完成1次")) { fruit_sign(); continue; }

        toastLog("已完成所有可执行任务");
        toastLog("已完成所有可执行任务");
        toastLog("已完成所有可执行任务");
        break;
    }

    for (; ;) {
        back();
        if (text("我的").findOne(2000)) {
            break;
        }
    }
}

function 切换账号() {
    desc("我的").findOne().click();
    desc("设置页面").findOne().click();
    text("退出登录").findOne().parent().child(0).click();
    text("确定").findOne().click();
    sleep(4000);
    for (; ;) {
        if (text("手机号登录").findOnce()) {
            sleep(1000);
            id("login_privacy_choose").findOne().click();
            sleep(1500);
            var bound = text("手机号登录").findOne().bounds();
            click(bound.centerX(), bound.centerY());
            break;
        }
        if (text("手机淘宝账户登录").findOnce()) {
            break;
        }
    }
    sleep(1000);
    text("手机淘宝账户登录").findOne().click();
    text("更多").findOne().click();
    text("换个账户登录").findOne().click();
    text("请输入淘宝账户").findOne();
    sleep(500);
    setText(0, 账号[当前运行账号]);
    sleep(200);
    setText(1, 密码[当前运行账号]);
    sleep(200);
    desc("登录").findOne().click();
    sleep(3000);
    for (; ;) {
        if (desc("我的").findOnce()) {
            break;
        }
        if (idContains("sys_notify_setting_dialog_close").findOnce()) {
            idContains("sys_notify_setting_dialog_close").findOne().click();
            sleep(1000);
        }
    }
    for (; ;) {
        if (textContains("裹酱积分").findOnce()) {
            sleep(1000);
            break;
        } else {
            desc("我的").findOne().parent().child(0).click();
            sleep(1000);
        }
    }
}


进入首页();
for (var i = 0; i < 6; i++, 当前运行账号++) {
    切换账号();
    做任务();
    //one_billion();
    if (当前运行账号 == 5) {
        当前运行账号 = -1;
    }
}

console.show();
sleep(100);
console.setPosition(400, 400);
console.setSize(730, 900);
console.info("\n\n所有账号任务完成！");
exit();
