var 名称版本="免首重券 1.0";
//
auto.waitFor();
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}

//设定
{
    var 分 = dialogs.input("输入开始时间-分\n\n(返回退出脚本)", 59); if (分 == null) { toast("已停止！"); exit(); }
    var 秒 = dialogs.input("输入开始时间-秒\n\n(返回退出脚本)", 59); if (秒 == null) { toast("已停止！"); exit(); }
    var 延时 = dialogs.input("输入延时(单位毫秒)\n\n(返回退出脚本)", 5); if (延时 == null) { toast("已停止！"); exit(); }
}
//显示
{
    var time = new Date(http.get("http://www.baidu.com").headers["Date"]);
    var month = time.getMonth() + 1;
    var log = "/sdcard/脚本/日志" + month + "." + time.getDate() + ".js";
    var 日志字串1 = "\n================================\n" + time.getHours() + ":" + time.getMinutes() + ":" + time.getSeconds() + "\n    /----" + 名称版本 + "----/\n";
    var 日志字串2 = "";
    var 日志字串3 = "";
    var 日志字串4 = "设定时间：" + 分 + ":" + 秒 + "\n延   时：" + 延时 + "\n";
    var 显示字串 = "      /----" + 名称版本 + "----/\n\n" + 日志字串2 + 日志字串3 + 日志字串4;
    var 日志字串5 = 日志字串1 + 日志字串2 + 日志字串3 + 日志字串4;
    files.append(log, 日志字串5);
}


function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info(显示字串 + "\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(1000);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute >= 分 && second >= 秒) {
            sleep(延时);
            break;
        }
        if (minute == 分 && second <= 秒 - 10) {
            print(minute + ":" + second);
            sleep(800);
        }
        if (minute == 分 && second == 秒 - 9) {
            print(minute + ":" + second);
            console.info("还有9秒");
            toast("还有9秒!\n请等待！");
            sleep(2000);
            toast("还有7秒!\n请等待！");
            console.hide();
            toast("还有5秒!\n马上开始！");
            toast("还有3秒!\n马上开始！");
        }
    }
    return;
}

function 抢券(){
    desc(":刷新").findOne().click();
    for (var i=0; ;i++) {
        if (!textContains("免首重券").findOnce()) {
            break;
        }
    }
    textContains("免首重券 10").findOne();
    for (var i=0; ;i++) {
        if (!textContains("开通VIP").findOnce()) {
            break;
        }
    }
    var 父控件=textContains("免首重券 10").findOne().parent();
    父控件.child(父控件.childCount()-1).click();    

}


倒计时();
抢券();









