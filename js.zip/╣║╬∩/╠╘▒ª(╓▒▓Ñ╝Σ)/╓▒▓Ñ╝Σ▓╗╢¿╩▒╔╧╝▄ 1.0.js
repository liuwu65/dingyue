var 名称版本 = "直播间不定时上架 1.0";
//
auto.waitFor();
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}

//设定
{
    var 关键字 = rawInput("请输入商品序号", ""); if (关键字 == null) { toast("已停止！"); exit(); }
    var options = ["● 判断中间步骤  -  提交", "● 有中间步骤    -    提交", "● 无中间步骤    -    提交", "● 自动选择规格  -  提交", "● 指定规格      -      提交"];
    var 提交方式 = dialogs.select("请选择 提交方式\n\n(若不清楚是否有中间步骤\n请选择 判断中间步骤)\n\n(返回退出脚本)", options); if (提交方式 == -1) { toast("已停止！"); exit(); }
    if (提交方式 == 4) {
        var 类别数 = dialogs.singleChoice("请选择类别数量\n\n(只有一个选项的类不计算)", ["1", "2", "3", "4", "5"]) + 1; if (类别数 == -1) { toast("已停止！"); exit(); };
        var 类别选择 = [''];
        for (var i = 0; i < 类别数; i++) {
            类别选择[i] = dialogs.singleChoice("第" + (i + 1) + "类选择第几个？", ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25"]); if (类别选择[i] == -1) { toast("已停止！"); exit(); };
        }
    }
    var 价格判断 = dialogs.select("是否判断价格？\n\n(返回退出脚本)\n", "● 判断价格", "● 不判断价格"); if (价格判断 == -1) { toast("已停止！"); exit(); }
    if (价格判断 == 0) {
        var 价格1 = null;
        var 理想价格 = dialogs.input("输入物品理想价格\n\n(返回退出脚本)", 50); if (理想价格 == null) { toast("已停止！"); exit(); }
    }
}
//显示
{
    var time = new Date(http.get("http://www.baidu.com").headers["Date"]);
    var month = time.getMonth() + 1;
    var log = "/sdcard/脚本/日志" + month + "." + time.getDate() + ".js";
    var 日志字串1 = "\n===============================\n" + time.getHours() + ":" + time.getMinutes() + ":" + time.getSeconds() + "\n    /----" + 名称版本 + "----/\n";
    var 日志字串2 = "关键字：" + 关键字 + "\n";
    var 日志字串3 = "";
    if (提交方式 == 0) { var 日志字串4 = "提交方式：判断中间步骤\n" }
    if (提交方式 == 1) { var 日志字串4 = "提交方式：有中间步骤\n" }
    if (提交方式 == 2) { var 日志字串4 = "提交方式：无中间步骤\n" }
    if (提交方式 == 3) { var 日志字串4 = "提交方式：自动选择规格\n" }
    if (提交方式 == 4) { var 日志字串4 = "提交方式：指定规格\n类别选择：" + 类别选择 + "\n" }
    var 日志字串5 = 日志字串1 + 日志字串2 + 日志字串3 + 日志字串4 + "理想价格：" + 理想价格 + "\n";
    var 显示字串 = "/----" + 名称版本 + "----/\n\n" + 日志字串2 + 日志字串3 + 日志字串4 + "\n" + "理想价格：￥ " + 理想价格 + "\n";
    files.append(log, 日志字串5);
    var 成立控制 = 0; var 次数 = 0;
}


function 倒计时() {
    console.show();
    sleep(100);
    console.setPosition(400, 400);
    console.setSize(730, 900);
    console.info(显示字串 + "\n脚本已运行！\n" + "最后一分钟开始计时！");
    sleep(100);

    for (; ;) {
        var internetdDate = new Date(http.get("http://www.baidu.com").headers["Date"]);
        var minute = internetdDate.getMinutes();
        var second = internetdDate.getSeconds();
        if (minute == 分) {
            if (second <= 秒 - 6) {
                print(minute + ":" + second);
                sleep(800);
                continue;
            } else {
                console.info(minute + ":" + second);
                console.info("还有5秒");
                sleep(2000);
                toast("还有3秒!");
                console.hide();
                sleep(1000);
                break;
            }
        } else {
            sleep(800);
            continue;
        }
    }
    console.hide();
    for (; ;) {
        var second = new Date(http.get("http://www.baidu.com").headers["Date"]).getSeconds();
        if (second >= 秒) {
            sleep(延时);
            return;
        }
    }
}

function 刷关键字() {
    for (; ;) {
        idContains("taolive_product_switch_btn").findOne().click();
        desc("马上抢").findOne();
        if (desc(关键字).findOnce()) {
            break;
        }
        sleep(100);
    }
}

function 购买点击() {
    textContains("客服").findOne();
    if (idContains("ll_bottom_bar_content").findOne().childCount() == 5) {
        var 购买按钮 = idContains("detail_main_sys_button").find()[1];
    } else {
        var 购买按钮 = idContains("ll_bottom_bar_content").findOne().child(0).child(0).child(2).find(classNameContains("LinearLayout"))[2];
    }
    if (购买按钮 && 购买按钮.enabled()) {
        购买按钮.click();
        成立控制 = 1;
    } else {
        back();
        desc(关键字).findOne();
        return false;
    }
    return true;
}

function 规格页进入判断() {
    for (; ;) {
        if (idContains("body").findOnce()) {
            sleep(200);
            break;
        }
        if (idContains("sku_native_view_layout").findOnce()) {
            sleep(260);
            break;
        }
    }
}

function 自动选规格操作() {
    for (; ;) {
        if (idContains("sku_native_view_layout").findOnce()) {
            idContains("sku_native_view_layout").findOne().children().forEach(function (类) {
                类.children().forEach(function (类2) {
                    if (类2.className() == "android.widget.RelativeLayout") {
                        if (类2.childCount() == 1) { return; }
                        类2.children().every(function (项) {
                            if (项.desc().indexOf("不可选择") != -1) {
                                return true;
                            } else {
                                项.click();
                                return false;
                            }
                        });
                    }
                });
            });
            break;
        }
        if (idContains("body").findOnce()) {
            var 类 = descContains("可选").findOne().parent().parent().parent();
            if (类.parent().id() != "com.taobao.taobao:id/body") {
                类 = 类.parent().parent();
            }
            类.children().forEach(function (类2) {
                if (类2.className().indexOf("support.v7.widget") != -1) {
                    if (类2.child(0).child(0).childCount() != 1) {
                        类2.child(0).child(0).children().every(function (项) {
                            if (项.child(0).desc().indexOf("不可选") != -1) {
                                return true;
                            } else {
                                项.child(0).click();
                                sleep(30);
                                return false;
                            }
                        });
                    }
                }
                if (类2.className().indexOf("FrameLayout") != -1) {
                    if (类2.childCount() != 1) {
                        类2.children().every(function (项) {
                            if (项.child(0).desc().indexOf("不可选") != -1) {
                                return true;
                            } else {
                                项.child(0).click();
                                sleep(30);
                                return false;
                            }
                        });
                    }
                }
            });
            break;
        }
    }
}

function 指定规格操作() {
    for (; ;) {
        if (idContains("sku_native_view_layout").findOnce()) {
            var i = 0;
            idContains("sku_native_view_layout").findOne().children().forEach(function (类) {
                类.children().forEach(function (类2) {
                    if (类2.className() == "android.widget.RelativeLayout") {
                        if (类2.childCount() != 1) {
                            if (类2.child(类别选择[i]).desc().indexOf("不可选") != -1) {
                                类2.children().every(function (项) {
                                    if (项.desc().indexOf("不可选") != -1) {
                                        return true;
                                    } else {
                                        项.click();
                                        i++;
                                        return false;
                                    }
                                });
                            } else {
                                类2.child(类别选择[i]).click();
                            }
                            i++;
                        }
                    }
                });
            });
            break;
        }
        if (idContains("body").findOnce()) {
            var 类; var i = 0;
            var 类 = descContains("可选").findOne().parent().parent().parent();
            if (类.parent().id() != "com.taobao.taobao:id/body") {
                类 = 类.parent().parent();
            }
            类.children().forEach(function (类2) {
                if (类2.className().indexOf("support.v7.widget") != -1) {
                    if (类2.child(0).child(0).childCount() != 1) {
                        if (类2.child(0).child(0).child(类别选择[i]).child(0).desc().indexOf("不可选") != -1) {
                            类2.child(0).child(0).children().every(function (项) {
                                if (项.child(0).desc().indexOf("不可选") != -1) {
                                    return true;
                                } else {
                                    项.child(0).click();
                                    i++;
                                    sleep(30);
                                    return false;
                                }
                            });
                        } else {
                            类2.child(0).child(0).child(类别选择[i]).child(0).click();
                            sleep(30);
                            i++;
                        }
                    }
                }
                if (类2.className().indexOf("FrameLayout") != -1) {
                    if (类2.childCount() != 1) {
                        if (类2.child(类别选择[i]).child(0).desc().indexOf("不可选") != -1) {
                            类2.children().every(function (项) {
                                if (项.child(0).desc().indexOf("不可选") != -1) {
                                    return true;
                                } else {
                                    项.child(0).click();
                                    i++;
                                    sleep(30);
                                    return false;
                                }
                            });
                        } else {
                            类2.child(类别选择[i]).child(0).click();
                            sleep(30);
                            i++;
                        }
                    }
                }
            });
            break;
        }
    }
};

function 确定点击() {
    for (; ;) {
        if (text("立即购买").boundsInside(0, 1600, device.width, device.height
        ).findOnce()) {
            var 范围 = text("立即购买").boundsInside(0, 1600, device.width, device.height
            ).findOne().bounds();
            click(范围.centerX(), 范围.centerY());
            break;
        }
        if (text("确定").boundsInside(0, 1600, device.width, device.height
        ).findOnce()) {
            var 范围 = text("确定").boundsInside(0, 1600, device.width, device.height
            ).findOne().bounds();
            click(范围.centerX(), 范围.centerY());
            break;
        }
        if (textContains("确认").boundsInside(0, 1600, device.width, device.height
        ).findOnce()) {
            var 范围 = textContains("确认").boundsInside(0, 1600, device.width, device.height
            ).findOne().bounds();
            click(范围.centerX(), 范围.centerY());
            break;
        }
        if (textContains("马上抢").boundsInside(0, 1600, device.width, device.height
        ).findOnce()) {
            var 范围 = textContains("马上抢").boundsInside(0, 1600, device.width, device.height
            ).findOne().bounds();
            click(范围.centerX(), 范围.centerY());
            break;
        }
        if (text("领券购买").boundsInside(0, 1600, device.width, device.height
        ).findOnce()) {
            var 范围 = text("领券购买").boundsInside(0, 1600, device.width, device.height
            ).findOne().bounds();
            click(范围.centerX(), 范围.centerY());
            break;
        }
    }
}

function 返回再进入() {
    for (; ;) {
        if (textContains("客服").findOnce()) {
            if (idContains("ll_bottom_bar_content").findOne().childCount() == 5) {
                var 购买按钮 = idContains("detail_main_sys_button").find()[1];
            } else {
                var 购买按钮 = idContains("ll_bottom_bar_content").findOne().child(0).child(0).child(2).find(classNameContains("LinearLayout"))[2];
            }
            购买按钮.click();
            规格页进入判断();
            确定点击();
            break;
        }
        if (idContains("body").findOnce() || idContains("sku_native_view_layout").findOnce()) {
            确定点击();
            break;
        }
    }
}




function 判断价格捡漏() {
    if (!购买点击()) {
        return;
    }

    if (提交方式 == 0) {           //判断中间步骤-提交
        var djkz = 0;
        for (; ;) {
            if (text("提交订单").findOnce()) {
                break;
            }
            if (djkz == 0 && (idContains("body").findOnce() || idContains("sku_native_view_layout").findOnce())) {
                确定点击();
                djkz = 1;
            }
        }
        if (djkz == 0) {
            for (; ;) {
                for (; ;) {
                    text("提交订单").findOne();
                    var 价格 = textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥', '');
                    if (价格 > 理想价格 || textContains("购买数量超过").findOnce() || textContains("商品不能购买").findOnce() || textContains("已无库存").findOnce()) {
                        sleep(1100);
                        back();
                        textContains("客服").findOne();
                        idContains("detail_main_sys_button").find()[1].click();
                        continue;
                    } else {
                        break;
                    }
                }
                text("提交订单").findOne().click();
                if (textContains("我知道了").findOne(500)) {
                    textContains("我知道了").findOne().click();
                    textContains("客服").findOne();
                    idContains("detail_main_sys_button").find()[1].click();
                    continue;
                } else {
                    break;
                }
            }
            toast("抢购完成！！！");
        }
        if (djkz == 1) {
            for (; ;) {
                for (; ;) {
                    text("提交订单").findOne();
                    var 价格 = textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥', '');
                    if (价格 > 理想价格 || textContains("购买数量超过").findOnce() || textContains("商品不能购买").findOnce() || textContains("已无库存").findOnce()) {
                        sleep(1100);
                        back();
                        返回再进入();
                        continue;
                    } else {
                        break;
                    }
                }
                text("提交订单").findOne().click();
                if (textContains("我知道了").findOne(500)) {
                    textContains("我知道了").findOne().click();
                    返回再进入();
                    continue;
                } else {
                    break;
                }
            }
            toast("抢购完成！！！");
        }
    }

    if (提交方式 == 1) {           //有中间步骤-提交
        规格页进入判断();
        确定点击();
        for (; ;) {
            for (; ;) {
                text("提交订单").findOne();
                var 价格 = textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥', '');
                if (价格 > 理想价格 || textContains("购买数量超过").findOnce() || textContains("商品不能购买").findOnce() || textContains("已无库存").findOnce()) {
                    sleep(1100);
                    back();
                    返回再进入();
                    continue;
                } else {
                    break;
                }
            }
            text("提交订单").findOne().click();
            if (textContains("我知道了").findOne(500)) {
                textContains("我知道了").findOne().click();
                返回再进入();
                continue;
            } else {
                break;
            }
        }
        toast("抢购完成！！！");
    }

    if (提交方式 == 2) {           //无中间步骤-提交
        for (; ;) {
            for (; ;) {
                text("提交订单").findOne();
                var 价格 = textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥', '');
                if (价格 > 理想价格 || textContains("购买数量超过").findOnce() || textContains("商品不能购买").findOnce() || textContains("已无库存").findOnce()) {
                    sleep(1100);
                    back();
                    textContains("客服").findOne();
                    idContains("detail_main_sys_button").find()[1].click();
                    continue;
                } else {
                    break;
                }
            }
            text("提交订单").findOne().click();
            if (textContains("我知道了").findOne(500)) {
                textContains("我知道了").findOne().click();
                back();
                textContains("客服").findOne();
                idContains("detail_main_sys_button").find()[1].click();
                continue;
            } else {
                break;
            }
        }
        toast("抢购完成！！！");
    }

    if (提交方式 == 3) {           //自动选择规格-提交
        规格页进入判断();
        自动选规格操作();
        确定点击();

        for (; ;) {
            for (; ;) {
                text("提交订单").findOne();
                var 价格 = textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥', '');
                if (价格 > 理想价格 || textContains("购买数量超过").findOnce() || textContains("商品不能购买").findOnce() || textContains("已无库存").findOnce()) {
                    sleep(1100);
                    back();
                    返回再进入();
                    continue;
                } else {
                    break;
                }
            }
            text("提交订单").findOne().click();
            if (textContains("我知道了").findOne(500)) {
                textContains("我知道了").findOne().click();
                返回再进入();
                continue;
            } else {
                break;
            }
        }
        toast("抢购完成！！！");
    }
    if (提交方式 == 4) {           //指定规格-提交
        规格页进入判断();
        指定规格操作();
        确定点击();

        for (; ;) {
            for (; ;) {
                text("提交订单").findOne();
                var 价格 = textStartsWith("合计").findOne().parent().findOne(textStartsWith("￥")).text().replace('￥', '');
                if (价格 > 理想价格 || textContains("购买数量超过").findOnce() || textContains("商品不能购买").findOnce() || textContains("已无库存").findOnce()) {
                    sleep(1100);
                    back();
                    返回再进入();
                    continue;
                } else {
                    break;
                }
            }
            text("提交订单").findOne().click();
            if (textContains("我知道了").findOne(500)) {
                textContains("我知道了").findOne().click();
                返回再进入();
                continue;
            } else {
                break;
            }
        }
        toast("抢购完成！！！");
    }
}

function 判断价格() {
    toast("抢购开始。。。");
    刷关键字();
    for (; ;) {
        desc(关键字).findOne().parent().parent().parent().parent().click();
        次数++;
        判断价格捡漏();
        if (成立控制 == 1) {
            break;
        }
        for (; ;) {
            if (textContains("客服").findOnce()) {
                continue;
            } else {
                break;
            }
        }
    }
    files.append(log, "    最后显示价格：￥ " + 价格1 + "\n    进入次数统计：" + 次数 + "\n================================\n");
    if (成立控制 == 1) {
        toast("抢购结束！！！");
    }
}




function 不判断价格捡漏() {
    if (!购买点击()) {
        return;
    }

    if (提交方式 == 0) {           //判断中间步骤-提交
        var djkz = 0;
        for (; ;) {
            if (text("提交订单").findOnce()) {
                break;
            }
            if (djkz == 0 && (idContains("body").findOnce() || idContains("sku_native_view_layout").findOnce())) {
                确定点击();
                djkz = 1;
            }
        }
        if (djkz == 0) {
            for (; ;) {
                for (; ;) {
                    text("提交订单").findOne();
                    if (textContains("购买数量超过").findOnce() || textContains("商品不能购买").findOnce() || textContains("已无库存").findOnce()) {
                        sleep(1100);
                        back();
                        textContains("客服").findOne();
                        idContains("detail_main_sys_button").find()[1].click();
                        continue;
                    } else {
                        break;
                    }
                }
                text("提交订单").findOne().click();
                if (textContains("我知道了").findOne(500)) {
                    textContains("我知道了").findOne().click();
                    textContains("客服").findOne();
                    idContains("detail_main_sys_button").find()[1].click();
                    continue;
                } else {
                    break;
                }
            }
            toast("抢购完成！！！");
        }
        if (djkz == 1) {
            for (; ;) {
                for (; ;) {
                    text("提交订单").findOne();
                    if (textContains("购买数量超过").findOnce() || textContains("商品不能购买").findOnce() || textContains("已无库存").findOnce()) {
                        sleep(1100);
                        back();
                        返回再进入();
                        continue;
                    } else {
                        break;
                    }
                }
                text("提交订单").findOne().click();
                if (textContains("我知道了").findOne(500)) {
                    textContains("我知道了").findOne().click();
                    返回再进入();
                    continue;
                } else {
                    break;
                }
            }
            toast("抢购完成！！！");
        }
    }

    if (提交方式 == 1) {           //有中间步骤-提交
        规格页进入判断();
        确定点击();
        for (; ;) {
            for (; ;) {
                text("提交订单").findOne();
                if (textContains("购买数量超过").findOnce() || textContains("商品不能购买").findOnce() || textContains("已无库存").findOnce()) {
                    sleep(1100);
                    back();
                    返回再进入();
                    continue;
                } else {
                    break;
                }
            }
            text("提交订单").findOne().click();
            if (textContains("我知道了").findOne(500)) {
                textContains("我知道了").findOne().click();
                返回再进入();
                continue;
            } else {
                break;
            }
        }
        toast("抢购完成！！！");
    }

    if (提交方式 == 2) {           //无中间步骤-提交
        for (; ;) {
            for (; ;) {
                text("提交订单").findOne();
                if (textContains("购买数量超过").findOnce() || textContains("商品不能购买").findOnce() || textContains("已无库存").findOnce()) {
                    sleep(1100);
                    back();
                    textContains("客服").findOne();
                    idContains("detail_main_sys_button").find()[1].click();
                    continue;
                } else {
                    break;
                }
            }
            text("提交订单").findOne().click();
            if (textContains("我知道了").findOne(500)) {
                textContains("我知道了").findOne().click();
                textContains("客服").findOne();
                idContains("detail_main_sys_button").find()[1].click();
                continue;
            } else {
                break;
            }
        }
        toast("抢购完成！！！");
    }

    if (提交方式 == 3) {                     //自动选择规格-提交
        规格页进入判断();
        自动选规格操作();
        确定点击();
        for (; ;) {
            for (; ;) {
                text("提交订单").findOne();
                if (textContains("购买数量超过").findOnce() || textContains("商品不能购买").findOnce() || textContains("已无库存").findOnce()) {
                    sleep(1100);
                    back();
                    返回再进入();
                    continue;
                } else {
                    break;
                }
            }
            text("提交订单").findOne().click();
            if (textContains("我知道了").findOne(500)) {
                textContains("我知道了").findOne().click();
                返回再进入();
                continue;
            } else {
                break;
            }
        }
        toast("抢购完成！！！");
    }

    if (提交方式 == 4) {                     //指定规格-提交
        规格页进入判断();
        指定规格操作();
        确定点击();

        for (; ;) {
            for (; ;) {
                text("提交订单").findOne();
                if (textContains("购买数量超过").findOnce() || textContains("商品不能购买").findOnce() || textContains("已无库存").findOnce()) {
                    sleep(1100);
                    back();
                    返回再进入();
                    continue;
                } else {
                    break;
                }
            }
            text("提交订单").findOne().click();
            if (textContains("我知道了").findOne(500)) {
                textContains("我知道了").findOne().click();
                返回再进入();
                continue;
            } else {
                break;
            }
        }
        toast("抢购完成！！！");
    }
}

function 不判断价格() {
    toast("抢购开始。。。");
    刷关键字();
    for (; ;) {
        desc(关键字).findOne().parent().parent().parent().parent().click();
        次数++;
        不判断价格捡漏();
        if (成立控制 == 1) {
            break;
        }
        for (; ;) {
            if (textContains("客服").findOnce()) {
                continue;
            } else {
                break;
            }
        }
    }
    files.append(log, "\n    进入次数统计：" + 次数 + "\n================================\n");
    if (成立控制 == 1) {
        toast("抢购结束！！！");
    }
}



if (价格判断 == 0) {
    判断价格();
}

if (价格判断 == 1) {
    不判断价格();
}
