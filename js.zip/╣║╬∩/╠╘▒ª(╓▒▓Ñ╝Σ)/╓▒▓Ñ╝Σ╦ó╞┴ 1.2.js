//直播间刷屏 1.2.js
//修复不点击bug
auto.waitFor();
停止其他脚本();
function 停止其他脚本() {
    var 运行的脚本 = [''];
    for (var i = 0; i < engines.all().length; i++) {
        var t = ("" + engines.all()[i].source).replace('/storage/emulated/0/', '');
        运行的脚本[i] = t;
    }
    var u = ("" + engines.myEngine().source).replace('/storage/emulated/0/', '');
    for (var i = 0; i < 运行的脚本.length; i++) {
        if (运行的脚本[i] != u) {
            engines.all()[i].forceStop();
            toast(运行的脚本[i] + ":已停止！");
        }
    }
}

var 发送内容 = rawInput("发送内容", ""); if (发送内容 == null) { toast("已停止！"); exit(); }
var 发送次数 = dialogs.input("发送次数", 6); if (发送次数 == null) { toast("已停止！"); exit(); }

for (var i = 0; i < 发送次数; i++) {
    for (; ;) {
        if (text("发送").findOnce()) {
            break;
        }
        idContains("taolive_chat_msg_btn").findOne().click();
        sleep(200);
    }
    idContains("taolive_edit_text").findOne().setText(发送内容);
    for (; ;) {
        if (!text("发送").findOnce()) {
            break;
        }
        text("发送").findOne().click();
        sleep(200);
    }
}
